<?php
session_start(); // Khởi tạo phiên nếu chưa có
session_destroy(); // Hủy phiên nếu đã khởi tạo thành công
header("Location: index.php");
exit();