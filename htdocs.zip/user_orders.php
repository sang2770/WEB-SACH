<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

if (!isLogined()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Lấy tất cả các đơn hàng của người dùng
$sql = "SELECT * FROM don_hang WHERE user_id = ? ORDER BY ngay_dat DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách đơn hàng của bạn</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php require_once 'header.php'; ?>

<div class="container mt-3">
    <h2>Danh sách đơn hàng của bạn</h2>
    <?php if (empty($orders)) : ?>
        <p>Bạn chưa có đơn hàng nào!</p>
    <?php else : ?>
        <div class="accordion" id="ordersAccordion">
            <?php foreach ($orders as $index => $order) : ?>
                <?php
                // Lấy chi tiết sách trong đơn hàng
                $order_id = $order['id'];
                $sql_details = "SELECT ctdh.ma_sach, s.ten_sach, ctdh.so_luong, ctdh.gia, ctdh.thanh_tien
                                FROM chi_tiet_don_hang ctdh
                                JOIN sach s ON ctdh.ma_sach = s.id
                                WHERE ctdh.ma_don_hang = ?";
                $stmt_details = $conn->prepare($sql_details);
                $stmt_details->bind_param("i", $order_id);
                $stmt_details->execute();
                $result_details = $stmt_details->get_result();
                $details = [];
                $total = 0; // Khởi tạo tổng tiền cho mỗi đơn hàng
                while ($row_details = $result_details->fetch_assoc()) {
                    $details[] = $row_details;
                    $total += $row_details['thanh_tien']; // Tính tổng tiền
                }
                $stmt_details->close();
                ?>
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; border-bottom: 2px solid #ccc;" id="heading<?php echo $index; ?>">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo $index; ?>" aria-expanded="true" aria-controls="collapse<?php echo $index; ?>">
                                Ngày đặt: <?php echo htmlspecialchars($order['ngay_dat']); ?>
                            </button>
                            
                        </h5>
                        <p><strong>Trạng thái:</strong> <?php echo htmlspecialchars($order['status']); ?></p>

                    </div>
                    <div id="collapse<?php echo $index; ?>" class="collapse" aria-labelledby="heading<?php echo $index; ?>" data-parent="#ordersAccordion">
                        <div class="card-body" style="padding: 20px 50px;">
                            <p><strong>Họ tên:</strong> <?php echo htmlspecialchars($order['ho_ten']); ?></p>
                            <p><strong>Địa chỉ:</strong> <?php echo htmlspecialchars($order['dia_chi']); ?></p>
                            <p><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($order['sdt']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
                            <?php if (empty($details)) : ?>
                                <p>Không có thông tin sách.</p>
                            <?php else : ?>
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Tên sách</th>
                                        <th scope="col">Số lượng</th>
                                        <th scope="col">Giá</th>
                                        <th scope="col">Thành tiền</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($details as $detail) : ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($detail['ten_sach']); ?></td>
                                            <td><?php echo htmlspecialchars($detail['so_luong']); ?></td>
                                            <td><?php echo number_format($detail['gia'], 0, ',', '.'); ?> VND</td>
                                            <td><?php echo number_format($detail['thanh_tien'], 0, ',', '.'); ?> VND</td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <!-- Hiển thị tổng tiền cho mỗi đơn hàng -->
                                <p><strong>Tổng tiền:</strong> <?php echo number_format($total, 0, ',', '.'); ?> VND</p>
                            <?php endif; ?>
                            <p><strong>Ghi chú:</strong> <?php echo htmlspecialchars($order['ghi_chu']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php require_once 'footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
