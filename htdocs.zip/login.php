<?php session_start();?>
<?php
include "helper/common.php";
include_once "helper/user.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usernameoremail = $_POST["usernameoremail"];
    $password = $_POST["matkhau"];
    if (!login($usernameoremail, $password)) {
        setMessage("danger", "Thông tin đăng nhập không chính ");
        redirectToSelf();
    }
}
?>
<?php include 'header.php';?>
<div class="card p-lg-5 w-50 mx-auto mt-5">
    <div class="container">
        <h2 class="mt-5 text-center">Đăng nhập</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Tên người dùng hoặc email:</label>
                <input type="text" class="form-control" id="usernameoremail" name="usernameoremail" required>
            </div>
            <div class="form-group">
                <label for="matkhau">Mật khẩu:</label>
                <input type="password" class="form-control" id="matkhau" name="matkhau" required>
            </div>
            <button type="submit" class="btn btn-primary mt-1">Đăng nhập</button>
            <div>
                <span>Bạn chưa có tài khoản?</span><a href="register.php">Đăng ký</a> <br>
                <span>Bạn quên mật khẩu?</span><a href="forgot_password.php">Quên mật khẩu</a>

            </div>
        </form>
    </div>
</div>


<?php require_once 'footer.php'; ?>
