<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;
?>

<?php require_once 'header.php'; ?>

<div class="container mt-3">
    <form id="filter-form" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <select name="sort_price" class="form-control">
                    <option value="">Sắp xếp theo giá</option>
                    <option value="asc">Giá tăng dần</option>
                    <option value="desc">Giá giảm dần</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="theloai" class="form-control">
                    <option value="">Chọn thể loại</option>
                    <!-- PHP để load danh sách thể loại -->
                    <?php
                    $sql = "SELECT ma_tl, ten_tl FROM theloai";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['ma_tl'] . '">' . $row['ten_tl'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="tacgia" class="form-control">
                    <option value="">Chọn tác giả</option>
                    <!-- PHP để load danh sách tác giả -->
                    <?php
                    $sql = "SELECT ma_tg, ten_tg FROM tacgia";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['ma_tg'] . '">' . $row['ten_tg'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="nhaxuatban" class="form-control">
                    <option value="">Chọn nhà xuất bản</option>
                    <!-- PHP để load danh sách nhà xuất bản -->
                    <?php
                    $sql = "SELECT ma_nxb, ten_nxb FROM nhaxuatban";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['ma_nxb'] . '">' . $row['ten_nxb'] . '</option>';
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control" placeholder="Tìm kiếm theo tên sách">
            </div>
            <div class="col-md-6">
                <button type="submit" class="btn btn-primary">Lọc sách</button>
            </div>
        </div>
    </form>

    <div class="row" id="book-list">
        <?php
        // Tải danh sách sách mặc định (có thể là tất cả sách hoặc sách phổ biến)
        include 'load_books.php';
        ?>
    </div>
</div>
<?php require_once 'footer.php'; ?>

<script>
    document.getElementById('filter-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var formData = new FormData(this);

        fetch('load_books.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.text())
            .then(data => {
                document.getElementById('book-list').innerHTML = data;
            });
    });

    document.addEventListener('DOMContentLoaded', function () {
        var cartButtons = document.querySelectorAll('.add-to-cart');

        cartButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var bookId = this.getAttribute('data-book-id');
                var price = this.getAttribute('data-price');

                fetch('add_to_cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'ma_sach=' + bookId + '&gia=' + price
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            document.getElementById('cart-count').textContent = data.total_items;
                        } else {
                        }
                    });
            });
        });
    });
</script>