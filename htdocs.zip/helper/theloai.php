<?php
function get_theloai($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM theloai WHERE 1=1";
    if (!empty($search)) {
        $query .= " AND (ma_tl LIKE '%$search%' 
                        OR ten_tl LIKE '%$search%' 
                        OR ma_dm LIKE '%$search%')";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $theloai = array();
    while ($row = $results->fetch_assoc()) {
        $theloai[] = $row;
    }
    return $theloai;
}

function get_total_theloai($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM theloai WHERE 1=1";
    if (!empty($search)) {
        $query .= " AND (ma_tl LIKE '%$search%' 
                        OR ten_tl LIKE '%$search%' 
                        OR ma_dm LIKE '%$search%')";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];
}

function setStatusTL($id, $status = 1)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE theloai SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
}

function create_tl($ten_tl, $ma_dm)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO theloai (ten_tl, ma_dm) VALUES (?, ?)");
    $stmt->bind_param("ss", $ten_tl, $ma_dm);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE theloai SET ma_tl = 'TL$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $id;
}

function get_tl_by_name($name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM theloai WHERE ten_tl = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->num_rows > 0;
}

function get_tl_by_id($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM theloai WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->fetch_object();
}

function update_tl_by_id($id, $ten_tl, $ma_dm)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE theloai SET ten_tl = ?, ma_dm = ? WHERE id = ?");
    $stmt->bind_param("ssi", $ten_tl, $ma_dm, $id);
    $stmt->execute();
}