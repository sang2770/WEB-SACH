<?php
function get_nhaxuatban($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM nhaxuatban";
    if (!empty($search)) {
        $query .= " WHERE ma_nxb LIKE '%$search%' 
                        or ten_nxb LIKE '%$search%' 
                        or sdt like '%$search%' 
                        or dia_chi like '%$search%'
                        or email like '%$search%'";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $nhaxuatbans = array();
    while ($row = $results->fetch_assoc()) {
        $nhaxuatbans[] = $row;
    }
    return $nhaxuatbans;
}

function get_total_nhaxuatban($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM nhaxuatban";
    if (!empty($search)) {
        $query .= " WHERE ma_nxb LIKE '%$search%' 
                        or ten_nxb LIKE '%$search%' 
                        or sdt like '%$search%' 
                        or dia_chi like '%$search%'
                        or email like '%$search%'";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];

}

function setStatusNXB($id, $status = 1)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE nhaxuatban SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
}

function create_nxb($ten_nxb, $sdt, $dia_chi, $email)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO nhaxuatban (ten_nxb, sdt, dia_chi, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $ten_nxb, $sdt, $dia_chi, $email);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE nhaxuatban SET ma_nxb = 'NXB$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $id;
}

function get_nxb_by_name($name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM nhaxuatban WHERE ten_nxb = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->num_rows > 0;
}

function get_nxb_by_id($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM nhaxuatban WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->fetch_object();
}

function update_nxb_by_id($id, $ten_nxb, $sdt, $dia_chi, $email)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE nhaxuatban SET ten_nxb = ?, sdt = ?, dia_chi = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $ten_nxb, $sdt, $dia_chi, $email, $id);
    $stmt->execute();
}