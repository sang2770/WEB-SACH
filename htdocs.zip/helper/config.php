<?php
// Thông tin cấu hình cơ sở dữ liệu
$servername = "localhost"; // MySQL chạy trên localhost
$username = "root";
$password = "";
$database = "bansach_2";

// Kết nối MySQLi
$conn = new mysqli($servername, $username, $password, $database);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$LIMIT = 4;

// Đóng kết nối - chỉ nên dùng khi kết thúc phiên làm việc
// $conn->close();
?>