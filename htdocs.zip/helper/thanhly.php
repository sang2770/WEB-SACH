<?php

function get_thanhly($search, $limit, $offset) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT thanhly.*, user.* 
              FROM thanhly 
              JOIN user ON user.id = thanhly.nguoi_tao 
              join role on role.id = user.role_id
              WHERE user.role_id != 6 and ( ma_tl LIKE ? OR user.username LIKE ?)
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssii', $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_thanhly_by_id($id) {
    global $conn;
    $query = "SELECT thanhly.*, user.* 
              FROM thanhly 
              JOIN user ON user.id = thanhly.nguoi_tao 
              join role on role.id = user.role_id
              WHERE user.role_id = 6 and (ma_tl LIKE ? OR user.username LIKE ?)
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssii', $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_total_hoadon($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM thanhly JOIN user ON user.id = thanhly.nguoi_tao 
                         join role on role.id = user.role_id
               WHERE user.role_id = 6 and ( ma_tl LIKE ? or user.username LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function get_total_thanhly($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM thanhly JOIN user ON user.id = thanhly.nguoi_tao 
                         join role on role.id = user.role_id
               WHERE user.role_id != 6 and ( ma_tl LIKE ? or user.username LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function setStatus_thanhly($id, $status = 1) {
    global $conn;
    $query = "UPDATE thanhly SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
}

function get_sach_by_thanhly($ma_pn) {
    global $conn;
    $query = "SELECT chi_tiet_thanh_ly.*, FORMAT(chi_tiet_thanh_ly.gia, 'N0') as 'gia_ban', FORMAT(sach.gia, 'N0') as von, sach.ten_sach, donvitinh.* 
    FROM chi_tiet_thanh_ly
    join sach on sach.ma_sach = chi_tiet_thanh_ly.ma_sach
    join thanhly on thanhly.ma_tl = chi_tiet_thanh_ly.ma_tl
    join donvitinh on donvitinh.ma_dvt = sach.ma_dvt WHERE chi_tiet_thanh_ly.ma_tl = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $ma_pn);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


function xac_nhan_thanhly($id) {
    global $conn;
    $query = "UPDATE thanhly SET trang_thai = 2 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function huy_thanhly($id) {
    global $conn;
    $query = "UPDATE thanhly SET trang_thai = 3 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function get_thanhlyall($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT thanhly.*, user.*
              FROM thanhly 
              JOIN user ON user.id = thanhly.nguoi_tao 
              WHERE (ma_tl LIKE ? OR user.username LIKE ?) 
              AND thanhly.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}