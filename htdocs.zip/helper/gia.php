<?php
function get_gia($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM gia";
    if (!empty($search)) {
        $query .= " WHERE ma_gia LIKE '%$search%' 
                        or ten_gia LIKE '%$search%'";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $gias = array();
    while ($row = $results->fetch_assoc()) {
        $gias[] = $row;
    }
    return $gias;
}


function get_total_gia($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM gia";
    if (!empty($search)) {
        $query .= " WHERE ma_gia LIKE '%$search%' 
                        or ten_gia LIKE '%$search%'";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];

}


function set_status_gia($id, $status = 1)
{
    global $conn;
    $query = "UPDATE gia SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}


function get_gia_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM gia WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}


function get_gia_by_name($name)
{
    global $conn;
    $query = "SELECT * FROM gia WHERE ten_gia = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}


/**
 * Create a new gia entry in the database.
 *
 * @param string $ten_gia
 * @param string $tinh_trang
 * @param string $ma_tuke
 * @return bool|int
 */
function create_gia($ten_gia, $tinh_trang, $ma_tuke)
{
    global $conn;
    $query = "INSERT INTO gia (ten_gia, tinh_trang, ma_tuke) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('sss', $ten_gia, $tinh_trang, $ma_tuke);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE gia SET ma_gia = 'G$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->insert_id;
}


/**
 * Update an existing gia entry in the database by id.
 *
 * @param int $id
 * @param string $ten_gia
 * @param string $tinh_trang
 * @param string $ma_tuke
 * @return bool
 */
function update_gia($id, $ten_gia, $tinh_trang, $ma_tuke)
{
    global $conn;
    $query = "UPDATE gia SET ten_gia = ?, tinh_trang = ?, ma_tuke = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('sssi', $ten_gia, $tinh_trang, $ma_tuke, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}

function get_gia_list() {
    global $conn;
    $query = "SELECT ma_gia, ten_gia FROM gia WHERE is_active = 1 ORDER BY ten_gia ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $tuke_list = array();
    while ($row = $results->fetch_assoc()) {
        $item = array(
            'key' => $row['ma_gia'],
            'value' => $row['ten_gia']
        );
        $tuke_list[] = $item;
    }
    return $tuke_list;
}
?>