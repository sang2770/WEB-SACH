<?php
include_once 'config.php';
function isUserExisted($email, $username)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ? or username = ?");
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

function createUser($usename, $email, $password)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO user (username, email, matkhau) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $usename, $email, $password);
    $stmt->execute();
    setSession("user_id", $conn->insert_id);
    setSession("role_id", 6);
    setSession("username", $usename);
    redirectTo("index.php");
}

function isLogined()
{
    return getSession("user_id") != null;
}


function login($usernameoremail, $password)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM user WHERE (username = ? or email = ?) and matkhau = ?");
    $md5 = md5($password);
    $stmt->bind_param("sss", $usernameoremail, $usernameoremail, $md5);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        setSession("user_id", $row['id']);
        setSession("role_id", $row['role_id']);
        setSession("username", $row['username']);
        if ($row['role_id'] != 6) {
            redirectTo("/admin/index.php");
        } else {}
        redirectTo("index.php");
    }
    return null;
}

function getUserList($search, $limit, $offset)
{
    global $conn;

    // Chuẩn bị truy vấn SQL với điều kiện tìm kiếm nếu có
    $sql = "SELECT user.id, username, email, is_active, role.name as role 
            FROM user LEFT join role ON role.id = user.role_id";

    // Kiểm tra nếu có giá trị tìm kiếm
    if (!empty($search)) {
        $sql .= " WHERE username LIKE ? OR email LIKE ?";
    }

    // Thêm LIMIT và OFFSET vào truy vấn SQL
    $sql .= " LIMIT ? OFFSET ?";

    // Chuẩn bị truy vấn
    $stmt = $conn->prepare($sql);

    if (!empty($search)) {
        // Chuẩn bị giá trị tìm kiếm cho truy vấn
        $searchTerm = "%$search%";
        $stmt->bind_param("ssii", $searchTerm, $searchTerm, $limit, $offset);
    } else {
        $stmt->bind_param("ii", $limit, $offset);
    }

    // Thực thi truy vấn
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    // Tạo mảng để lưu trữ người dùng
    $users = [];

    // Lặp qua từng kết quả và lưu vào mảng
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    // Trả về danh sách người dùng
    return $users;
}

function getUserCount($search = "")
{
    global $conn;

    // Chuẩn bị truy vấn SQL với điều kiện tìm kiếm nếu có
    $sql = "SELECT COUNT(*) AS total FROM user";

    // Kiểm tra nếu có giá trị tìm kiếm
    if (!empty($search)) {
        $sql .= " WHERE username LIKE ? OR email LIKE ?";
    }

    // Chuẩn bị truy vấn
    $stmt = $conn->prepare($sql);

    if (!empty($search)) {
        // Chuẩn bị giá trị tìm kiếm cho truy vấn
        $searchTerm = "%$search%";
        $stmt->bind_param("ss", $searchTerm, $searchTerm);
    }

    // Thực thi truy vấn
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        return $row['total'];
    }

    return 0;
}

function setActive($userid, $status = 1)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE user SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status,$userid);
    $stmt->execute();
}

function setRole($userid, $roleid)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE user SET role_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $roleid,$userid);
    $stmt->execute();
}