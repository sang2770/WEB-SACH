<?php

function get_donhang($search, $limit, $offset)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT don_hang.*, don_hang.id as id_dh, user.*, user.id as user_id
              FROM don_hang 
              LEFT JOIN user ON user.id = don_hang.user_id 
              WHERE ho_ten LIKE ? OR user.username LIKE ? OR dia_chi LIKE ? OR sdt LIKE ?
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssii', $search, $search, $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_total_donhang($search)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM don_hang JOIN user ON user.id = don_hang.user_id 
              WHERE ho_ten LIKE ? OR user.username LIKE ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function setStatus_donhang($id, $status = 'Chờ xử lý')
{
    global $conn;
    $query = "UPDATE don_hang SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
}

function get_sach_by_donhang($id)
{
    global $conn;
    $query = "SELECT chi_tiet_don_hang.*, FORMAT(chi_tiet_don_hang.gia, 'N0') as 'gia_ban', sach.ten_sach 
              FROM chi_tiet_don_hang
              JOIN sach ON sach.id = chi_tiet_don_hang.ma_sach
              WHERE chi_tiet_don_hang.ma_don_hang = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_donhangall($search)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT don_hang.*, don_hang.id as id_dh, user.*
              FROM don_hang 
              JOIN user ON user.id = don_hang.user_id 
              WHERE (ho_ten LIKE ? OR user.username LIKE ?) 
              AND don_hang.status = 'Đã xác nhận'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_donhang_by_id($id)
{
    global $conn;
    $query = "SELECT don_hang.*, don_hang.id as id_dh, user.*
              FROM don_hang 
              JOIN user ON user.id = don_hang.user_id 
              WHERE don_hang.id = ? AND don_hang.status = 'Đã xác nhận'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}