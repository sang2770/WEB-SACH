<?php

function get_phieuxuat($search, $limit, $offset) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT phieuxuat.*, user.* 
              FROM phieuxuat 
              JOIN user ON user.id = phieuxuat.nguoi_tao 
              join role on role.id = user.role_id
              WHERE user.role_id != 6 and ( ma_px LIKE ? OR user.username LIKE ?)
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssii', $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_hoadon($search, $limit, $offset) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT phieuxuat.*, user.* 
              FROM phieuxuat 
              JOIN user ON user.id = phieuxuat.nguoi_tao 
              join role on role.id = user.role_id
              WHERE user.role_id = 6 and (ma_px LIKE ? OR user.username LIKE ?)
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssii', $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_total_hoadon($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM phieuxuat JOIN user ON user.id = phieuxuat.nguoi_tao 
                         join role on role.id = user.role_id
               WHERE user.role_id = 6 and ( ma_px LIKE ? or user.username LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function get_total_phieuxuat($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM phieuxuat JOIN user ON user.id = phieuxuat.nguoi_tao 
                         join role on role.id = user.role_id
               WHERE user.role_id != 6 and ( ma_px LIKE ? or user.username LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function setStatus_phieuxuat($id, $status = 1) {
    global $conn;
    $query = "UPDATE phieunhap SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
}

function get_sach_by_phieuxuat($ma_pn) {
    global $conn;
    $query = "SELECT chi_tiet_phieu_xuat.*, FORMAT(chi_tiet_phieu_xuat.gia, 'N0') as 'gia_ban', FORMAT(sach.gia, 'N0') as von, sach.ten_sach, donvitinh.* 
    FROM chi_tiet_phieu_xuat
    join sach on sach.ma_sach = chi_tiet_phieu_xuat.ma_sach
    join phieuxuat on phieuxuat.ma_px = chi_tiet_phieu_xuat.ma_px
    join donvitinh on donvitinh.ma_dvt = sach.ma_dvt WHERE chi_tiet_phieu_xuat.ma_px = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $ma_pn);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


function xac_nhan_phieu_xuat($id) {
    global $conn;
    $query = "UPDATE phieunhap SET trang_thai = 2 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function huy_phieu_xuat($id) {
    global $conn;
    $query = "UPDATE phieunhap SET trang_thai = 3 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function get_phieuxuatall($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT phieunhap.*, user.*, nhacungcap.ten_ncc 
              FROM phieunhap 
              JOIN user ON user.id = phieunhap.nguoi_tao 
              JOIN nhacungcap ON nhacungcap.ma_ncc = phieunhap.ma_ncc 
              WHERE (ma_pn LIKE ? OR nhacungcap.ma_ncc LIKE ? OR user.username LIKE ? OR nhacungcap.ten_ncc LIKE ?) 
              AND phieunhap.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function get_phieuxuat_by_id($id) {
    global $conn;
    $query = "SELECT phieuxuat.*, user.*
              FROM phieuxuat 
              JOIN user ON user.id = phieuxuat.nguoi_tao 
              WHERE phieuxuat.ma_px = ? AND phieuxuat.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}