<?php

function get_phieunhap($search, $limit, $offset) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT phieunhap.*, user.*, nhacungcap.ten_ncc FROM phieunhap 
              JOIN user ON user.id = phieunhap.nguoi_tao 
              JOIN nhacungcap ON nhacungcap.ma_ncc = phieunhap.ma_ncc 
              WHERE ma_pn LIKE ? OR nhacungcap.ma_ncc LIKE ?  OR user.username LIKE ? OR nhacungcap.ten_ncc LIKE ?
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssii', $search, $search, $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_total_phieunhap($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM phieunhap JOIN user ON user.id = phieunhap.nguoi_tao 
              JOIN nhacungcap ON nhacungcap.ma_ncc = phieunhap.ma_ncc WHERE ma_pn LIKE ? OR phieunhap.ma_ncc LIKE ? or user.username LIKE ? or nhacungcap.ten_ncc LIKE ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function setStatus_phieunhap($id, $status = 1) {
    global $conn;
    $query = "UPDATE phieunhap SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
}

function get_sach_by_phieunhap($ma_pn) {
    global $conn;
    $query = "SELECT chi_tiet_phieu_nhap.*, FORMAT(sach.gia, 'N0') as gia_ban, FORMAT(chi_tiet_phieu_nhap.gia, 'N0') as gia_nhap, sach.ten_sach, donvitinh.* FROM chi_tiet_phieu_nhap 
    join sach on sach.ma_sach = chi_tiet_phieu_nhap.ma_sach
                                                  join donvitinh on donvitinh.ma_dvt = sach.ma_dvt
                                                  WHERE ma_pn = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $ma_pn);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


function xac_nhan_phieu_nhap($id) {
    global $conn;
    $query = "UPDATE phieunhap SET trang_thai = 2 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function huy_phieu_nhap($id) {
    global $conn;
    $query = "UPDATE phieunhap SET trang_thai = 3 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    return $stmt->execute();
}

function get_phieunhapall($search) {
    global $conn;
    $search = "%$search%";
    $query = "SELECT phieunhap.*, user.*, nhacungcap.ten_ncc 
              FROM phieunhap 
              JOIN user ON user.id = phieunhap.nguoi_tao 
              JOIN nhacungcap ON nhacungcap.ma_ncc = phieunhap.ma_ncc 
              WHERE (ma_pn LIKE ? OR nhacungcap.ma_ncc LIKE ? OR user.username LIKE ? OR nhacungcap.ten_ncc LIKE ?) 
              AND phieunhap.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function get_phieunhap_by_id($id) {
    global $conn;
    $query = "SELECT phieunhap.*, user.*, nhacungcap.ten_ncc 
              FROM phieunhap 
              JOIN user ON user.id = phieunhap.nguoi_tao 
              JOIN nhacungcap ON nhacungcap.ma_ncc = phieunhap.ma_ncc 
              WHERE phieunhap.ma_pn = ? AND phieunhap.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}