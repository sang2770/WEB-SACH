<?php
function getRoleSelect() {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM role");
    $roles = array();
    $stmt->execute();
    $results =  $stmt->get_result();
    while ($row = $results->fetch_assoc()) {
        $item = array(
            'key' => $row['id'],
            'value' => $row['name']
        );
        $roles[] = $item;
    }
    return $roles;
}

function getRoles()
{
    global $conn;
    $stmt = $conn->prepare("SELECT role.name, COUNT(user.id) as user_count
FROM role
LEFT JOIN user ON role.id = user.role_id
GROUP BY role.name;
");
    $stmt->execute();
    $results =  $stmt->get_result();
    $roles = array();
    while ($row = $results->fetch_assoc()) {
        $roles[] = $row;
    }
    return $roles;
}

function getCurrentRole($user_id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT role.id FROM role LEFT JOIN user ON role.id = user.role_id WHERE user.id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['id'];
}