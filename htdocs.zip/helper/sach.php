<?php
// Start of Selection
function get_sach($search, $limit, $offset) {
    global $conn;
    $query = "SELECT * FROM sach WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (
                        ten_sach LIKE '%$search%'
                        OR ma_sach LIKE '%$search%' 
                        OR ma_tg LIKE '%$search%'
                        OR ma_tl LIKE '%$search%'
                        OR ma_nxb LIKE '%$search%'
                        OR ma_ngan LIKE '%$search%'
                        OR ma_km LIKE '%$search%'
                        OR ma_dvt LIKE '%$search%'
                        OR ten_sach LIKE '%$search%')";
    }
    $query .= " ORDER BY id DESC LIMIT ?, ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return array();
    }
    $stmt->bind_param('ii', $offset, $limit);
    $stmt->execute();
    $results = $stmt->get_result();
    $sachs = array();
    while ($row = $results->fetch_assoc()) {
        $sachs[] = $row;
    }
    return $sachs;
}


function get_total_sach($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM sach WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (
                        ten_sach LIKE '%$search%' 
                        OR ma_sach LIKE '%$search%' 
                        OR ma_tg LIKE '%$search%'
                        OR ma_tl LIKE '%$search%'
                        OR ma_nxb LIKE '%$search%'
                        OR ma_ngan LIKE '%$search%'
                        OR ma_km LIKE '%$search%'
                        OR ma_dvt LIKE '%$search%'
                        OR ten_sach LIKE '%$search%')";
    }
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return 0;
    }
    $stmt->execute();
    $results = $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];
}


function set_status_sach($id, $status = 1)
{
    global $conn;
    $query = "UPDATE sach SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}


function get_sach_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM sach WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}


function get_sach_by_name($name)
{
    global $conn;
    $query = "SELECT * FROM sach WHERE ten_sach = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}

function create_sach($ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $hinh_anh)
{
    global $conn;
    $query = "INSERT INTO sach (ma_tg, so_luong, ma_tl, ma_nxb, ma_ngan, ma_km, ma_dvt, gia, ten_sach, hinh_anh) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    // Chỉnh sửa chuỗi định nghĩa loại để khớp với số lượng tham số
    $stmt->bind_param('sisssssdss', $ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $hinh_anh);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE sach SET ma_sach = 'BOOK$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $id;
}


function update_sach($id, $ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $hinh_anh)
{
    global $conn;
    $query = "UPDATE sach SET ma_tg = ?, so_luong = ?, ma_tl = ?, ma_nxb = ?, ma_ngan = ?, ma_km = ?, ma_dvt = ?, gia = ?, ten_sach = ?, hinh_anh = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    // Điều chỉnh số lượng và thứ tự tham số trong bind_param để khớp với câu lệnh SQL
    $stmt->bind_param('sisssssdssi', $ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $hinh_anh, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}
?>