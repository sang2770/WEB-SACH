<?php
function get_tuke($search, $limit, $offset) {
    global $conn;
    $query = "SELECT * FROM tuke";
    if (!empty($search)) {
        $query .= " WHERE ma_tuke LIKE '%$search%' 
                        OR ten_tuke LIKE '%$search%' 
                        OR trang_thai LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $query .= " ORDER BY id DESC LIMIT $offset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $tuke = array();
    while ($row = $results->fetch_assoc()) {
        $tuke[] = $row;
    }
    return $tuke;
}

function get_total_tuke($search = "") {
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM tuke";
    if (!empty($search)) {
        $query .= " WHERE ma_tuke LIKE '%$search%' 
                        OR ten_tuke LIKE '%$search%' 
                        OR trang_thai LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];
}

function setStatus_tuke($id, $status = 1) {
    global $conn;
    $stmt = $conn->prepare("UPDATE tuke SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
}

function create_tuke($ten_tuke, $trang_thai) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO tuke (ten_tuke, trang_thai) VALUES (?, ?)");
    $stmt->bind_param("ss", $ten_tuke, $trang_thai);
    $stmt->execute();
    $id = $conn->insert_id;
    $ma_tuke = "TK$id";
    $stmt = $conn->prepare("UPDATE tuke SET ma_tuke = ? WHERE id = ?");
    $stmt->bind_param("si", $ma_tuke, $id);
    $stmt->execute();
    return $id;
}

function get_tuke_by_name($name) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tuke WHERE ma_tuke = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}

function get_tuke_by_id($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tuke WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}

function update_tuke_by_id($id, $ten_tuke, $trang_thai) {
    global $conn;
    $stmt = $conn->prepare("UPDATE tuke SET ten_tuke = ?, trang_thai = ? WHERE id = ?");
    $stmt->bind_param("ssi", $ten_tuke, $trang_thai, $id);
    $stmt->execute();
}

function get_tuke_list() {
    global $conn;
    $query = "SELECT ma_tuke, ten_tuke FROM tuke WHERE is_active = 1 ORDER BY ten_tuke ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $tuke_list = array();
    while ($row = $results->fetch_assoc()) {
        $item = array(
            'key' => $row['ma_tuke'],
            'value' => $row['ten_tuke']
        );
        $tuke_list[] = $item;
    }
    return $tuke_list;
}
?>