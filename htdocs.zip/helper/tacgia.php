<?php
function get_tacgia($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM tacgia WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (ma_tg LIKE '%$search%' 
                        OR ten_tg LIKE '%$search%' 
                        OR mo_ta LIKE '%$search%')";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $tacgia = array();
    while ($row = $results->fetch_assoc()) {
        $tacgia[] = $row;
    }
    return $tacgia;
}

function get_total_tacgia($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM tacgia WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (ma_tg LIKE '%$search%' 
                        OR ten_tg LIKE '%$search%' 
                        OR mo_ta LIKE '%$search%')";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];
}

function setStatusTG($id, $status = 1)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE tacgia SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
}

function create_tg($ten_tg, $mo_ta)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO tacgia (ten_tg, mo_ta) VALUES (?, ?)");
    $stmt->bind_param("ss", $ten_tg, $mo_ta);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE tacgia SET ma_tg = 'TG$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $id;
}

function get_tg_by_name($name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tacgia WHERE ten_tg = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->num_rows > 0;
}

function get_tg_by_id($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tacgia WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $results =  $stmt->get_result();
    return $results->fetch_object();
}

function update_tg_by_id($id, $ten_tg, $mo_ta)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE tacgia SET ten_tg = ?, mo_ta = ? WHERE id = ?");
    $stmt->bind_param("ssi", $ten_tg, $mo_ta, $id);
    $stmt->execute();
}