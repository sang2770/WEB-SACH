<?php
function showAlert()
{
    $message = $_SESSION['message']['name'];
    $type = $_SESSION['message']['type'];
    echo "<div class='custom-alert-message alert alert-$type alert-dismissible tada show mx-2 mt-1' role='alert'>
            " . $message . "
        </div>";
}

function setMessage($type, $message)
{
    $_SESSION['message'] = [
        'name' => $message,
        'type' => $type,
    ];
}

function setSession($key, $value)
{
    $_SESSION[$key] = $value;
}

function getSession($key)
{
    if (isset($_SESSION[$key])) {
        return $_SESSION[$key];
    }
    return null;
}

function redirectTo($url)
{
    header("Location: $url");
    exit();
}

function redirectToSelf()
{
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

function genderSelect($id, $name, $label, $options = array(), $selected = "")
{
    // Nếu không có giá trị mặc định được chọn, lấy giá trị đầu tiên làm mặc định
    if (empty($selected) && !empty($options)) {
        $selected = $options[0]['key'];
    }

    echo '<label class="form-label" for="' . $id . '">' . $label . '</label>';
    echo '<select class="form-select" id="' . $id . '" name="' . $name . '">';
    foreach ($options as $option) {
        $key = $option['key'];
        $value = $option['value'];
        // Kiểm tra nếu key của tùy chọn hiện tại bằng với giá trị được chọn
        $isSelected = $key == $selected ? "selected" : "";
        echo "<option value='$key' $isSelected>$value</option>";
    }
    echo '</select>';
}

function getValue($val)
{
    return $val ?? null;
}

function renderButtonChange($name1, $value1, $name2, $value2, $label, $type)
{
    echo "<form method='POST'>";
    echo "<input type='hidden' name='$name1' value='$value1' hidden>";
    echo "<input type='hidden' name='$name2' value='$value2' hidden>";
    echo "<button type='submit' class='btn btn-primary btn-sm btn-$type'>$label</button>";
    echo "</form>";
}

function get_select_list($ma, $ten, $table)
{
    global $conn;
    $query = "SELECT $ma, $ten FROM $table WHERE is_active = 1 ORDER BY id ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $list = array();
    while ($row = $results->fetch_assoc()) {
        $item = array(
            'key' => $row[$ma],
            'value' => $row[$ten],
            'gia' => $row['gia'] ?? null
        );
        $list[] = $item;
    }
    return $list;
}

function get_khuyenmai_no_expired_and_number_gt_1()
{
    global $conn;
    $query = "SELECT * FROM khuyenmai WHERE is_active = 1 AND so_luong > 1";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $khuyenmai_list = array();
    while ($row = $results->fetch_assoc()) {
        if (strtotime($row['ngay_bat_dau']) <= time() && strtotime($row['ngay_ket_thuc']) >= time()) {
            $item = array(
                'key' => $row['id'] . '-' . $row['phan_tram_giam_gia'],
                'value' => $row['ten_km'] . ' - ' . $row['phan_tram_giam_gia'] . '%'
            );
            $khuyenmai_list[] = $item;
        }
    }
    return $khuyenmai_list;
}


function get_full_sach()
{
    global $conn;
    $query = "SELECT ma_sach, ten_sach, gia FROM sach";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $sach_list = array();
    while ($row = $result->fetch_assoc()) {
        $sach_list[] = $row;
    }
    return $sach_list;
}





function gen_more($str, $length)
{
    $sub = strlen($str) > $length ? substr($str, 0, 200) . " ..." : $str;
    return $sub;
}