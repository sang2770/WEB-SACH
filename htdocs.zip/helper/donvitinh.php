<?php
function get_donvitinh($search, $limit, $offset) {
    global $conn;
    $query = "SELECT * FROM donvitinh";
    if (!empty($search)) {
        $query .= " WHERE ma_dvt LIKE '%$search%' 
                            or ten_dvt LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $query .= " ORDER BY id DESC LIMIT $offset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $donvitinh = array();
    while ($row = $results->fetch_assoc()) {
        $donvitinh[] = $row;
    }
    return $donvitinh;
}

function get_total_donvitinh($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM donvitinh";
    if (!empty($search)) {
        $query .= " WHERE ma_dvt LIKE '%$search%' 
                            or ten_dvt LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];

}

function setStatusDVT($id, $status = 1)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE donvitinh SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
}

function create_dvt($ten_dvt)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO donvitinh (ten_dvt) VALUES (?)");
    $stmt->bind_param("s", $ten_dvt);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE donvitinh SET ma_dvt = 'DVT$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->insert_id;

}

function get_dvt_by_name($name)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM donvitinh WHERE ten_dvt = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}

function get_dvt_by_id($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM donvitinh WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}

function update_dvt_by_id($id, $ten_dvt)
{
    global $conn;
    $stmt = $conn->prepare("UPDATE donvitinh SET ten_dvt = ? WHERE id = ?");
    $stmt->bind_param("si", $ten_dvt, $id);
    $stmt->execute();
}