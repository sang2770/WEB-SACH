<?php
function get_khuyenmai($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM khuyenmai";
    if (!empty($search)) {
        $query .= " WHERE ma_km LIKE '%$search%' 
                        or ten_km LIKE '%$search%'
                        or mo_ta LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $gias = array();
    while ($row = $results->fetch_assoc()) {
        $gias[] = $row;
    }
    return $gias;
}


function get_total_khuyenmai($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM khuyenmai";
    if (!empty($search)) {
        $query .= " WHERE ma_km LIKE '%$search%' 
                        or ten_km LIKE '%$search%'
                        or mo_ta LIKE '%$search%'";
    }
    $query .= " WHERE is_active = 1";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];

}


function set_status_khuyenmai($id, $status = 1)
{
    global $conn;
    $query = "UPDATE khuyenmai SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}


function get_khuyenmai_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM khuyenmai WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}


function get_khuyenmai_by_name($name)
{
    global $conn;
    $query = "SELECT * FROM khuyenmai WHERE ten_km = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}


function create_khuyenmai($ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta): bool
{
    global $conn;
    // Chuẩn bị câu lệnh SQL để chèn dữ liệu mới vào bảng khuyenmai
    $query = "INSERT INTO khuyenmai (ten_km, ngay_bat_dau, ngay_ket_thuc, phan_tram_giam_gia, so_luong, mo_ta) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    // Kiểm tra xem câu lệnh chuẩn bị có thành công hay không
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }

    // Gán các tham số cho câu lệnh SQL
    $stmt->bind_param('sssdis', $ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta);

    // Thực thi câu lệnh SQL
    $stmt->execute();

    // Lấy ID cuối cùng được chèn vào bảng
    $insert_id = $conn->insert_id;

    // Chuẩn bị câu lệnh SQL để cập nhật mã khuyến mãi
    $stmt->prepare("UPDATE khuyenmai SET ma_km = ? WHERE id = ?");
    $var1 = "KM" . $insert_id;

    // Gán các tham số cho câu lệnh SQL
    $stmt->bind_param('si', $var1, $insert_id);

    // Thực thi câu lệnh SQL
    $stmt->execute();

    // Trả về ID cuối cùng được chèn vào bảng
    return $insert_id;
}

function update_khuyenmai($id, $ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta)
{
    global $conn;
    $query = "UPDATE khuyenmai SET ten_km = ?, ngay_bat_dau = ?, ngay_ket_thuc = ?, phan_tram_giam_gia = ?, so_luong = ?, mo_ta = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('sssdisi', $ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}
?>