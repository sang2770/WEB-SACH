<?php


function get_hoadon($search, $limit, $offset)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT hoa_don.*, hoa_don.id as id_hd, user.* , user.id as user_id
              FROM hoa_don 
              JOIN user ON user.id = hoa_don.nguoi_tao 
              join role on role.id = user.role_id
              WHERE role.id != 6 AND (ma_hoadon LIKE ? OR user.username LIKE ?)
              LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssii', $search, $search, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_total_hoadon($search)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT COUNT(*) as total FROM hoa_don JOIN user ON user.id = hoa_don.nguoi_tao 
                         join role on role.id = user.role_id
               WHERE user.role_id != 6 and ( ma_hoadon LIKE ? or user.username LIKE ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

function setStatus_phieuxuat($id, $status = 1)
{
    global $conn;
    $query = "UPDATE phieunhap SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
}

function get_sach_by_hoadon($id)
{
    global $conn;
    $query = "SELECT chi_tiet_hoa_don.*, FORMAT(chi_tiet_hoa_don.gia, 'N0') as 'gia_ban', FORMAT(sach.gia, 'N0') as von, sach.ten_sach, donvitinh.* 
    FROM chi_tiet_hoa_don
    join sach on sach.ma_sach = chi_tiet_hoa_don.ma_sach
    join hoa_don on hoa_don.id = chi_tiet_hoa_don.id_hoadon
    join donvitinh on donvitinh.ma_dvt = sach.ma_dvt WHERE chi_tiet_hoa_don.id_hoadon = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


function get_hoadonall($search)
{
    global $conn;
    $search = "%$search%";
    $query = "SELECT hoa_don.*,hoa_don.id as id_hoadon, user.*
              FROM hoa_don 
              JOIN user ON user.id = hoa_don.nguoi_tao 
              WHERE (ma_hoadon LIKE ? OR user.username LIKE ?) 
              AND hoa_don.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function get_hoadon_by_id($id)
{
    global $conn;
    $query = "SELECT hoa_don.*,hoa_don.id as id_hoadon, user.*
              FROM hoa_don 
              JOIN user ON user.id = hoa_don.nguoi_tao 
              WHERE hoa_don.id = ? AND hoa_don.trang_thai = 2";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}