<?php
function get_danhmuc($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM danhmuc WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (ma_dm LIKE '%$search%' 
                        OR ten_dm LIKE '%$search%')";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $danhmucs = array();
    while ($row = $results->fetch_assoc()) {
        $danhmucs[] = $row;
    }
    return $danhmucs;
}


function get_total_danhmuc($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM danhmuc WHERE is_active = 1";
    if (!empty($search)) {
        $query .= " AND (ma_dm LIKE '%$search%' 
                        OR ten_dm LIKE '%$search%')";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];
}


function set_status_danhmuc($id, $status = 1)
{
    global $conn;
    $query = "UPDATE danhmuc SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}


function get_danhmuc_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM danhmuc WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}


function get_danhmuc_by_name($name)
{
    global $conn;
    $query = "SELECT * FROM danhmuc WHERE ten_dm = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}


/**
 * Create a new danh muc entry in the database.
 *
 * @param string $ten_dm
 * @return bool|int
 */
function create_danhmuc($ten_dm)
{
    global $conn;
    $query = "INSERT INTO danhmuc (ten_dm) VALUES (?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s',$ten_dm);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE danhmuc SET ma_dm = 'DM$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->insert_id;
}


/**
 * Update an existing danh muc entry in the database by id.
 *
 * @param int $id
 * @param string $ten_dm
 * @return bool
 */
function update_danhmuc($id, $ten_dm)
{
    global $conn;
    $query = "UPDATE danhmuc SET ten_dm = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('si', $ten_dm, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}

function get_danhmuc_list() {
    global $conn;
    $query = "SELECT ma_dm, ten_dm FROM danhmuc WHERE is_active = 1 ORDER BY ten_dm ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results = $stmt->get_result();
    $danhmuc_list = array();
    while ($row = $results->fetch_assoc()) {
        $item = array(
            'key' => $row['ma_dm'],
            'value' => $row['ten_dm']
        );
        $danhmuc_list[] = $item;
    }
    return $danhmuc_list;
}