<?php
session_start();
include "helper/common.php";
include_once "helper/user.php";
// Xử lý khi form được submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $matkhau = $_POST["matkhau"];
    $username = $_POST["username"];
    $confirm_matkhau = $_POST["confirm_matkhau"];
    if (strlen($username) < 6) {
        setMessage('danger', 'Tên ngừoi dùng phải lớn hơn 6 ký tự!');
        redirectToSelf();
    }
    if (strlen($matkhau) < 6) {
        setMessage('danger', 'Mật Khẩu phải lớn hơn 6 ký tự!');
        redirectToSelf();
    }
    if ($matkhau != $confirm_matkhau) {
        setMessage("danger", "Mật khẩu không khớp!");
        redirectToSelf();
    }
    if (isUserExisted($email, $username)) {
        setMessage('danger', 'Username hoặc email đã tồn tại!');
        redirectToSelf();
    }
    createUser($username, $email, md5($matkhau));
}
include 'header.php';
// Đóng kết nối
?>

    <div class="card p-lg-5 w-50 mx-auto mt-5">
    <div class="container">
        <h2 class="mt-5">Đăng ký người dùng</h2>
        <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Tên người dùng:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="matkhau">Mật khẩu:</label>
                    <input type="password" class="form-control" id="matkhau" name="matkhau" required>
                </div>
                <div class="form-group">
                    <label for="confirm_matkhau">Xác nhận mật khẩu:</label>
                    <input type="password" class="form-control" id="confirm_matkhau" name="confirm_matkhau" required>
                </div>
                <button type="submit" class="btn btn-primary mt-1">Đăng ký</button>
            <div>
                <span>Bạn đã có tài khoản rồi?</span><a href="login.php">Đăng nhập</a> <br>
                <span>Bạn quên mật khẩu?</span><a href="forgot_password.php">Quên mật khẩu</a>
            </div>
            </form>
    </div>
    </div>

<?php include 'footer.php'; ?>