<?php

function getAPIData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}

$type = isset($_GET['type']) ? $_GET['type'] : '';
$response = [];

switch ($type) {
    case 'district':
        if (isset($_GET['province_id'])) {
            $province_id = $_GET['province_id'];
            $response = getAPIData("https://vapi.vnappmob.com/api/province/district/$province_id");
        }
        break;

    case 'ward':
        if (isset($_GET['district_id'])) {
            $district_id = $_GET['district_id'];
            $response = getAPIData("https://vapi.vnappmob.com/api/province/ward/$district_id");
        }
        break;

    default:
        http_response_code(400);
        $response = ['error' => 'Invalid request'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>