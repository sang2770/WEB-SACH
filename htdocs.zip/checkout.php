<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

if (!isLogined()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Lấy danh sách sách từ giỏ hàng
$sql = "SELECT cart.ma_sach, cart.so_luong, sach.ten_sach, sach.gia, (cart.so_luong * sach.gia) AS thanh_tien 
        FROM cart 
        JOIN sach ON cart.ma_sach = sach.ma_sach 
        WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total += $row['thanh_tien'];
}

$stmt->close();
?>

<?php require_once 'header.php'; ?>

<div class="container mt-3">
    <h2>Giỏ hàng của bạn</h2>
    <?php if (empty($cart_items)) : ?>
        <p>Giỏ hàng của bạn đang rỗng!</p>
    <?php else : ?>
        <form id="checkout-form" action="pre-checkout.php" method="GET">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Tên sách</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Giá</th>
                    <th scope="col">Thành tiền</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($cart_items as $item) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['ten_sach']); ?></td>
                        <td>
                            <input type="number" name="so_luong[<?php echo $item['ma_sach']; ?>]"
                                   class="form-control quantity"
                                   value="<?php echo htmlspecialchars($item['so_luong']); ?>"
                                   min="1" data-price="<?php echo $item['gia']; ?>"
                                   data-subtotal="subtotal-<?php echo $item['ma_sach']; ?>"
                                   data-ma-sach="<?php echo $item['ma_sach']; ?>">
                        </td>
                        <td><?php echo number_format($item['gia'], 0, ',', '.'); ?> VND</td>
                        <td id="subtotal-<?php echo $item['ma_sach']; ?>"><?php echo number_format($item['thanh_tien'], 0, ',', '.'); ?> VND</td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3" class="text-right"><strong>Tổng cộng:</strong></td>
                    <td><strong id="total"><?php echo number_format($total, 0, ',', '.'); ?> VND</strong></td>
                </tr>
                </tbody>
            </table>

            <button type="submit" class="btn btn-primary mt-3">Thanh toán</button>
        </form>
        <button type="button" class="btn btn-danger mt-3" id="cancel-button" onclick="deleteCart()">Hủy</button>


        <script>
            function deleteCart() {
                fetch('delete_cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Giỏ hàng đã được xóa.');
                        location.reload();
                    } else {
                        alert('Có lỗi xảy ra khi xóa giỏ hàng.');
                    }
                });
            }
        </script>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const quantityInputs = document.querySelectorAll('.quantity');

        quantityInputs.forEach(input => {
            input.addEventListener('change', function() {
                const pricePerUnit = parseFloat(this.dataset.price);
                const quantity = parseInt(this.value);
                const subtotalElement = document.getElementById(this.dataset.subtotal);
                const newSubtotal = pricePerUnit * quantity;

                subtotalElement.textContent = newSubtotal.toLocaleString('vi-VN', {style: 'currency', currency: 'VND'});

                // Update the total
                updateTotal();

                // Save the new quantity to the cart
                const maSach = this.dataset.maSach;
                saveQuantityToCart(maSach, quantity);
            });
        });

        function updateTotal() {
            let total = 0;
            quantityInputs.forEach(input => {
                const quantity = parseInt(input.value);
                const pricePerUnit = parseFloat(input.dataset.price);
                total += quantity * pricePerUnit;
            });

            document.getElementById('total').textContent = total.toLocaleString('vi-VN', {style: 'currency', currency: 'VND'});
        }

        function saveQuantityToCart(maSach, quantity) {
            fetch('update_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ ma_sach: maSach, so_luong: quantity })
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    alert('Có lỗi xảy ra khi cập nhật giỏ hàng.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        document.getElementById('checkout-form').addEventListener('submit', function (event) {
            event.preventDefault();
            
            window.location.href = '/pre-checkout.php';
        });
    });
</script>