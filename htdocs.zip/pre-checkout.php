<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

// Kiểm tra người dùng đã đăng nhập
if (!isLogined()) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];

function getAPIData($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}

// Lấy danh sách tỉnh/thành phố
$cities = getAPIData("https://vapi.vnappmob.com/api/province");

// Lấy danh sách sách từ giỏ hàng
$sql = "SELECT cart.ma_sach, cart.so_luong, sach.ten_sach, sach.gia, (cart.so_luong * sach.gia) AS thanh_tien 
        FROM cart 
        JOIN sach ON cart.ma_sach = sach.ma_sach 
        WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total += $row['thanh_tien'];
}

$stmt->close();
if (empty($cart_items)) {
    echo "<p>Giỏ hàng của bạn đang rỗng!</p>";
    header('Location: checkout.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">

<?php require_once 'header.php'; ?>

    <div class="checkout-container" style="margin: 20px auto; width: 60%; padding: 20px; border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
    <h2>Thanh toán đơn hàng</h2>
    <hr/>
        
    <form action="process_checkout.php" method="POST">
            <h3>Thông tin liên hệ</h3>
            <div class="form-group mb-3">
                <label for="ho_ten">Họ tên</label>
                <input type="text" class="form-control" id="ho_ten" name="ho_ten" required>
            </div>
            <div class="form-group mb-3">
                <label for="sdt">Số điện thoại</label>
                <input type="text" class="form-control" id="sdt" name="sdt" required>
            </div>
            <div class="form-group mb-3">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group mb-3">
                <label for="tinh">Tỉnh/Thành phố</label>
                <select class="form-control" id="tinh" name="tinh" required>
                    <option value="">Chọn Tỉnh/Thành phố</option>
                    <?php foreach ($cities['results'] as $city): ?>
                        <option value="<?php echo $city['province_id']; ?>"
                            data-province_name="<?php echo $city['province_name']; ?>"><?php echo $city['province_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="huyen">Huyện/Quận</label>
                <select class="form-control" id="huyen" name="huyen" required>
                    <option value="">Chọn Huyện/Quận</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="xa">Xã/Phường</label>
                <select class="form-control" id="xa" name="xa" required>
                    <option value="">Chọn Xã/Phường</option>
                </select>
            </div>
            <input type="hidden" id="tinh_name" name="tinh_name">
            <input type="hidden" id="huyen_name" name="huyen_name">
            <input type="hidden" id="xa_name" name="xa_name">
            <div class="form-group mb-3">
                <label for="dia_chi">Địa chỉ chi tiết</label>
                <textarea class="form-control" id="dia_chi" name="dia_chi" rows="3" required></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="ghi_chu">Ghi chú</label>
                <textarea class="form-control" id="ghi_chu" name="ghi_chu" rows="3"></textarea>
            </div>

            <h3>Thông tin giỏ hàng</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Đơn giá</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['ten_sach']) ?></td>
                            <td><?= $item['so_luong'] ?></td>
                            <td><?= number_format($item['gia'], 2) ?> VND</td>
                            <td><?= number_format($item['so_luong'] * $item['gia'], 2) ?> VND</td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3"><strong>Tổng tiền:</strong></td>
                        <td><strong><?= number_format($total, 2) ?> VND</strong></td>
                    </tr>
                </tbody>
            </table>

            <button type="submit" class="btn btn-primary mt-3">Xác nhận đơn hàng</button>
        </form>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const huyenSelect = document.getElementById('huyen');
            const xaSelect = document.getElementById('xa');

            document.getElementById('tinh').addEventListener('change', function () {
                const provinceId = this.value;
                const provinceName = this.options[this.selectedIndex].getAttribute('data-province_name');
                document.getElementById('tinh_name').value = provinceName;
                fetch('get_data.php?type=district&province_id=' + provinceId)
                    .then(response => response.json())
                    .then(data => {
                        huyenSelect.innerHTML = '<option value="">Chọn Huyện/Quận</option>';
                        xaSelect.innerHTML = '<option value="">Chọn Xã/Phường</option>';
                        data.results.forEach(district => {
                            const option = document.createElement('option');
                            option.value = district.district_id;
                            option.setAttribute('data-district_name', district.district_name);
                            option.text = district.district_name;
                            huyenSelect.add(option);
                        });
                    });
            });

            huyenSelect.addEventListener('change', function () {
                const districtId = this.value;
                const districtName = this.options[this.selectedIndex].getAttribute('data-district_name');
                document.getElementById('huyen_name').value = districtName;
                fetch('get_data.php?type=ward&district_id=' + districtId)
                    .then(response => response.json())
                    .then(data => {
                        xaSelect.innerHTML = '<option value="">Chọn Xã/Phường</option>';
                        data.results.forEach(ward => {
                            const option = document.createElement('option');
                            option.value = ward.ward_id;
                            option.textContent = ward.ward_name;
                            option.setAttribute('data-ward_name', ward.ward_name);
                            xaSelect.add(option);
                        });
                    });
            });

            xaSelect.addEventListener('change', function () {
                const wardName = this.options[this.selectedIndex].getAttribute('data-ward_name');
                document.getElementById('xa_name').value = wardName;
            });
        });
    </script>
<?php require_once 'footer.php'; ?>