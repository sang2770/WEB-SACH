<?php
session_start();
include "helper/common.php";
include_once "helper/user.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    // dang phat trien
}
?>

<?php include 'header.php'; ?>

    <div class="card p-lg-5 w-50 mx-auto mt-5">
        <div class="container">
            <h2 class="mt-5 text-center">Quên mật khẩu</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <button type="submit" class="btn btn-primary mt-1">Gửi yêu cầu khôi phục</button>
            </form>
        </div>
    </div>

<?php include 'footer.php'; ?>