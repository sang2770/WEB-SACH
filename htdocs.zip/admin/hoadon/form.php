<?php
$mode = "insert";
if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $tuke = get_tuke_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <?php if ($mode == "update"): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($tuke->id) ?>" />
                <?php endif; ?>

                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <div class="form-outline mb-4">
                    <input type="text" id="ho_ten" name="ho_ten" class="form-control" />
                    <label class="form-label" for="ho_ten">Họ tên</label>
                </div>
                <!-- Số Điện Thoại -->
                <div class="form-outline mb-4">
                    <input type="text" id="sdt" name="sdt" class="form-control" />
                    <label class="form-label" for="sdt">Số Điện Thoại</label>
                </div>

                <!-- Địa Chỉ -->
                <div class="form-outline mb-4">
                    <input type="text" id="diaChi" name="dia_chi"
                        value="<?= isset($ncc->dia_chi) ? htmlspecialchars($ncc->dia_chi) : null ?>"
                        class="form-control" />
                    <label class="form-label" for="diaChi">Địa Chỉ</label>
                </div>
                <!-- Khuyến Mãi -->
                <div class="form-outline mb-4">
                    <input type="text" id="khuyenmai" name="khuyenmai" class="form-control" placeholder="Nhập khuyến mãi" />
                    <label class="form-label" for="khuyenmai">Khuyến Mãi</label>
                </div>
                <!-- Container for book fields -->
                <div id="books-container">
                    <div class="book-item mb-4">
                        <div class="mb-4">
                            <?= genderSelect("sach", "sach[]", "Sách", get_select_list("ma_sach", "ten_sach", "sach"), null) ?>
                        </div>
                        <input type="number" name="so_luong[]" class="form-control mb-2" placeholder="Số lượng" min="1"
                            required />
                    </div>
                </div>

                <button type="button" class="btn btn-secondary mb-4" id="add-book-button">Thêm sách</button>

                <div class="form-outline mb-4">
                    <label class="form-label" for="tongTien">Tổng Tiền: </label>
                    <span id="tongTien">0</span> VND
                </div>

                <button type="submit"
                    class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm hóa đơn" : "Cập nhật hóa đơn" ?></button>
            </form>
        </div>
    </div>
</div>

<script>
    const sachs = <?php echo json_encode(get_full_sach()); ?>;
    const bookPrices = {};
    const khuyenmaiInput = document.querySelector('input[name="khuyenmai"]');

    sachs.forEach(sach => {
        bookPrices[sach.ma_sach] = sach.gia;
    });

    function updateTotal() {
        let total = 0;
        document.querySelectorAll('.book-item').forEach(item => {
            const select = item.querySelector('select[name="sach[]"]');
            const quantity = item.querySelector('input[name="so_luong[]"]').value;
            const price = bookPrices[select.value] || 0;
            total += price * quantity;
        });

        const discount = parseFloat(khuyenmaiInput.value) || 0;
        
        if (discount) {
            total -= total * (discount / 100);
        }

        document.getElementById('tongTien').textContent = total.toLocaleString();
    }

    document.getElementById('add-book-button').addEventListener('click', function () {
        const booksContainer = document.getElementById('books-container');
        const newBookItem = document.createElement('div');
        newBookItem.classList.add('book-item', 'mb-4');

        newBookItem.innerHTML = `
        <?= genderSelect("sach", "sach[]", "Sách", get_select_list("ma_sach", "ten_sach", "sach"), $tuke->ma_km ?? null) ?>
        <input type="number" name="so_luong[]" class="form-control mb-2" placeholder="Số lượng" min="1" required />
        <button type="button" class="btn btn-danger remove-book-button">Xoá sách</button>
    `;

        booksContainer.appendChild(newBookItem);
        newBookItem.querySelector('select[name="sach[]"]').addEventListener('change', updateTotal);
        newBookItem.querySelector('input[name="so_luong[]"]').addEventListener('input', updateTotal);
    });

    document.addEventListener('click', function (e) {
        if (e.target && e.target.classList.contains('remove-book-button')) {
            e.target.parentElement.remove();
            updateTotal();
        }
    });

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('select[name="sach[]"]').forEach(select => {
            select.addEventListener('change', updateTotal);
        });
        document.querySelectorAll('input[name="so_luong[]"]').forEach(input => {
            input.addEventListener('input', updateTotal);
        });
        khuyenmaiInput.addEventListener('input', updateTotal);
    });
</script>