<?php
global $conn;
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/hoadon.php';
require_once '../../helper/khuyenmai.php'; // Include the khuyenmai helper

if (isset($_GET['status']) && $_GET['status'] == "confirm") {
    $id = $_GET['id_hoadon'];

    $phieu_nhap = get_sach_by_hoadon($id);
    foreach ($phieu_nhap as $pn) {
        $query_book = "UPDATE sach SET so_luong = so_luong - ? WHERE ma_sach = ?";
        $stmt_book = $conn->prepare($query_book);
        $stmt_book->bind_param('is', $pn['so_luong'], $pn['ma_sach']);
        $stmt_book->execute();
    }
    $ma_hoadon = uniqid('HD-');
    $query = "UPDATE hoa_don SET trang_thai = 2, nguoi_cap_nhat = ?, ma_hoadon = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('isi', $user_id, $ma_hoadon, $id);
    $stmt->execute();
    setMessage("success", "Xác nhận hoá đơn thành công");
    redirectTo("index.php");
}

if (isset($_GET['status']) && $_GET['status'] == "cancel") {
    $id = $_GET['id_hoadon'];
    $query = "UPDATE hoa_don SET trang_thai = 3, nguoi_cap_nhat = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('ii', $user_id, $id);
    $stmt->execute();
    setMessage("success", "Huỷ thành công");
    redirectTo("index.php");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_POST['mode'];
    $ho_ten = $_POST['ho_ten'];
    $sdt = $_POST['sdt'];
    $dia_chi = $_POST['dia_chi'];
    $sach = $_POST['sach'];
    $so_luong = $_POST['so_luong'];
    $khuyen_mai = $_POST['khuyenmai']; // Assuming khuyenmai is passed in POST
    $user_id = getSession("user_id");
    $total_price = 0;

    if ($mode === "insert") {
        $query = "INSERT INTO hoa_don (ho_ten, sdt, dia_chi, nguoi_tao, ngay_tao, trang_thai) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $trang_thai = 1;
        $ngay_tao = date('Y-m-d H:i:s');
        $stmt->bind_param('sssiss', $ho_ten, $sdt, $dia_chi, $user_id, $ngay_tao, $trang_thai);
        $stmt->execute();
        $hoadon_id = $stmt->insert_id;

        foreach ($sach as $index => $ma_sach) {
            // Get gia from sach
            $query_get_gia = "SELECT gia FROM sach WHERE ma_sach = ?";
            $stmt_get_gia = $conn->prepare($query_get_gia);
            $stmt_get_gia->bind_param('s', $ma_sach);
            $stmt_get_gia->execute();
            $result = $stmt_get_gia->get_result();
            $row = $result->fetch_assoc();
            $gia = $row['gia'];

            $query_sach = "INSERT INTO chi_tiet_hoa_don (id_hoadon, ma_sach, so_luong, gia) VALUES (?, ?, ?, ?)";
            $stmt_sach = $conn->prepare($query_sach);
            $stmt_sach->bind_param('isii', $hoadon_id, $ma_sach, $so_luong[$index], $gia);
            $stmt_sach->execute();

            // Calculate total price
            $total_price += $gia * $so_luong[$index];
        }

        // Apply discount directly from input
        $discount_percentage = floatval($khuyen_mai);
        $total_price_after_discount = $total_price - ($total_price * $discount_percentage / 100);
        
        // Update total price in hoa_don
        $query_update_total = "UPDATE hoa_don SET tong_tien = ? WHERE id = ?";
        if ($stmt_update_total = $conn->prepare($query_update_total)) {
            $stmt_update_total->bind_param('di', $total_price_after_discount, $hoadon_id);
        } else {
            // Handle error
            die("Error preparing statement: " . $conn->error);
        }
        $stmt_update_total->execute();

        setMessage("success", "Thêm hóa đơn thành công");
    } elseif ($mode === "update") {
        // Update logic here if needed
    }

    redirectTo("index.php");
}
?>