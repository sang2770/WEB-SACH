<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/role.php";
require_once "../../helper/user.php";
require_once "../../helper/khuyenmai.php";
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'tab-table';
?>

<?php require_once "../header.php" ?>
    <div class="container mt-3">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-table" ? "active" : "" ?>" id="tk-tab" data-mdb-toggle="tab" href="#tk" role="tab" aria-controls="tk" aria-selected="true">Khuyến mãi</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-form" ? "active" : "" ?>" id="tk-tab-form" data-mdb-toggle="tab" href="#tk-form" role="tab" aria-controls="tk-form" aria-selected="false">Thêm khuyến mãi</a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade <?= $tab == "tab-table" ? "active show" : "" ?>" id="tk" role="tabpanel" aria-labelledby="tk-tab">
                <?php require_once "table.php" ?>
            </div>
            <div class="tab-pane fade <?= $tab == "tab-form" ? "active show" : "" ?>" id="tk-form" role="tabpanel" aria-labelledby="tk-tab-form">
                <?php require_once "form.php" ?>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>