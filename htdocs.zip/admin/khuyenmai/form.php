<?php
$mode = "insert";
if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $km = get_khuyenmai_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <div class="form-outline mb-4">
                    <input type="text" id="tenkm" name="ten_km" value="<?= isset($km->ten_km) ? htmlspecialchars($km->ten_km) : null ?>" class="form-control" required />
                    <label class="form-label" for="ten_km">Tên khuyến mãi</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="date" id="ngay_bat_dau" name="ngay_bat_dau" value="<?= isset($km->ngay_bat_dau) ? htmlspecialchars($km->ngay_bat_dau) : null ?>" class="form-control" required />
                    <label class="form-label" for="ngay_bat_dau">Ngày bắt đầu</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="date" id="ngay_ket_thuc" name="ngay_ket_thuc" value="<?= isset($km->ngay_ket_thuc) ? htmlspecialchars($km->ngay_ket_thuc) : null ?>" class="form-control" required />
                    <label class="form-label" for="ngay_ket_thuc">Ngày kết thúc</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="number" id="phan_tram_giam_gia" name="phan_tram_giam_gia" value="<?= isset($km->phan_tram_giam_gia) ? htmlspecialchars($km->phan_tram_giam_gia) : null ?>" class="form-control" required />
                    <label class="form-label" for="phan_tram_giam_gia">Phần trăm giảm giá</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="number" id="so_luong" name="so_luong" value="<?= isset($km->so_luong) ? htmlspecialchars($km->phan_tram_giam_gia) : null ?>" class="form-control" required />
                    <label class="form-label" for="so_luong">Số lượng</label>
                </div>
                <div class="form-outline mb-4">
                    <textarea name="mo_ta" id="mota" class="form-control" rows="8"><?= isset($km->mo_ta) ? htmlspecialchars($km->mo_ta) : null ?></textarea>
                    <label class="form-label" for="mota">Mô tả</label>
                </div>

                <?php if ($mode == "update"): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($km->id) ?>"/>
                <?php endif; ?>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm khuyến mãi" : "Lưu khuyến mãi" ?></button>
            </form>
        </div>
    </div>
</div>