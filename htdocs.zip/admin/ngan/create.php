<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/tuke.php';
require_once '../../helper/ngan.php';


if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_ngan = $_POST['ten_ngan'];
    $tinh_trang = $_POST['tinh_trang'];
    $ma_gia= $_POST['ma_gia'];
    if (get_ngan_by_name($ten_ngan)) {
        setMessage("danger", "Ngăn đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_ngan($ten_ngan, $tinh_trang, $ma_gia);
    setMessage("info", "Thêm ngăn thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_ngan = $_POST['ten_ngan'];
    $tinh_trang = $_POST['tinh_trang'];
    $ma_gia = $_POST['ma_gia'];
    update_ngan($id, $ten_ngan, $tinh_trang, $ma_gia);
    setMessage("info", "Cập nhật ngăn thành công!");
    redirectTo("index.php");
}
?>