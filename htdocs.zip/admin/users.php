<?php
session_start();
require_once '../helper/common.php';
require_once '../helper/user.php';
require_once '../helper/role.php';
$allow = [1,2];
$role_id = getCurrentRole(getSession('user_id'));
if (!in_array($role_id, $allow)) {
    redirectTo("/admin/index.php");
}
?>

<?php

if (isset($_POST['deactivate'])) {
    $user_id = $_POST['user_id'];
    setActive($user_id, 0);
    setMessage("info", "Đã vô hiệu hoá người dùng!");
}

if (isset($_POST['activate'])) {
    $user_id = $_POST['user_id'];
    setActive($user_id, 1);
    setMessage("info", "Người dùng đã hoạt động!");
}

if (isset($_POST['role-select'])) {
    $role_id = $_POST['role-select'];
    $user_id = $_POST['userid'];
    setRole($user_id, $role_id);
    setMessage("info", "Thay đổi quyền thành công!");
}

$search = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;

$totalRecords = getUserCount($search);
$totalPages = ceil($totalRecords / $limit);
$users = getUserList($search, $limit, $offset);
$roles = getRoleSelect();
$role_data = getRoles();
require_once 'header.php';
?>

<div class="container mt-3">
    <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="home-tab" data-mdb-toggle="tab" href="#users" role="tab" aria-controls="users" aria-selected="true">Người dùng</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="profile-tab" data-mdb-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Quyền</a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade show active" id="users" role="tabpanel" aria-labelledby="home-tab">
            <?php require_once 'user_table.php'; ?>
        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <?php require_once 'role_table.php'; ?>
        </div>
    </div>
</div>
<script>
    const setRole = (userid, username) => {
        $('#username').val(username);
        $('#userid').val(userid);
    }
</script>
<?php require_once '../footer.php'; ?>