<?php
global $conn;
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/thanhly.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    // Lấy dữ liệu nhà cung cấp và thông tin khác của phiếu nhập
    $nguoi_tao = $_SESSION['user_id']; // Giả định bạn lưu ID người tạo trong session
    $ngay_tao = date("Y-m-d H:i:s");
    $ho_ten = $_POST['ho_ten'];
    $sdt = $_POST['sdt'];
    $dia_chi = $_POST['dia_chi'];
    $ly_do = $_POST['ly_do'];
    $ma_tl = uniqid('TL'); // Tạo mã phiếu thanh lý duy nhất
    try {
        // Lấy danh sách sách cùng với số lượng và giá
        $sach_ids = $_POST['sach'];
        $so_luong = $_POST['so_luong'];
        $gia = $_POST['gia'];

        // Kiểm tra số lượng tồn kho trước khi lưu
        foreach ($sach_ids as $index => $ma_sach) {
            $query_check = "SELECT so_luong FROM sach WHERE ma_sach = ?";
            $stmt_check = $conn->prepare($query_check);
            $stmt_check->bind_param('s', $ma_sach);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            $row_check = $result_check->fetch_assoc();

            if ($row_check['so_luong'] < $so_luong[$index]) {
                throw new Exception("Số lượng tồn kho không đủ cho mã sách: $ma_sach");
            }
        }

        // Thêm dữ liệu vào bảng thanhly
        $query_tl = "INSERT INTO thanhly (nguoi_tao, ngay_tao, ma_tl, ho_ten, sdt, dia_chi, ly_do) VALUES (?, ?, ?, ?,?,?,?)";
        $stmt_tl = $conn->prepare($query_tl);
        if ($stmt_tl === false) {
            throw new Exception($conn->error);
        }
        $stmt_tl->bind_param('sssssss', $nguoi_tao, $ngay_tao, $ma_tl, $ho_ten, $sdt, $dia_chi, $ly_do);
        $stmt_tl->execute();

        // Lấy ID phiếu thanh lý vừa tạo
        $phieu_thanhly_id = $conn->insert_id;

        // Thêm dữ liệu vào bảng chi_tiet_thanh_ly
        $query_ct_tl = "INSERT INTO chi_tiet_thanh_ly (ma_sach, so_luong, gia, ma_tl) VALUES (?, ?, ?, ?)";
        $stmt_ct_tl = $conn->prepare($query_ct_tl);
        if ($stmt_ct_tl === false) {
            throw new Exception($conn->error);
        }

        foreach ($sach_ids as $index => $ma_sach) {
            $current_so_luong = $so_luong[$index];
            $current_gia = (int) $gia[$index];
            $stmt_ct_tl->bind_param('siis', $ma_sach, $current_so_luong, $current_gia, $ma_tl);
            $stmt_ct_tl->execute();
        }

        $conn->commit();
        setMessage("info", "Thêm phiếu thanh lý thành công");
        redirectTo("index.php");
    } catch (Exception $e) {
        $conn->rollback();
        setMessage("danger", "Đã xảy ra lỗi: " . $e->getMessage());
        redirectTo("index.php");
    }
}
if (isset($_GET['status']) && $_GET['status'] == "confirm") {
    $id = $_GET['ma_tl'];

    $phieu_thanhly = get_sach_by_thanhly($id);
    foreach ($phieu_thanhly as $pn) {
        $query_book = "UPDATE sach SET so_luong = so_luong - ? WHERE ma_sach = ?";
        $stmt_book = $conn->prepare($query_book);
        $stmt_book->bind_param('is', $pn['so_luong'], $pn['ma_sach']);
        $stmt_book->execute();
    }
    $query = "UPDATE thanhly SET trang_thai = 2, nguoi_cap_nhat = ? WHERE ma_tl = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('is', $user_id, $id);
    $stmt->execute();
    setMessage("success", "Xác nhận phiếu thanh lý thành công");
    redirectTo("index.php");
}

if (isset($_GET['status']) && $_GET['status'] == "cancel") {
    $id = $_GET['ma_tl'];
    $query = "UPDATE thanhly SET trang_thai = 3, nguoi_cap_nhat = ? WHERE ma_tl = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('is', $user_id, $id);
    $stmt->execute();
    setMessage("success", "Huỷ thành công");
    redirectTo("index.php");
}

?>