<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/tuke.php';
require_once '../../helper/gia.php';


if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_gia = $_POST['ten_gia'];
    $tinh_trang = $_POST['tinh_trang'];
    $ma_tuke = $_POST['ma_tuke'];
    if (get_gia_by_name($ten_gia)) {
        setMessage("danger", "Giá đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_gia($ten_gia, $tinh_trang, $ma_tuke);
    setMessage("info", "Thêm giá thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_gia = $_POST['ten_gia'];
    $tinh_trang = $_POST['tinh_trang'];
    $ma_tuke = $_POST['ma_tuke'];
    update_gia($id, $ten_gia, $tinh_trang, $ma_tuke);
    setMessage("info", "Cập nhật giá thành công!");
    redirectTo("index.php");
}
?>