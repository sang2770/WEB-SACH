<?php
global $LIMIT;
require_once "../../helper/sach.php"; // Đổi đường dẫn tới helper phù hợp
$limit = $LIMIT;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;
$search = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

if (isset($_POST['activate'])) {
    $id = $_POST['id'];
    set_status_sach($id); // Đổi tên cho phù hợp
    setMessage("info", "Thay đổi trạng thái thành công!");
    unset($_GET['tab']);
}

if (isset($_POST['deactivate'])) {
    $id = $_POST['id'];
    set_status_sach($id, 0); // Đổi tên cho phù hợp
    setMessage("info", "Thay đổi trạng thái thành công!");
    unset($_GET['tab']);
}

$sach_lst = get_sach($search, $limit, $offset); // Đổi tên cho phù hợp
$totalRecords = get_total_sach($search); // Đổi tên cho phù hợp
$totalPages = ceil($totalRecords / $limit);
?>
<div class="card mt-1">
    <div class="card-body" style="height: 620px">
        <form action="index.php" method="get">
            <div class="form-group">
                <input hidden name="page" value="<?php echo $page; ?>" />
                <input type="text" placeholder="Tìm kiếm..." name="search" value="<?php echo $search; ?>" id="search" class="form-control" />
                <button type="submit" class="btn btn-info mt-1">Tìm</button>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table align-middle">
            <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Mã Sách</th>
                <th scope="col">Tên Sách</th>
                <th scope="col">Tác Giả</th>
                <th scope="col">Số Lượng</th>
                <th scope="col">Thể Loại</th>
                <th scope="col">Nhà Xuất Bản</th>
                <th scope="col">Ngăn</th>
                <th scope="col">Khuyến Mãi</th>
                <th scope="col">Đơn Vị Tính</th>
                <th scope="col">Giá</th>
                <!-- <th scope="col">Trạng thái</th> -->
                <!-- <th scope="col">Hiển Thị</th> -->
                <th scope="col">Hành Động</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            $so_luong = 0;
            foreach ($sach_lst as $sach) { // Đổi biến và mảng dữ liệu cho phù hợp
                $status = $sach['is_active']; // Đổi tên biến
                $so_luong = $so_luong + $sach['so_luong'];
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                echo '<td>' . $sach['ma_sach'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' .  '<img height="50px" src="'.str_replace("../..", "", $sach['hinh_anh']).'" /> <br />' . $sach['ten_sach'] .'</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_tg'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['so_luong'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_tl'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_nxb'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_ngan'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_km'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['ma_dvt'] . '</td>'; // Đổi tên cột cho phù hợp
                echo '<td>' . $sach['gia'] . '</td>'; // Đổi tên cột cho phù hợp
                // echo '<td>' . ($status == 1 ? 'Hiện' : 'Ẩn') . '</td>';
                // echo '<td class="' . ($status == 1 ? 'text-success' : 'text-danger') . '">' . ($status == 1 ? 'Hiện' : 'Ẩn') . '</td>';
                echo '<td>';
                if ($status) {
                    renderButtonChange('deactivate', 1, 'id', $sach['id'], "Xóa", "danger");
                } else {
                    // renderButtonChange('activate', 1, 'id', $sach['id'], "Hiện", "success");
                }
                echo '<a href="?id=' . $sach['id'] . '&tab=tab-form"><button class="btn btn-info btn-sm mt-1">Sửa</button></a>';
                echo '</td>';
                echo '</tr>';
                $i++;
            }
            ?>
            </tbody>
        </table>
            <div>
                <span>Tổng sách: </span><?php echo $totalRecords; ?>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <div class="pagination mx-auto">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>