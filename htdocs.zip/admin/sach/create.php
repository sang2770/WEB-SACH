<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/sach.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_sach = $_POST['ten_sach'];
    $ma_tg = $_POST['ma_tg'];
    $so_luong = $_POST['so_luong'];
    $ma_tl = $_POST['ma_tl'];
    $ma_nxb = $_POST['ma_nxb'];
    $ma_ngan = $_POST['ma_ngan'];
    $ma_km = $_POST['ma_km'];
    $ma_dvt = $_POST['ma_dvt'];
    $gia = $_POST['gia'];
    if (get_sach_by_name($ten_sach)) {
        setMessage("danger", "Tên sách đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../images/";
        $target_file = $target_dir . basename($_FILES["hinh_anh"]["name"]);
        if (move_uploaded_file($_FILES["hinh_anh"]["tmp_name"], $target_file)) {
            $hinh_anh = $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
    create_sach($ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $target_file);
    setMessage("info", "Thêm sách thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_sach = $_POST['ten_sach'];
    $ma_tg = $_POST['ma_tg'];
    $so_luong = $_POST['so_luong'];
    $ma_tl = $_POST['ma_tl'];
    $ma_nxb = $_POST['ma_nxb'];
    $ma_ngan = $_POST['ma_ngan'];
    $ma_km = $_POST['ma_km'];
    $ma_dvt = $_POST['ma_dvt'];
    $gia = $_POST['gia'];
    if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../../images/";
        $target_file = $target_dir . basename($_FILES["hinh_anh"]["name"]);
        if (move_uploaded_file($_FILES["hinh_anh"]["tmp_name"], $target_file)) {
            $hinh_anh = $target_file;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        $book = get_sach_by_id($id);
        $target_file = $book->hinh_anh;
    }
    update_sach($id, $ma_tg, $so_luong, $ma_tl, $ma_nxb, $ma_ngan, $ma_km, $ma_dvt, $gia, $ten_sach, $target_file);
    setMessage("info", "Cập nhật sách thành công");
    redirectTo("index.php");
}
?>