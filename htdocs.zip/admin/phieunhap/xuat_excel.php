<?php
require_once "../../helper/config.php";
require_once "../../helper/common.php";
require_once "../../helper/phieunhap.php";
require_once "../../lib/vendor/autoload.php"; // Chèn tệp autoload của Composer

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

$search = isset($_GET['search']) ? $_GET['search'] : "";
$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Lấy phiếu nhập theo id
    $phieunhap_lst = get_phieunhap_by_id($id);
} else {
    // Lấy tất cả phiếu nhập chỉ có status = 2
    $phieunhap_lst = get_phieunhapall($search);
}

// Tạo đối tượng Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Tiêu đề bảng
$header = array('STT', 'Mã Phiếu Nhập', 'Ngày Tạo', 'Người Tạo', 'Nhà Cung Cấp', 'Mã Sách', 'Tên Sách', 'Số Lượng', 'Đơn Vị Tính', 'Giá Nhập', 'Giá Bán', 'Tổng tiền');

// Đặt tiêu đề bảng
$sheet->fromArray($header, NULL, 'A1');

// Căn chỉnh và tô màu tiêu đề bảng
$sheet->getStyle('A1:L1')->getFont()->setBold(true);
$sheet->getStyle('A1:L1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A1:L1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('00B050'); // Màu xanh lá cây

$row = 2; // Bắt đầu từ hàng thứ 2 vì hàng 1 là tiêu đề bảng
$total_all = 0; // Biến để lưu trữ tổng tiền của tất cả các phiếu nhập

foreach ($phieunhap_lst as $index => $pn) {
    $sach_lst = get_sach_by_phieunhap($pn['ma_pn']);
    $startRow = $row;

    if (!empty($sach_lst)) {
        foreach ($sach_lst as $sach) {
            // Chuyển giá trị có ký tự "," thành số thực
            $so_luong = (float)str_replace(',', '', $sach['so_luong']);
            $gia_nhap = (float)str_replace(',', '', $sach['gia_nhap']);
            $tong_tien = $so_luong * $gia_nhap; // Tính tổng tiền
            $total_all += $tong_tien; // Cộng dồn tổng tiền vào biến tổng

            $sheet->setCellValue("A{$row}", $index + 1);
            $sheet->setCellValue("B{$row}", $pn['ma_pn']);
            $sheet->setCellValue("C{$row}", $pn['ngay_tao']);
            $sheet->setCellValue("D{$row}", $pn['username']);
            $sheet->setCellValue("E{$row}", $pn['ten_ncc']);
            $sheet->setCellValue("F{$row}", $sach['ma_sach']);
            $sheet->setCellValue("G{$row}", $sach['ten_sach']);
            $sheet->setCellValue("H{$row}", $so_luong);
            $sheet->setCellValue("I{$row}", $sach['ten_dvt']);
            $sheet->setCellValue("J{$row}", $gia_nhap);
            $sheet->setCellValue("K{$row}", $sach['gia_ban']);
            $sheet->setCellValue("L{$row}", $tong_tien); // Thêm tổng tiền vào ô

            // Định dạng các giá trị số trong cột J, K, L thành định dạng có dấu phẩy
            $sheet->getStyle("J{$row}:L{$row}")
                ->getNumberFormat()
                ->setFormatCode('#,##0');
            $row++;
        }

        // Hợp nhất các ô cho cột STT đến Nhà Cung Cấp
        $endRow = $row - 1;
        $sheet->mergeCells("A{$startRow}:A{$endRow}");
        $sheet->mergeCells("B{$startRow}:B{$endRow}");
        $sheet->mergeCells("C{$startRow}:C{$endRow}");
        $sheet->mergeCells("D{$startRow}:D{$endRow}");
        $sheet->mergeCells("E{$startRow}:E{$endRow}");
        $sheet->getStyle("A{$startRow}:E{$endRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    } else {
        // Phiếu nhập không có sách nào
        $sheet->setCellValue("A{$row}", $index + 1);
        $sheet->setCellValue("B{$row}", $pn['ma_pn']);
        $sheet->setCellValue("C{$row}", $pn['ngay_tao']);
        $sheet->setCellValue("D{$row}", $pn['username']);
        $sheet->setCellValue("E{$row}", $pn['ten_ncc']);
        $sheet->setCellValue("F{$row}", 'Không có sách nào.');
        $row++;
    }
}

// Thêm tổng tiền của tất cả phiếu nhập vào cuối bảng
$sheet->setCellValue("K{$row}", 'Tổng tiền tất cả phiếu:');
$sheet->setCellValue("L{$row}", $total_all);
$sheet->getStyle("L{$row}")
    ->getNumberFormat()
    ->setFormatCode('#,##0');
$sheet->getStyle("K{$row}:L{$row}")->getFont()->setBold(true);

// Định dạng chiều rộng cột
foreach (range('A', 'L') as $columnID) {
    $sheet->getColumnDimension($columnID)->setAutoSize(true);
}

// Áp dụng viền cho tất cả các ô có dữ liệu
$sheet->getStyle("A1:L" . ($row))->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

// Xuất file Excel
$writer = new Xlsx($spreadsheet);
$filename = 'phieunhap.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment;filename=\"{$filename}\"");
header('Cache-Control: max-age=0');

$writer->save('php://output');
exit;