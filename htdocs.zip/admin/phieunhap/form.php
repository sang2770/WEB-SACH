<?php
$mode = "insert";
if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $tuke = get_tuke_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <div class="mb-4">
                    <?= genderSelect("ma_ncc", "ma_ncc", "Nhà cung cấp", get_select_list("ma_ncc", "ma_ncc", "nhacungcap"), $sach->ma_km ?? null)?>
                </div>
                <?php if ($mode == "update"): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($tuke->id) ?>"/>
                <?php endif; ?>

                <input type="hidden" name="mode" value="<?= $mode ?>" />

                <!-- Container for book fields -->
                <div id="books-container">
                    <div class="book-item mb-4">
                        <div class="mb-4">
                            <?= genderSelect("sach", "sach[]", "Sách", get_select_list("ma_sach", "ten_sach", "sach"), $tuke->ma_km ?? null)?>
                        </div>
                        <input type="number" name="so_luong[]" class="form-control mb-2" placeholder="Số lượng" min="1" />
                        <input type="number" name="gia[]" class="form-control" placeholder="Giá" min="0" />
                    </div>
                </div>

                <button type="button" class="btn btn-secondary mb-4" id="add-book-button">Thêm sách</button>

                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm phiếu nhập" : "Cập nhật phiếu nhập" ?></button>
            </form>
        </div>
    </div>
</div>

<script>
    document.getElementById('add-book-button').addEventListener('click', function () {
        const booksContainer = document.getElementById('books-container');
        const newBookItem = document.createElement('div');
        newBookItem.classList.add('book-item', 'mb-4');

        newBookItem.innerHTML = `
        <?= genderSelect("sach", "sach[]", "Sách", get_select_list("ma_sach", "ten_sach", "sach"), $tuke->ma_km ?? null)?>
        <input type="number" name="so_luong[]" class="form-control mb-2" placeholder="Số lượng" min="1" />
        <input type="number" name="gia[]" class="form-control" placeholder="Giá" min="0" />
        <button type="button" class="btn btn-danger remove-book-button">Xoá sách</button>
    `;

        booksContainer.appendChild(newBookItem);
    });

    document.addEventListener('click', function (e) {
        if (e.target && e.target.classList.contains('remove-book-button')) {
            e.target.parentElement.remove();
        }
    });
</script>