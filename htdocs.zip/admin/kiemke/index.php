<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
require_once "../../helper/danhmuc.php";
?>

<?php require_once "../header.php"?>
    <div class="container mt-5">

        <!-- Inventory Stock Report -->
        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title">Kiểm kê</h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Tên Sách</th>
                        <th>Số Lượng Còn Lại</th>
                        <th>Đơn giá</th>
                        <th>DVT</th>
                        <th>Tổng tiền</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT sach.ten_sach, sach.so_luong AS stock_remaining, sach.gia, donvitinh.ten_dvt 
                              FROM sach 
                              JOIN donvitinh ON sach.ma_dvt = donvitinh.ma_dvt;";
                    $result = $conn->query($query);
                    if ($result->num_rows) {
                        while ($row = $result->fetch_assoc()) {
                            $stock_remaining = $row['stock_remaining'] < 0 ? 0 : $row['stock_remaining'];
                            $total_price = $stock_remaining * $row['gia'];
                            echo "<tr><td>{$row['ten_sach']}</td><td>{$stock_remaining}</td><td>{$row['gia']}</td><td>{$row['ten_dvt']}</td><td>{$total_price}</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No inventory data available</td></tr>";
                    }
                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>