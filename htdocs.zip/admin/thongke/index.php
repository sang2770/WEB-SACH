<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
require_once "../../helper/danhmuc.php";
?>

<?php require_once "../header.php"?>
    <div class="container mt-5">
        <h2 class="mb-3">Báo Cáo Hàng Ngày</h2>

        <!-- Daily Sales and Export Report -->
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Báo cáo hoá đơn hàng ngày</h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Số Sách Bán Ra</th>
                        <th>Tổng Thu</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    global $conn;

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $query = "SELECT DATE(h.ngay_tao) AS sale_date, SUM(c.so_luong) AS total_books_sold, SUM(c.gia * c.so_luong) AS total_revenue FROM hoa_don h JOIN chi_tiet_hoa_don c ON h.id = c.id_hoadon GROUP BY DATE(h.ngay_tao);";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['sale_date']}</td><td>{$row['total_books_sold']}</td><td>" . number_format($row['total_revenue'], 0) . " VND</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available for this date</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
                <h3 class="card-title">Báo cáo phiếu xuất hàng ngày</h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Số Sách Bán Ra</th>
                        <th>Tổng Thu</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    global $conn;

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $query = "SELECT DATE(h.ngay_tao) AS sale_date, SUM(c.so_luong) AS total_books_sold, SUM(c.gia * c.so_luong) AS total_revenue FROM phieuxuat h JOIN chi_tiet_phieu_xuat c ON h.ma_px = c.ma_px GROUP BY DATE(h.ngay_tao);";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['sale_date']}</td><td>{$row['total_books_sold']}</td><td>" . number_format($row['total_revenue'], 0) . " VND</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available for this date</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Inventory Stock Report -->
        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title">Báo cáo Tồn Kho</h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Tên Sách</th>
                        <th>Số Lượng Còn Lại</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT ten_sach, so_luong AS stock_remaining FROM sach;";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['ten_sach']}</td><td>{$row['stock_remaining']}</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No inventory data available</td></tr>";
                    }
                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>