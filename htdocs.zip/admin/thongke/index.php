<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
require_once "../../helper/danhmuc.php";
$group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE';

?>

<?php require_once "../header.php"?>
    <div class="container mt-5">
        

        <!-- Date Selection Form -->
        <form method="GET" class="mb-4" style="width: 200px;">
            <div class="form-group">
                <label for="group_by">Thống kê theo:</label>
                <select name="group_by" id="group_by" class="form-control">
                    <option value="DATE" <?php echo $group_by == 'DATE' ? 'selected' : ''; ?>>Ngày</option>
                    <option value="MONTH" <?php echo $group_by == 'MONTH' ? 'selected' : ''; ?>>Tháng</option>
                    <option value="YEAR" <?php echo $group_by == 'YEAR' ? 'selected' : ''; ?>>Năm</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Generate Report</button>
        </form>
        <h2 class="mb-3">Báo Cáo <?php $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE'; echo $group_by == 'DATE' ? 'Hàng Ngày' : ($group_by == 'MONTH' ? 'Hàng Tháng' : 'Hàng Năm'); ?></h2>
        <!-- Daily Sales and Export Report -->
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Báo cáo hoá đơn <?php $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE'; echo $group_by == 'DATE' ? 'Hàng Ngày' : ($group_by == 'MONTH' ? 'Hàng Tháng' : 'Hàng Năm'); ?></h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th><?php $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE'; echo $group_by == 'DATE' ? 'Ngày' : ($group_by == 'MONTH' ? 'Tháng' : 'Năm'); ?></th>
                        <th>Số Sách Bán Ra</th>
                        <th>Tổng Thu</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    global $conn;

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE';
                    $query = "SELECT $group_by(h.ngay_tao) AS sale_date, SUM(c.so_luong) AS total_books_sold, SUM(c.gia * c.so_luong) AS total_revenue FROM hoa_don h JOIN chi_tiet_hoa_don c ON h.id = c.id_hoadon GROUP BY $group_by(h.ngay_tao);";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['sale_date']}</td><td>{$row['total_books_sold']}</td><td>" . number_format($row['total_revenue'], 0) . " VND</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available for this date</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
                <h3 class="card-title">Báo cáo phiếu xuất <?php $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'DATE'; echo $group_by == 'DATE' ? 'hàng ngày' : ($group_by == 'MONTH' ? 'hàng tháng' : 'hàng năm'); ?></h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Số Sách Bán Ra</th>
                        <th>Tổng Thu</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT $group_by(h.ngay_tao) AS sale_date, SUM(c.so_luong) AS total_books_sold, SUM(c.gia * c.so_luong) AS total_revenue FROM phieuxuat h JOIN chi_tiet_phieu_xuat c ON h.ma_px = c.ma_px GROUP BY $group_by(h.ngay_tao);";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['sale_date']}</td><td>{$row['total_books_sold']}</td><td>" . number_format($row['total_revenue'], 0) . " VND</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available for this date</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Inventory Stock Report -->
        <!-- <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title">Báo cáo Tồn Kho</h3>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Tên Sách</th>
                        <th>Số Lượng Còn Lại</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT ten_sach, so_luong AS stock_remaining FROM sach;";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['ten_sach']}</td><td>{$row['stock_remaining']}</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No inventory data available</td></tr>";
                    }
                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
        </div> -->
    </div>
<?php require_once "../../footer.php" ?>