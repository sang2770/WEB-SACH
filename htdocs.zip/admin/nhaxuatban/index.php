<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'nxb-tab';
?>

<?php require_once "../header.php"?>
    <div class="container mt-3">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "nxb-tab" ? "active" : "" ?>" id="nxb-tab" data-mdb-toggle="tab" href="#nxb" role="tab" aria-controls="nxb" aria-selected="true">Nhà xuất bản</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "nxb-tab-form" ? "active" : "" ?>"" id="nxb-tab-form" data-mdb-toggle="tab" href="#nxb-form" role="tab" aria-controls="nxb-form" aria-selected="false">Thêm nhà xuất bản</a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade <?= $tab == "nxb-tab" ? "active show" : "" ?>" id="nxb" role="tabpanel" aria-labelledby="nxb-tab">
                <?php require_once "table.php" ?>
            </div>
            <div class="tab-pane fade <?= $tab == "nxb-tab-form" ? "active show" : "" ?>"" id="nxb-form" role="tabpanel" aria-labelledby="nxb-tab-form">
                <?php require_once "form.php" ?>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>