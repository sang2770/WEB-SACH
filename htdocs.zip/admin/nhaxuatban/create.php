<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/nhaxuatban.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_nxb = $_POST['ten_nxb'];
    $sdt = $_POST['sdt'];
    $dia_chi = $_POST['dia_chi'];
    $email = $_POST['email'];
    if (get_nxb_by_name($ten_nxb)) {
        setMessage("danger", "Nhà xuất bản đã tồn tại!");
        redirectTo("index.php");
    }
    create_nxb($ten_nxb, $sdt, $dia_chi, $email);
    setMessage("info", "Thêm nhà xuất bản thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_nxb = $_POST['ten_nxb'];
    $sdt = $_POST['sdt'];
    $email = $_POST['email'];
    $dia_chi = $_POST['dia_chi'];
    update_nxb_by_id($id, $ten_nxb, $sdt, $dia_chi, $email);
    setMessage("info", "Cập nhật nhà xuất bản thành công!");
    redirectTo("index.php");
}
?>