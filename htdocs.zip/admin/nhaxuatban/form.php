<?php
    $mode = "insert";
    if(isset($_GET['id']) && $_GET['id']){
        $id = $_GET['id'];
        $nxb = get_nxb_by_id($id);
        $mode = "update";
    }
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Nhà Xuất Bản -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenNxb" name="ten_nxb" value="<?= isset($nxb->ten_nxb) ? htmlspecialchars($nxb->ten_nxb) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenNxb">Tên Nhà Xuất Bản</label>
                </div>
                <!-- Số Điện Thoại -->
                <div class="form-outline mb-4">
                    <input type="text" id="sdt" name="sdt" value="<?= isset($nxb->sdt) ? htmlspecialchars($nxb->sdt) : null ?>" class="form-control" required />
                    <label class="form-label" for="sdt">Số Điện Thoại</label>
                </div>

                <!-- Địa Chỉ -->
                <div class="form-outline mb-4">
                    <input type="text" id="diaChi" name="dia_chi" value="<?= isset($nxb->dia_chi) ? htmlspecialchars($nxb->dia_chi) : null ?>" class="form-control" required />
                    <label class="form-label" for="diaChi">Địa Chỉ</label>
                </div>

                <!-- Email -->
                <div class="form-outline mb-4">
                    <input type="email" id="email" name="email" value="<?= isset($nxb->email) ? htmlspecialchars($nxb->email) : null ?>" class="form-control" required />
                    <label class="form-label" for="email">Email</label>
                </div>
                <input type="hidden" name="id" value="<?= isset($nxb->id) ? htmlspecialchars($nxb->id) : null ?>">
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Nhà Xuất Bản" : "Lưu Nhà Xuất Bản" ?></button>
            </form>
        </div>
    </div>
</div>