<?php
global $LIMIT;
require_once "../../helper/nhaxuatban.php";
$limit = $LIMIT;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;
$search = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

if (isset($_POST['activate'])) {
    $id = $_POST['user_id'];
    setStatusNXB($id);
    setMessage("info", "Thay đổi trạng thái thành công!");
}

if (isset($_POST['deactivate'])) {
    $id = $_POST['user_id'];
    setStatusNXB($id, 0);
    setMessage("info", "Thay đổi trạng thái thành công!");
}

$nhaxuatban_lst = get_nhaxuatban($search, $limit, $offset);
$totalRecords = get_total_nhaxuatban($search);
$totalPages = ceil($totalRecords / $limit);
?>
<div class="card mt-1">
    <div class="card-body" style="height: 620px">
        <form action="index.php" method="get">
            <div class="form-group">
                <input hidden name="page" value="<?php echo $page; ?>" /">
                <input type="text" placeholder="Tìm kiếm nhà xuất bản ..." name="search" value="<?php echo $search; ?>" id="search" class="form-control" />
                <button type="submit" class="btn btn-info mt-1">Tìm</button>
            </div>
        </form>
        <table class="table align-middle">
            <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Mã NXB</th>
                <th scope="col">Tên NXB</th>
                <th scope="col">Email</th>
                <th scope="col">Địa chỉ</th>
                <th scope="col">Số điện thoại</th>
                <!-- <th scope="col">Trạng thái</th> -->
                <th scope="col">Hành động</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            foreach ($nhaxuatban_lst as $nxb) {
                $status = $nxb['is_active'];
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                echo '<td>' . $nxb['ma_nxb'] . '</td>';
                echo '<td>' . $nxb['ten_nxb'] . '</td>';
                echo '<td>' . $nxb['email'] . '</td>';
                echo '<td>' . $nxb['dia_chi'] . '</td>';
                echo '<td>' . $nxb['sdt'] . '</td>';
                // if ($status == 1) {
                //     echo '<td class="text-success">Hiện</td>';
                // } else {
                //     echo '<td class="text-danger">Ẩn</td>';
                // }
                echo '<td>';
                if ($status) {
                    renderButtonChange('deactivate', 1, 'user_id', $nxb['id'], "Xóa", "danger");
                } else {
                    // renderButtonChange('activate', 1, 'user_id', $nxb['id'], "Hiện", "success");
                }
                echo '<a href="?id='.$nxb['id'].'&tab=nxb-tab-form"><button class="btn btn-info btn-sm mt-1">Sửa</button></a>';
                echo '</td>';
                echo '</tr>';
                $i++;
            }
            ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <div class="pagination mx-auto">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>