<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/donvitinh.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_dvt = $_POST['ten_dvt'];
    if (get_dvt_by_name($ten_dvt)) {
        setMessage("danger", "Đơn vị tính đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_dvt($ten_dvt);
    setMessage("info", "Thêm đơn vị tính thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_dvt = $_POST['ten_dvt'];
    update_dvt_by_id($id, $ten_dvt);
    setMessage("info", "Cập nhật đơn vị tính thành công!");
    redirectTo("index.php");
}
?>