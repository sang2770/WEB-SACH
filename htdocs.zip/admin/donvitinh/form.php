<?php
$mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
    $id = $_GET['id'];
    $dvt = get_dvt_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Đơn vị tính -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenDvt" name="ten_dvt" value="<?= isset($dvt->ten_dvt) ? htmlspecialchars($dvt->ten_dvt) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenDvt">Tên Đơn Vị Tính</label>
                </div>

                <input type="hidden" name="id" value="<?= isset($dvt->id) ? htmlspecialchars($dvt->id) : null ?>"/>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Đơn Vị Tính" : "Lưu Đơn Vị Tính" ?></button>
            </form>
        </div>
    </div>
</div>