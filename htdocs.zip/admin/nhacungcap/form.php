<?php
    $mode = "insert";
    if(isset($_GET['id']) && $_GET['id']){
        $id = $_GET['id'];
        $ncc = get_ncc_by_id($id);
        $mode = "update";
    }
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Nhà Xuất Bản -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenNcc" name="ten_ncc" value="<?= isset($ncc->ten_ncc) ? htmlspecialchars($ncc->ten_ncc) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenNcc">Tên Nhà Cung Cấp</label>
                </div>
                <!-- Số Điện Thoại -->
                <div class="form-outline mb-4">
                    <input type="text" id="sdt" name="sdt" value="<?= isset($ncc->sdt) ? htmlspecialchars($ncc->sdt) : null ?>" class="form-control" required />
                    <label class="form-label" for="sdt">Số Điện Thoại</label>
                </div>

                <!-- Địa Chỉ -->
                <div class="form-outline mb-4">
                    <input type="text" id="diaChi" name="dia_chi" value="<?= isset($ncc->dia_chi) ? htmlspecialchars($ncc->dia_chi) : null ?>" class="form-control" required />
                    <label class="form-label" for="diaChi">Địa Chỉ</label>
                </div>

                <!-- Email -->
                <div class="form-outline mb-4">
                    <input type="email" id="email" name="email" value="<?= isset($ncc->email) ? htmlspecialchars($ncc->email) : null ?>" class="form-control" required />
                    <label class="form-label" for="email">Email</label>
                </div>
                <input type="hidden" name="id" value="<?= isset($ncc->id) ? htmlspecialchars($ncc->id) : null ?>">
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Nhà Xuất Bản" : "Lưu Nhà Xuất Bản" ?></button>
            </form>
        </div>
    </div>
</div>