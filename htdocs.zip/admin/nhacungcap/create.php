<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/nhacungcap.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_ncc = $_POST['ten_ncc'];
    $sdt = $_POST['sdt'];
    $dia_chi = $_POST['dia_chi'];
    $email = $_POST['email'];
    if (get_ncc_by_name($ten_ncc)) {
        setMessage("danger", "Nhà xuất bản đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_ncc($ten_ncc, $sdt, $dia_chi, $email);
    setMessage("info", "Thêm nhà xuất bản thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_ncc = $_POST['ten_ncc'];
    $sdt = $_POST['sdt'];
    $email = $_POST['email'];
    $dia_chi = $_POST['dia_chi'];
    update_ncc_by_id($id, $ten_ncc, $sdt, $dia_chi, $email);
    setMessage("info", "Cập nhật nhà xuất bản thành công!");
    redirectTo("index.php");
}
?>