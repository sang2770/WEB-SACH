<?php
global $conn;
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once "../../helper/donhang.php";
require_once '../../helper/hoadon.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $id_dh = $_POST['id_dh'];

    // Lấy thông tin don hang
    $sql_get_dh = "SELECT ho_ten, sdt, dia_chi FROM don_hang WHERE id = ?";
    $stmt_get_dh = $conn->prepare($sql_get_dh);
    if ($stmt_get_dh === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt_get_dh->bind_param("i", $id_dh);
    $stmt_get_dh->execute();
    $result_dh = $stmt_get_dh->get_result();
    $don_hang_info = $result_dh->fetch_assoc();
    // Cập nhật trạng thái đơn hàng thành 'Xác nhận'
    setStatus_donhang($id_dh, 'Xác nhận');
    if ($don_hang_info) {
        $ho_ten = $don_hang_info['ho_ten'];
        $sdt = $don_hang_info['sdt'];
        $dia_chi_day_du = $don_hang_info['dia_chi'];

        $conn->begin_transaction();
        try {
            $trang_thai = 1;
            $sql_insert_px = "INSERT INTO hoa_don (nguoi_tao, nguoi_cap_nhat, ngay_tao, dia_chi, sdt, ho_ten, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt_insert_px = $conn->prepare($sql_insert_px);
            if ($stmt_insert_px === false) {
                throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
            }
            $ngay_tao = date('Y-m-d H:i:s');
            $stmt_insert_px->bind_param("iissssi", $user_id, $user_id, $ngay_tao, $dia_chi_day_du, $sdt, $ho_ten, $trang_thai);
            $stmt_insert_px->execute();
            $id_hoadon = $conn->insert_id;

            // Lấy sách từ chi tiết đơn hàng
            $sql = "SELECT sach.ma_sach, chi_tiet_don_hang.so_luong, sach.gia 
                    FROM chi_tiet_don_hang 
                    JOIN sach ON chi_tiet_don_hang.ma_sach = sach.id 
                    WHERE chi_tiet_don_hang.ma_don_hang = ?";
                    
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
            }
            $stmt->bind_param("i", $id_dh);
            $stmt->execute();
            $result = $stmt->get_result();

            // Thêm chi tiết phiếu xuất
            $sql_insert_ct_px = "INSERT INTO chi_tiet_hoa_don (id_hoadon, ma_sach, so_luong, gia) VALUES (?, ?, ?, ?)";
            $stmt_insert_ct_px = $conn->prepare($sql_insert_ct_px);
            if ($stmt_insert_ct_px === false) {
                throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
            }
            while ($row = $result->fetch_assoc()) {
                echo $row['ma_sach'];
                $ma_sach = $row['ma_sach'];
                $so_luong = $row['so_luong'];
                $gia = $row['gia'];

                $stmt_insert_ct_px->bind_param("isii", $id_hoadon, $ma_sach, $so_luong, $gia);
                $stmt_insert_ct_px->execute();

                // Cập nhật số lượng sách trong kho
                $sql_update_books = "UPDATE sach SET so_luong = so_luong - ? WHERE ma_sach = ?";
                $stmt_update_books = $conn->prepare($sql_update_books);
                if ($stmt_update_books === false) {
                    throw new Exception('Prepare failed: ' . htmlspecialchars($conn->error));
                }
                $stmt_update_books->bind_param("is", $so_luong, $ma_sach);
                $stmt_update_books->execute();
            }
            

            $conn->commit();
            setMessage("success", "Xác nhận đơn hàng thành công");
            // Chuyển hướng người dùng về trang danh sách hóa đơn sau khi thanh toán thành công
            header('Location: index.php');
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo "Thanh toán thất bại: " . $e->getMessage();
        }

        $stmt->close();
    } else {
        echo "Đơn hàng không tồn tại.";
    }
    $conn->close();
} else {
    header('Location: donhang/index.php');
}
