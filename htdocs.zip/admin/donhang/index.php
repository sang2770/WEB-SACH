<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/role.php";
require_once "../../helper/user.php";
require_once "../../helper/donhang.php";  // Giả định có helper xử lý đơn hàng

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'tab-table';
$allow = [1, 2, 3];
$role_id = getCurrentRole(getSession('user_id'));
if (!in_array($role_id, $allow)) {
    header("Location: /admin/index.php");
    exit();
}

global $LIMIT;
$limit = $LIMIT;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? $_GET['search'] : '';

$donhang_lst = get_donhang($search, $limit, $offset);
$totalRecords = get_total_donhang($search);
$totalPages = ceil($totalRecords / $limit);
?>

<?php require_once "../header.php"; ?>
<div class="container mt-3" style="max-width: 80%;">
    <div class="card mt-1">
        <div class="card-body">
            <form action="index.php" method="get">
                <div class="form-group">
                    <input hidden name="page" value="<?php echo $page; ?>" />
                    <input type="text" placeholder="Tìm kiếm..." name="search" value="<?php echo $search; ?>" class="form-control" />
                    <button type="submit" class="btn btn-info mt-1">Tìm</button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th scope="col">STT</th>
                            <th scope="col">Ngày Đặt</th>
                            <th scope="col">Họ Tên</th>
                            <th scope="col">Địa Chỉ</th>
                            <th scope="col">SĐT</th>
                            <th scope="col">Tổng Tiền</th>
                            <th scope="col">Chi Tiết</th>
                            <th scope="col">Trạng Thái</th>
                            <th scope="col">Hành Động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        foreach ($donhang_lst as $dh) {
                            echo '<tr>';
                            echo '<td>' . $i . '</td>';
                            echo '<td>' . $dh['ngay_dat'] . '</td>';
                            echo '<td>' . $dh['ho_ten'] . '</td>';
                            echo '<td>' . $dh['dia_chi'] . '</td>';
                            echo '<td>' . $dh['sdt'] . '</td>';
                            echo '<td>' . number_format($dh['tong_tien'], 2) . '</td>';
                            echo '<td>';
                            $chi_tiet_lst = get_sach_by_donhang($dh['id_dh']); // Lấy chi tiết đơn hàng
                            if (!empty($chi_tiet_lst)) {
                                echo '<table class="table table-bordered">';
                                echo '<thead>';
                                echo '<tr><th>Mã Sách</th><th>Số Lượng</th><th>Giá</th><th>Thành Tiền</th></tr>';
                                echo '</thead><tbody>';
                                foreach ($chi_tiet_lst as $ct) {
                                    echo '<tr>';
                                    echo '<td>' . $ct['ma_sach'] . '</td>';
                                    echo '<td>' . $ct['so_luong'] . '</td>';
                                    echo '<td>' . number_format($ct['gia'], 2) . '</td>';
                                    echo '<td>' . number_format($ct['thanh_tien'], 2) . '</td>';
                                    echo '</tr>';
                                }
                                echo '</tbody></table>';
                            } else {
                                echo 'Không có chi tiết.';
                            }
                            echo '</td>';
                            echo '<td>' . $dh['status'] . '</td>';
                            echo '<td>';
                            if ($dh['status'] != 'Xác nhận' && $dh['status'] != 'Hủy') {
                                echo '<form action="/admin/donhang/confirm.php" method="post" style="display:inline-block;">';
                                echo '<input type="hidden" name="id_dh" value="' . $dh['id_dh'] . '">';
                                echo '<button type="submit" class="btn btn-success mt-1">Xác nhận</button>';
                                echo '</form>';
                                echo '<form action="/admin/donhang/cancel.php" method="post" style="display:inline-block; margin-left: 10px;">';
                                echo '<input type="hidden" name="id_dh" value="' . $dh['id_dh'] . '">';
                                echo '<button type="submit" class="btn btn-danger mt-1">Hủy</button>';
                                echo '</form>';
                            }
                            echo '</td>';
                            echo '</tr>';
                            $i++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            <!-- Phân trang -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">&laquo;</a>
                        </li>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">&raquo;</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php require_once "../../footer.php"; ?>
