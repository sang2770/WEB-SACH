<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/danhmuc.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_dm = $_POST['ten_dm'];
    if (get_danhmuc_by_name($ten_dm)) {
        setMessage("danger", "Danh mục đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_danhmuc($ten_dm);
    setMessage("info", "Thêm danh mục thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $ten_dm = $_POST['ten_dm'];
    $id = $_POST['id'];
    if (get_danhmuc_by_name($ten_dm)) {
        setMessage("danger", "Danh mục đã tồn tại!");
        redirectTo("index.php?id=$id&tab=tab-form");
    }
    update_danhmuc($id, $ten_dm);
    setMessage("info", "Cập nhật nhà xuất bản thành công!");
    redirectTo("index.php");
}
?>