<?php
    $mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
        $id = $_GET['id'];
        $nxb = get_danhmuc_by_id($id);
        $mode = "update";
    }
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Nhà Xuất Bản -->
                <div class="form-outline mb-4">
                    <input type="text" id="tendm" name="ten_dm" value="<?= isset($nxb->ten_dm) ? htmlspecialchars($nxb->ten_dm) : null ?>" class="form-control" required />
                    <label class="form-label" for="ten_dm">Tên danh mục</label>
                </div>
                <input type="hidden" name="id" value="<?= isset($nxb->id) ? htmlspecialchars($nxb->id) : null ?>">
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Nhà Danh Mục" : "Lưu Danh Mục" ?></button>
            </form>
        </div>
    </div>
</div>