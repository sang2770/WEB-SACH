<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/tuke.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_tuke = $_POST['ten_tuke'];
    $trang_thai = $_POST['trang_thai'];
    create_tuke($ten_tuke, $trang_thai);
    setMessage("info", "Thêm tủ kệ thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_tuke = $_POST['ten_tuke'];
    $trang_thai = $_POST['trang_thai'];
    update_tuke_by_id($id, $ten_tuke, $trang_thai);
    setMessage("info", "Cập nhật tủ kệ thành công!");
    redirectTo("index.php");
}
?>