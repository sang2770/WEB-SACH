<?php
$mode = "insert";
if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $tuke = get_tuke_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <div class="form-outline mb-4">
                    <input type="text" id="tenTuke" name="ten_tuke" value="<?= isset($tuke->ten_tuke) ? htmlspecialchars($tuke->ten_tuke) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenTuke">Tên Tủ Kệ</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="text" id="trangThai" name="trang_thai" value="<?= isset($tuke->trang_thai) ? htmlspecialchars($tuke->trang_thai) : null ?>" class="form-control" required />
                    <label class="form-label" for="trangThai">Trạng Thái</label>
                </div>
                <?php if ($mode == "update"): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($tuke->id) ?>"/>
                <?php endif; ?>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Tủ Kệ" : "Lưu Tủ Kệ" ?></button>
            </form>
        </div>
    </div>
</div>