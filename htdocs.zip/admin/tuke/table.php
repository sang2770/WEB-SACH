<?php
global $LIMIT;
require_once "../../helper/tuke.php";
$limit = $LIMIT;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;
$search = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

if (isset($_POST['activate'])) {
    $id = $_POST['id'];
    setStatus_tuke($id);
    setMessage("info", "Thay đổi trạng thái thành công!");
    unset($_GET['tab']);
}

if (isset($_POST['deactivate'])) {
    $id = $_POST['id'];
    setStatus_tuke($id, 0);
    setMessage("info", "Thay đổi trạng thái thành công!");
    unset($_GET['tab']);
}

$tuke_lst = get_tuke($search, $limit, $offset);
$totalRecords = get_total_tuke($search);
$totalPages = ceil($totalRecords / $limit);
?>
<div class="card mt-1">
    <div class="card-body" style="height: 620px">
        <form action="index.php" method="get">
            <div class="form-group">
                <input hidden name="page" value="<?php echo $page; ?>" />
                <input type="text" placeholder="Tìm kiếm..." name="search" value="<?php echo $search; ?>" id="search" class="form-control" />
                <button type="submit" class="btn btn-info mt-1">Tìm</button>
            </div>
        </form>
        <table class="table align-middle">
            <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Mã Tủ Kệ</th>
                <th scope="col">Tên Tủ Kệ</th>
                <!-- <th scope="col">Trạng thái</th> -->
                <th scope="col">Hiển Thị</th>
                <th scope="col">Hành Động</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            foreach ($tuke_lst as $tk) {
                $status = $tk['is_active'];
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                echo '<td>' . $tk['ma_tuke'] . '</td>';
                echo '<td>' . $tk['ten_tuke'] . '</td>';
                echo '<td>' . $tk['trang_thai'] . '</td>';
                // if ($status == 1) {
                //     echo '<td class="text-success">Hiện</td>';
                // } else {
                //     echo '<td class="text-danger">Ẩn</td>';
                // }
                echo '<td>';
                if ($status) {
                    renderButtonChange('deactivate', 1, 'id', $tk['id'], "Xóa", "danger");
                } else {
                    renderButtonChange('activate', 1, 'id', $tk['id'], "Hiện", "success");
                }
                echo '<a href="?id='.$tk['id'].'&tab=tab-form"><button class="btn btn-info btn-sm mt-1">Sửa</button></a>';
                echo '</td>';
                echo '</tr>';
                $i++;
            }
            ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <div class="pagination mx-auto">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>