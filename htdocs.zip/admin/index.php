<?php
session_start();
require_once '../helper/common.php';
require_once '../helper/user.php';
require_once '../helper/role.php';
if (!isLogined()) {
    redirectTo('/login.php');
}
?>

<?php require_once 'header.php'; ?>
<!-- Navbar -->
<style>
    .card {
        height: 100%;
    }

    .card-body {
        display: flex;
        flex-direction: column;
        border: 1px solid #ccc;
        justify-content: space-between;
        border-radius: 10px;
        text-align: center;
    }

    .card-body img {
        width: 100px;
        height: 100px;
        margin: 0 auto;
        margin-bottom: 10px;
    }
</style>
<div class="container mt-5">
    <h1 class="text-center">Welcome to BookStore Admin Panel</h1>
    <div class="row mt-4 mx-auto">
        <?php
        $role_id = getSession('role_id');
        if ($role_id == 1) {
            echo '     <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/user.png" alt="Người dùng" class="img-fluid">
                    <h5 class="card-title">Người dùng</h5>
                    <p class="card-text">Quản lý thông tin người dùng</p>
                    <a href="/admin/users.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>';
        }
        ?>

        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/book.png" alt="Sách" class="img-fluid">
                    <h5 class="card-title">Sách</h5>
                    <p class="card-text">Quản lý thông tin sách</p>
                    <a href="/admin/sach/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <!-- Thêm các thẻ card khác tương tự -->
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/nxb.png" alt="Nhà xuất bản" class="img-fluid">
                    <h5 class="card-title">Nhà xuất bản</h5>
                    <p class="card-text">Quản lý thông tin nhà xuất bản</p>
                    <a href="/admin/nhaxuatban/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/ncc.png" alt="Nhà cung cấp" class="img-fluid">
                    <h5 class="card-title">Nhà cung cấp</h5>
                    <p class="card-text">Quản lý thông tin nhà cung cấp</p>
                    <a href="/admin/nhacungcap/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/tacgia.png" alt="Tác giả" class="img-fluid">
                    <h5 class="card-title">Tác giả</h5>
                    <p class="card-text">Quản lý thông tin tác giả</p>
                    <a href="/admin/tacgia/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/danhmuc.png" alt="Danh mục" class="img-fluid">
                    <h5 class="card-title">Danh mục</h5>
                    <p class="card-text">Quản lý danh mục sách</p>
                    <a href="/admin/danhmuc/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/theloai.png" alt="Thể loại" class="img-fluid">
                    <h5 class="card-title">Thể loại</h5>
                    <p class="card-text">Quản lý thể loại sách</p>
                    <a href="/admin/theloai/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/donvitinh.png" alt="Đơn vị tính" class="img-fluid">
                    <h5 class="card-title">Đơn vị tính</h5>
                    <p class="card-text">Quản lý đơn vị tính sách</p>
                    <a href="/admin/donvitinh/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/khuyenmai.png" alt="Khuyến mãi" class="img-fluid">
                    <h5 class="card-title">Khuyến mãi</h5>
                    <p class="card-text">Quản lý các chương trình khuyến mãi</p>
                    <a href="/admin/khuyenmai/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/tuke.png" alt="Tủ kệ" class="img-fluid">
                    <h5 class="card-title">Tủ kệ</h5>
                    <p class="card-text">Quản lý tủ kệ sách</p>
                    <a href="/admin/tuke/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/gia.png" alt="Giá" class="img-fluid">
                    <h5 class="card-title">Giá</h5>
                    <p class="card-text">Quản lý giá sách</p>
                    <a href="/admin/gia/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/ngan.png" alt="Ngăn" class="img-fluid">
                    <h5 class="card-title">Ngăn</h5>
                    <p class="card-text">Quản lý ngăn sách</p>
                    <a href="/admin/ngan/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/ticket.png" alt="Phiếu nhập" class="img-fluid">
                    <h5 class="card-title">Phiếu nhập</h5>
                    <p class="card-text">Quản lý phiếu nhập sách</p>
                    <a href="/admin/phieunhap/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/ticket.png" alt="Phiếu xuất" class="img-fluid">
                    <h5 class="card-title">Phiếu xuất</h5>
                    <p class="card-text">Quản lý phiếu xuất sách</p>
                    <a href="/admin/phieuxuat/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/bill.png" alt="Hoá đơn" class="img-fluid">
                    <h5 class="card-title">Hoá đơn</h5>
                    <p class="card-text">Quản lý hoá đơn</p>
                    <a href="/admin/hoadon/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/thanhly-1.png" alt="Thanh lý" class="img-fluid">
                    <h5 class="card-title">Thanh lý</h5>
                    <p class="card-text">Quản lý thanh lý sách</p>
                    <a href="/admin/thanhly/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/bill.png" alt="Kiem kê" class="img-fluid">
                    <h5 class="card-title">Kiểm kê</h5>
                    <p class="card-text">Quản lý kiểm kê sách</p>
                    <a href="/admin/kiemke/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <div class="card">
                <div class="card-body">
                    <img src="../images/icons/pack.png" alt="Đơn hàng" class="img-fluid">
                    <h5 class="card-title">Đơn hàng</h5>
                    <p class="card-text">Quản lý đơn hàng</p>
                    <a href="/admin/donhang/index.php" class="btn btn-primary">Tới trang</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.10.2/mdb.min.js"></script>

<?php require_once '../footer.php'; ?>

</body>

</html>