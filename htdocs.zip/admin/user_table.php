<div class="card mt-1">
    <div class="card-body">
        <form action="users.php" method="get">
            <div class="form-group">
                <input hidden name="page" value="<?php echo $page; ?>" /">
                <input type="text" placeholder="Tìm kiếm theo email or tên người dùng ..." name="search" id="search" class="form-control" />
                <button type="submit" class="btn btn-info mt-1">Tìm</button>
            </div>
        </form>
        <table class="table align-middle">
            <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Tên người dùng</th>
                <th scope="col">Email</th>
                <th scope="col">Trạng thái</th>
                <th scope="col">Quyền</th>
                <th scope="col">Hành động</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            foreach ($users as $user) {
                $status = $user['is_active'];
                $id = $user['id'];
                $username = $user['username'];
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                echo '<td>' . $user['username'] . '</td>';
                echo '<td>' . $user['email'] . '</td>';
                if ($status == 1) {
                    echo '<td class="text-success"> Đang hoạt động </td>';
                } else {
                    echo '<td class="text-danger"> Đang bị vô hiệu hoá</td>';
                }
                echo '<td>' . $user['role'] . '</td>';
                echo '<td>';
                if ($status) {
                    renderButtonChange('deactivate', 1, 'user_id', $user['id'], "Vô hiệu hoá", "danger");
                } else {
                    renderButtonChange('activate', 1, 'user_id', $user['id'], "Hoạt động", "success");
                }
                echo "<button data-mdb-toggle='modal' id='set-role-user' data-mdb-target='#set-role' class='btn btn-sm btn-outline-info mt-1' onclick='setRole($id, \"$username\")'>Phân quyền</button>";
                echo '</td>';
                echo '</tr>';
                $i++;
            }
            ?>
            </tbody>
        </table>
        <div class="pagination mx-auto">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
        <div class="modal fade" id="set-role" tabindex="-1"aria-hidden="true">
            <div class="modal-dialog">
                <form action="users.php" method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Thay đổi quyền</h5>
                            <button type="button" class="btn-close" data-mdb-ripple-init data-mdb-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="username" class="form-label">Người dùng</label>
                                <input type="text" class="form-control" id="username" name="username" readonly />
                                <input type="text" class="form-control" id="userid" name="userid" hidden />
                            </div>
                            <?php genderSelect('role-select', 'role-select', 'Quyền', $roles); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-tertiary" data-mdb-ripple-init data-mdb-dismiss="modal">Đóng</button>
                            <button  class="btn btn-primary" type="submit" data-mdb-ripple-init>Lưu</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>