<?php
$mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
    $id = $_GET['id'];
    $tg = get_tg_by_id($id);
    $mode = "update";
}

// Lấy danh sách danh mục từ cơ sở dữ liệu
$danhmuc_list = get_danhmuc_list();
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Thể loại -->
                <div class="form-outline mb-4">
                    <input type="text" id="ten_tg" name="ten_tg" value="<?= isset($tg->ten_tg) ? htmlspecialchars($tg->ten_tg) : null ?>" class="form-control" required />
                    <label class="form-label" for="ten_tg">Tên Thể Loại</label>
                </div>

                <!-- Mã Danh Mục -->
                <div class="form-outline mb-4">
                    <textarea name="mo_ta" id="mota" class="form-control" rows="8"><?= isset($tg->mo_ta) ? htmlspecialchars($tg->mo_ta) : null ?></textarea>
                    <label class="form-label" for="mota">Mô tả</label>
                </div>

                <input type="hidden" name="id" value="<?= isset($tg->id) ? htmlspecialchars($tg->id) : null ?>">
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Tác giả" : "Lưu tác giả" ?></button>
            </form>
        </div>
    </div>
</div>