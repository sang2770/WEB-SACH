<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/tacgia.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_tg = $_POST['ten_tg'];
    $mo_ta = $_POST['mo_ta'] ?? '';
    if (get_tg_by_name($ten_tg)) {
        setMessage("danger", "Tác giả đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_tg($ten_tg, $mo_ta);
    setMessage("info", "Thêm tác giả thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_tg = $_POST['ten_tg'];
    $mo_ta = $_POST['mo_ta'];
    update_tg_by_id($id, $ten_tg, $mo_ta);
    setMessage("info", "Cập nhật tác giả thành công!");
    redirectTo("index.php");
}
?>