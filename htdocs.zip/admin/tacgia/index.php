<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
require_once "../../helper/danhmuc.php";
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'tab-table';
?>

<?php require_once "../header.php"?>
    <div class="container mt-3">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-table" ? "active" : "" ?>" id="tg-tab" data-mdb-toggle="tab" href="#tg" role="tab" aria-controls="tg" aria-selected="true">Tác giả</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-form" ? "active" : "" ?>" id="tg-tab-form" data-mdb-toggle="tab" href="#tg-form" role="tab" aria-controls="tg-form" aria-selected="false">Thêm tác giả</a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade <?= $tab == "tab-table" ? "active show" : "" ?>" id="tg" role="tabpanel" aria-labelledby="tg-tab">
                <?php require_once "table.php" ?>
            </div>
            <div class="tab-pane fade <?= $tab == "tab-form" ? "active show" : "" ?>" id="tg-form" role="tabpanel" aria-labelledby="tg-tab-form">
                <?php require_once "form.php" ?>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>