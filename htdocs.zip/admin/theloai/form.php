<?php
$mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
    $id = $_GET['id'];
    $tl = get_tl_by_id($id);
    $mode = "update";
}

// Lấy danh sách danh mục từ cơ sở dữ liệu
$danhmuc_list = get_danhmuc_list();
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Thể loại -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenTl" name="ten_tl" value="<?= isset($tl->ten_tl) ? htmlspecialchars($tl->ten_tl) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenTl">Tên Thể Loại</label>
                </div>

                <!-- Mã Danh Mục -->
                <div class="mb-4">
                    <?= genderSelect("ma_dm", "ma_dm", "Danh mục", $danhmuc_list, $tl->ma_dm ?? null)?>
                </div>

                <input type="hidden" name="id" value="<?= isset($tl->id) ? htmlspecialchars($tl->id) : null ?>"/>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Thể Loại" : "Lưu Thể Loại" ?></button>
            </form>
        </div>
    </div>
</div>