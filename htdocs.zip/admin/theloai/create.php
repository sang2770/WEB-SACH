<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/theloai.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_tl = $_POST['ten_tl'];
    $ma_dm = $_POST['ma_dm'] ?? '';
    if (get_tl_by_name($ten_tl)) {
        setMessage("danger", "Thể loại đã tồn tại!");
        redirectTo("index.php?tab=tab-form");
    }
    create_tl($ten_tl, $ma_dm);
    setMessage("info", "Thêm thể loại thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_tl = $_POST['ten_tl'];
    $ma_dm = $_POST['ma_dm'];
    update_tl_by_id($id, $ten_tl, $ma_dm);
    setMessage("info", "Cập nhật thể loại thành công!");
    redirectTo("index.php");
}
?>