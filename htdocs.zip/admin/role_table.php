<div class="card mt-1">
    <div class="card-body">
        <table class="table align-middle">
            <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Quyền</th>
                <th scope="col">Số lượng thành viên</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            foreach ($role_data as $role) {
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                echo '<td>' . $role['name'] . '</td>';
                echo '<td>' . $role['user_count'] . '</td>';
                echo '</tr>';
                $i++;
            }
            ?>
            </tbody>
        </table>
    </div>
</div>