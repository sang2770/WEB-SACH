<?php
require_once "../../helper/config.php";
require_once "../../helper/common.php";
require_once "../../helper/phieuxuat.php";
require_once "../../lib/vendor/autoload.php"; // Chèn tệp autoload của Composer

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

$search = isset($_GET['search']) ? $_GET['search'] : "";
$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    // Lấy phiếu xuất theo id
    $phieuxuat_lst = get_phieuxuat_by_id($id);
} else {
    // Lấy tất cả phiếu xuất chỉ có status = 2
    $phieuxuat_lst = get_phieuxuatall($search);
}

// Tạo đối tượng Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Tiêu đề bảng
$header = array('STT', 'Mã Phiếu Xuất', 'Ngày Tạo', 'Người Tạo', 'Họ tên', 'Địa chỉ', 'Số điện thoại', 'Mã Sách', 'Tên Sách', 'Số Lượng', 'Đơn Vị Tính', 'Giá Vốn', 'Giá Bán', 'Tổng tiền');

// Đặt tiêu đề bảng
$sheet->fromArray($header, NULL, 'A1');

// Căn chỉnh và tô màu tiêu đề bảng
$sheet->getStyle('A1:N1')->getFont()->setBold(true);
$sheet->getStyle('A1:N1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A1:N1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('00B050'); // Màu xanh lá cây

$row = 2; // Bắt đầu từ hàng thứ 2 vì hàng 1 là tiêu đề bảng
$total_all = 0; // Biến để lưu trữ tổng tiền của tất cả các phiếu xuất

foreach ($phieuxuat_lst as $index => $px) {
    $sach_lst = get_sach_by_phieuxuat($px['ma_px']);
    $startRow = $row;

    if (!empty($sach_lst)) {
        foreach ($sach_lst as $sach) {
            // Chuyển giá trị có ký tự "," thành số thực
            $so_luong = (float)str_replace(',', '', $sach['so_luong']);
            $gia_ban = (float)str_replace(',', '', $sach['gia_ban']);
            $tong_tien = $so_luong * $gia_ban; // Tính tổng tiền
            $total_all += $tong_tien; // Cộng dồn tổng tiền vào biến tổng

            $sheet->setCellValue("A{$row}", $index + 1);
            $sheet->setCellValue("B{$row}", $px['ma_px']);
            $sheet->setCellValue("C{$row}", $px['ngay_tao']);
            $sheet->setCellValue("D{$row}", $px['username']);
            $sheet->setCellValue("E{$row}", $px['ho_ten']);
            $sheet->setCellValue("F{$row}", $px['dia_chi']);
            $sheet->setCellValue("G{$row}", $px['sdt']);
            $sheet->setCellValue("H{$row}", $sach['ma_sach']);
            $sheet->setCellValue("I{$row}", $sach['ten_sach']);
            $sheet->setCellValue("J{$row}", $so_luong);
            $sheet->setCellValue("K{$row}", $sach['ten_dvt']);
            $sheet->setCellValue("L{$row}", $gia_ban);
            $sheet->setCellValue("M{$row}", $gia_ban); // Assign giá bán
            $sheet->setCellValue("N{$row}", $tong_tien); // Thêm tổng tiền vào ô

            // Định dạng các giá trị số trong cột L, M, N thành định dạng có dấu phẩy
            $sheet->getStyle("L{$row}:N{$row}")
                ->getNumberFormat()
                ->setFormatCode('#,##0');
            $row++;
        }

        // Hợp nhất các ô cho cột từ STT đến Số điện thoại
        $endRow = $row - 1;
        $sheet->mergeCells("A{$startRow}:A{$endRow}");
        $sheet->mergeCells("B{$startRow}:B{$endRow}");
        $sheet->mergeCells("C{$startRow}:C{$endRow}");
        $sheet->mergeCells("D{$startRow}:D{$endRow}");
        $sheet->mergeCells("E{$startRow}:E{$endRow}");
        $sheet->mergeCells("F{$startRow}:F{$endRow}");
        $sheet->mergeCells("G{$startRow}:G{$endRow}");
        $sheet->getStyle("A{$startRow}:G{$endRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    } else {
        // Phiếu xuất không có sách nào
        $sheet->setCellValue("A{$row}", $index + 1);
        $sheet->setCellValue("B{$row}", $px['ma_px']);
        $sheet->setCellValue("C{$row}", $px['ngay_tao']);
        $sheet->setCellValue("D{$row}", $px['username']);
        $sheet->setCellValue("E{$row}", $px['ho_ten']);
        $sheet->setCellValue("F{$row}", $px['dia_chi']);
        $sheet->setCellValue("G{$row}", $px['sdt']);
        $sheet->setCellValue("H{$row}", 'Không có sách nào.');
        $row++;
    }
}

// Thêm tổng tiền của tất cả phiếu xuất vào cuối bảng
$sheet->setCellValue("M{$row}", 'Tổng tiền tất cả phiếu:');
$sheet->setCellValue("N{$row}", $total_all);
$sheet->getStyle("N{$row}")
    ->getNumberFormat()
    ->setFormatCode('#,##0');
$sheet->getStyle("M{$row}:N{$row}")->getFont()->setBold(true);

// Định dạng chiều rộng cột
foreach (range('A', 'N') as $columnID) {
    $sheet->getColumnDimension($columnID)->setAutoSize(true);
}

// Áp dụng viền cho tất cả các ô có dữ liệu
$sheet->getStyle("A1:N" . ($row))->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

// Xuất file Excel
$writer = new Xlsx($spreadsheet);
$filename = 'phieuxuat.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment;filename=\"{$filename}\"");
header('Cache-Control: max-age=0');

$writer->save('php://output');
exit;