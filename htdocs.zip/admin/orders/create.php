<?php
global $conn;
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/phieunhap.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    // Lấy dữ liệu nhà cung cấp và thông tin khác của phiếu nhập
    $nguoi_tao = $_SESSION['user_id']; // Giả định bạn lưu ID người tạo trong session
    $ngay_tao = date("Y-m-d H:i:s");
    $ho_ten = $_POST['ho_ten'];
    $sdt = $_POST['sdt'];
    $dia_chi = $_POST['dia_chi'];
    $ma_px = uniqid('PX'); // Tạo mã phiếu nhập duy nhất
    try {
        // Thêm dữ liệu vào bảng phieunhap
        $query_pn = "INSERT INTO phieuxuat (nguoi_tao, ngay_tao, ma_px, ho_ten, sdt, dia_chi) VALUES (?, ?, ?, ?,?,?)";
        $stmt_pn = $conn->prepare($query_pn);
        if ($stmt_pn === false) {
            throw new Exception($conn->error);
        }
        $stmt_pn->bind_param('ssssss', $nguoi_tao, $ngay_tao, $ma_px, $ho_ten, $sdt, $dia_chi);
        $stmt_pn->execute();

        // Lấy ID phiếu nhập vừa tạo
        $phieu_nhap_id = $conn->insert_id;

        // Lấy danh sách sách cùng với số lượng và giá
        $sach_ids = $_POST['sach'];
        $so_luong = $_POST['so_luong'];
        $gia = $_POST['gia'];

        // Thêm dữ liệu vào bảng chi_tiet_phieu_nhap
        $query_ct_pn = "INSERT INTO chi_tiet_phieu_xuat (ma_sach, so_luong, gia, ma_px) VALUES (?, ?, ?, ?)";
        $stmt_ct_pn = $conn->prepare($query_ct_pn);
        if ($stmt_ct_pn === false) {
            throw new Exception($conn->error);
        }

        foreach ($sach_ids as $index => $ma_sach) {
            $current_so_luong = $so_luong[$index];
            $current_gia = (int) $gia[$index];
            $stmt_ct_pn->bind_param('siis', $ma_sach, $current_so_luong, $current_gia, $ma_px);
            $stmt_ct_pn->execute();
        }

        $conn->commit();
        setMessage("info", "Thêm phiếu xuất thành công");
        redirectTo("index.php");
    } catch (Exception $e) {
        $conn->rollback();
        setMessage("danger", "Đã xảy ra lỗi: " . $e->getMessage());
        redirectTo("index.php");
    }
}
if (isset($_GET['status']) && $_GET['status'] == "confirm") {
    $id = $_GET['ma_px'];

    $phieu_nhap = get_sach_by_phieunhap($id);
    foreach ($phieu_nhap as $pn) {
        $query_book = "UPDATE sach SET so_luong = so_luong - ? WHERE ma_sach = ?";
        $stmt_book = $conn->prepare($query_book);
        $stmt_book->bind_param('is', $pn['so_luong'], $pn['ma_sach']);
        $stmt_book->execute();
    }
    $query = "UPDATE phieuxuat SET trang_thai = 2, nguoi_cap_nhat = ? WHERE ma_px = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('is', $user_id, $id);
    $stmt->execute();
    setMessage("success", "Xác nhận phiếu xuất thành công");
    redirectTo("index.php");
}

if (isset($_GET['status']) && $_GET['status'] == "cancel") {
    $id = $_GET['ma_px'];
    $query = "UPDATE phieuxuat SET trang_thai = 3, nguoi_cap_nhat = ? WHERE ma_px = ?";
    $stmt = $conn->prepare($query);
    $user_id = getSession("user_id");
    $stmt->bind_param('is', $user_id, $id);
    $stmt->execute();
    setMessage("success", "Huỷ thành công");
    redirectTo("index.php");
}

?>