-- Bảng lưu thông tin đơn hàng
CREATE TABLE don_hang (
    id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ngay_dat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ho_ten VARCHAR(255) NOT NULL,
    sdt VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    dia_chi VARCHAR(500) NOT NULL,
    ghi_chu TEXT,
    tong_tien DECIMAL(15,2) NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id),
    status VARCHAR(255) DEFAULT 'Chờ xử lý'
);

-- Bảng lưu chi tiết đơn hàng
CREATE TABLE chi_tiet_don_hang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_don_hang INT NOT NULL,
    ma_sach INT NOT NULL,
    so_luong INT NOT NULL,
    gia DECIMAL(15,2) NOT NULL,
    thanh_tien DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (ma_don_hang) REFERENCES don_hang(id),
    FOREIGN KEY (ma_sach) REFERENCES sach(id)
);





DROP TABLE IF EXISTS `thanhly`;
CREATE TABLE `thanhly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nguoi_tao` int DEFAULT NULL,
  `nguoi_cap_nhat` int DEFAULT NULL,
  `ma_tl` varchar(255) DEFAULT NULL,
  `trang_thai` int DEFAULT '1',
  `ngay_tao` datetime DEFAULT NULL,
  `dia_chi` text,
  `sdt` varchar(20) DEFAULT NULL,
  `ngay_cap_nhat` datetime DEFAULT NULL,
  `ho_ten` varchar(255) DEFAULT NULL,
  `ly_do` TEXT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `thanhly_pk` (`ma_tl`),
  KEY `thanhly___fk` (`nguoi_tao`),
  KEY `thanhly___fk_2` (`nguoi_cap_nhat`),
  CONSTRAINT `thanhly___fk` FOREIGN KEY (`nguoi_tao`) REFERENCES `user` (`id`),
  CONSTRAINT `thanhly___fk_2` FOREIGN KEY (`nguoi_cap_nhat`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `chi_tiet_thanh_ly`;

CREATE TABLE `chi_tiet_thanh_ly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `gia` int DEFAULT NULL,
  `ma_tl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chi_tiet_thanh_ly___fk` (`ma_sach`),
  KEY `chi_tiet_thanh_ly___fk_2` (`ma_tl`),
  CONSTRAINT `chi_tiet_thanh_ly___fk` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`),
  CONSTRAINT `chi_tiet_thanh_ly___fk_2` FOREIGN KEY (`ma_tl`) REFERENCES `thanhly` (`ma_tl`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
