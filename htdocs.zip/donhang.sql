-- Bảng lưu thông tin đơn hàng
CREATE TABLE don_hang (
    id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ngay_dat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ho_ten VARCHAR(255) NOT NULL,
    sdt VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    dia_chi VARCHAR(500) NOT NULL,
    ghi_chu TEXT,
    tong_tien DECIMAL(15,2) NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id),
    status VARCHAR(255) DEFAULT 'Chờ xử lý'
);

-- Bảng lưu chi tiết đơn hàng
CREATE TABLE chi_tiet_don_hang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_don_hang INT NOT NULL,
    ma_sach INT NOT NULL,
    so_luong INT NOT NULL,
    gia DECIMAL(15,2) NOT NULL,
    thanh_tien DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (ma_don_hang) REFERENCES don_hang(id),
    FOREIGN KEY (ma_sach) REFERENCES sach(id)
);
