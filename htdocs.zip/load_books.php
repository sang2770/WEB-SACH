<style>
    .card-img, .card-img-top {
    border-top-left-radius: calc(.5rem - 1px);
    border-top-right-radius: calc(.5rem - 1px);
    aspect-ratio: 1 / 1;
    object-fit: scale-down;
}
</style>
<?php
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

// Nhận dữ liệu từ form lọc và tìm kiếm
$sort_price = isset($_POST['sort_price']) ? $_POST['sort_price'] : '';
$theloai = isset($_POST['theloai']) ? $_POST['theloai'] : '';
$tacgia = isset($_POST['tacgia']) ? $_POST['tacgia'] : '';
$nhaxuatban = isset($_POST['nhaxuatban']) ? $_POST['nhaxuatban'] : '';
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Xây dựng câu truy vấn
$sql = "
    SELECT sach.ma_sach, sach.ten_sach, tacgia.ten_tg, nhaxuatban.ten_nxb as nha_xuat_ban, sach.hinh_anh, sach.gia, theloai.ten_tl
    FROM sach
    JOIN theloai ON sach.ma_tl = theloai.ma_tl
    JOIN tacgia ON sach.ma_tg = tacgia.ma_tg
    JOIN nhaxuatban ON sach.ma_nxb = nhaxuatban.ma_nxb
    WHERE sach.is_active = 1 AND sach.so_luong > 0
";

if ($theloai) {
    $sql .= " AND sach.ma_tl = '{$theloai}'";
}
if ($tacgia) {
    $sql .= " AND sach.ma_tg = '{$tacgia}'";
}
if ($nhaxuatban) {
    $sql .= " AND sach.ma_nxb = '{$nhaxuatban}'";
}
if ($search) {
    $sql .= " AND sach.ten_sach LIKE '%{$search}%'";
}

if ($sort_price) {
    if ($sort_price == 'asc') {
        $sql .= " ORDER BY sach.gia ASC";
    } elseif ($sort_price == 'desc') {
        $sql .= " ORDER BY sach.gia DESC";
    }
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo '
        <div class="col-lg-3 col-md-4 mb-4 d-flex align-items-stretch">
            <div class="card">
                <img src="' . $row["hinh_anh"] . '" class="card-img-top" alt="' . $row["ten_sach"] . '">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">' . $row["ten_sach"] . '</h5>
                    <p class="card-text">Giá: ' . number_format($row["gia"], 0, ',', '.') . ' VND</p>
                    <p class="card-text">Nhà xuất bản: ' . $row["nha_xuat_ban"] . '</p>
                    <p class="card-text">Tác giả: ' . $row["ten_tg"] . '</p>
                    <p class="card-text">Thể loại: ' . $row["ten_tl"] . '</p>
                    <button class="btn btn-primary mt-auto add-to-cart" data-book-id="' . $row["ma_sach"] . '" data-price="' . $row["gia"] . '">Thêm vào giỏ hàng</button>
                </div>
            </div>
        </div>';
    }
} else {
    echo "Không có sách nào khớp với tiêu chí lọc.";
}

$conn->close();
?>