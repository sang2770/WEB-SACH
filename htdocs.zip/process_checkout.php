<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

// Kiểm tra người dùng đã đăng nhập
if (!isLogined()) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ho_ten = $_POST['ho_ten'];
    $sdt = $_POST['sdt'];
    $email = $_POST['email'] ?? '';
    $dia_chi = $_POST['dia_chi'];
    $ghi_chu = $_POST['ghi_chu'] ?? '';
    $tinh_name = $_POST['tinh_name'];
    $huyen_name = $_POST['huyen_name'];
    $xa_name = $_POST['xa_name'];
    
    // Xây dựng địa chỉ đầy đủ
    $dia_chi_day_du = $dia_chi . ', ' . $xa_name . ', ' . $huyen_name . ', ' . $tinh_name;
    
    // Lấy danh sách sách từ giỏ hàng
    $sql = "SELECT sach.id as ma_sach, cart.so_luong, sach.ten_sach, sach.gia, (cart.so_luong * sach.gia) AS thanh_tien 
            FROM cart 
            JOIN sach ON cart.ma_sach = sach.ma_sach 
            WHERE cart.user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $cart_items = [];
    $tong_tien = 0;

    while ($row = $result->fetch_assoc()) {
        $cart_items[] = $row;
        $tong_tien += $row['thanh_tien'];
    }

    $stmt->close();

    // Lấy ID người dùng từ session
    $user_id = $_SESSION['user_id']; 

    // Lưu thông tin đơn hàng vào bảng `don_hang`
    $stmt = $conn->prepare("INSERT INTO don_hang (ho_ten, sdt, email, dia_chi, ghi_chu, tong_tien, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssddi", $ho_ten, $sdt, $email, $dia_chi_day_du, $ghi_chu, $tong_tien, $user_id);
    $stmt->execute();
    $ma_don_hang = $stmt->insert_id;

    // Lưu chi tiết đơn hàng vào bảng `chi_tiet_don_hang`
    foreach ($cart_items as $item) {
        $ma_sach = $item['ma_sach'];
        $so_luong = $item['so_luong'];
        $gia = $item['gia'];
        $thanh_tien = $so_luong * $gia;
        $stmt_detail = $conn->prepare("INSERT INTO chi_tiet_don_hang (ma_don_hang, ma_sach, so_luong, gia, thanh_tien) VALUES (?, ?, ?, ?, ?)");
        $stmt_detail->bind_param("iisdd", $ma_don_hang, $ma_sach, $so_luong, $gia, $thanh_tien);
        $stmt_detail->execute();
        if ($stmt_detail->error) {
            echo "Không thể lưu chi tiết đơn hàng cho mã sách: $ma_sach.<br>";
            echo $stmt_detail->error;   
        }else{
            echo "Lưu chi tiết đơn hàng cho mã sách: $ma_sach thành công.<br>";
        }
        $stmt_detail->close();
    }

    // Xóa giỏ hàng sau khi đặt hàng thành công
    $sql_delete_cart = "DELETE FROM cart WHERE user_id = ?";
    $stmt_delete_cart = $conn->prepare($sql_delete_cart);
    $stmt_delete_cart->bind_param("i", $user_id);
    $stmt_delete_cart->execute();
    $stmt_delete_cart->close();

    // Chuyển hướng đến trang hiển thị thông tin đơn hàng
    header('Location: user_orders.php');
    // exit();
}
?>
