-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: localhost    Database: websach
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `gia` float DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart___fk` (`ma_sach`),
  KEY `cart___fk_2` (`user_id`),
  CONSTRAINT `cart___fk` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`),
  CONSTRAINT `cart___fk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chi_tiet_hoa_don`
--

DROP TABLE IF EXISTS `chi_tiet_hoa_don`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chi_tiet_hoa_don` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `gia` int DEFAULT NULL,
  `id_hoadon` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `chi_tiet_hoa_don___fk` (`ma_sach`),
  KEY `chi_tiet_hoa_don___fk_2` (`id_hoadon`),
  CONSTRAINT `chi_tiet_hoa_don___fk` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`),
  CONSTRAINT `chi_tiet_hoa_don___fk_2` FOREIGN KEY (`id_hoadon`) REFERENCES `hoa_don` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chi_tiet_hoa_don`
--

LOCK TABLES `chi_tiet_hoa_don` WRITE;
/*!40000 ALTER TABLE `chi_tiet_hoa_don` DISABLE KEYS */;
INSERT INTO `chi_tiet_hoa_don` VALUES (1,'BOOK1',2,100000,1),(2,'BOOK2',2,200000,1),(3,'BOOK3',3,100000,1),(4,'BOOK1',2,100000,2),(5,'BOOK2',2,200000,2);
/*!40000 ALTER TABLE `chi_tiet_hoa_don` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chi_tiet_phieu_nhap`
--

DROP TABLE IF EXISTS `chi_tiet_phieu_nhap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chi_tiet_phieu_nhap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `gia` int DEFAULT NULL,
  `ma_pn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chi_tiet_phieu_nhap___fk` (`ma_sach`),
  KEY `chi_tiet_phieu_nhap___fk_2` (`ma_pn`),
  CONSTRAINT `chi_tiet_phieu_nhap___fk` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`),
  CONSTRAINT `chi_tiet_phieu_nhap___fk_2` FOREIGN KEY (`ma_pn`) REFERENCES `phieunhap` (`ma_pn`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chi_tiet_phieu_nhap`
--

LOCK TABLES `chi_tiet_phieu_nhap` WRITE;
/*!40000 ALTER TABLE `chi_tiet_phieu_nhap` DISABLE KEYS */;
INSERT INTO `chi_tiet_phieu_nhap` VALUES (1,'BOOK1',10,100000,'PN673e18e1e85fb'),(2,'BOOK2',10,20000,'PN673e18e1e85fb'),(3,'BOOK3',12,200000,'PN673fb70f17faa'),(4,'BOOK4',10,100000,'PN673fb70f17faa');
/*!40000 ALTER TABLE `chi_tiet_phieu_nhap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chi_tiet_phieu_xuat`
--

DROP TABLE IF EXISTS `chi_tiet_phieu_xuat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chi_tiet_phieu_xuat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `gia` int DEFAULT NULL,
  `ma_px` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chi_tiet_phieu_xuat___fk` (`ma_sach`),
  KEY `chi_tiet_phieu_xuat___fk_2` (`ma_px`),
  CONSTRAINT `chi_tiet_phieu_xuat___fk` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`),
  CONSTRAINT `chi_tiet_phieu_xuat___fk_2` FOREIGN KEY (`ma_px`) REFERENCES `phieuxuat` (`ma_px`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chi_tiet_phieu_xuat`
--

LOCK TABLES `chi_tiet_phieu_xuat` WRITE;
/*!40000 ALTER TABLE `chi_tiet_phieu_xuat` DISABLE KEYS */;
INSERT INTO `chi_tiet_phieu_xuat` VALUES (1,'BOOK1',1,100000,'PX673ffdfadcee4'),(2,'BOOK3',2,200000,'PX673ffdfadcee4'),(3,'BOOK4',1,100000,'PX_67400aa797a14'),(4,'BOOK2',1,200000,'PX_67400aa797a14'),(5,'BOOK1',1,100000,'PX_67400b0abb208'),(6,'BOOK2',1,200000,'PX_67400b0abb208'),(7,'BOOK3',1,100000,'PX_67400b0abb208'),(8,'BOOK1',1,100000,'PX_67400db637f6d'),(9,'BOOK2',1,200000,'PX_67400db637f6d'),(10,'BOOK3',1,100000,'PX_67400db637f6d'),(11,'BOOK3',1,100000,'PX_67400eb0de0d2'),(12,'BOOK2',1,200000,'PX_67400eb0de0d2'),(13,'BOOK1',1,100000,'PX_67400eb0de0d2'),(14,'BOOK1',2,100000,'PX_67400f47296cd'),(15,'BOOK2',2,200000,'PX_67400f47296cd'),(16,'BOOK1',2,100000,'PX_6740153179e20'),(17,'BOOK2',2,200000,'PX_6740153179e20'),(18,'BOOK1',1,200000,'PX675075388fc55'),(19,'BOOK1',1,100000,'PX67507554c606a');
/*!40000 ALTER TABLE `chi_tiet_phieu_xuat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `danhmuc`
--

DROP TABLE IF EXISTS `danhmuc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `danhmuc` (
  `ma_dm` varchar(255) DEFAULT NULL,
  `ten_dm` varchar(255) NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `danhmuc_pk` (`ma_dm`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `danhmuc`
--

LOCK TABLES `danhmuc` WRITE;
/*!40000 ALTER TABLE `danhmuc` DISABLE KEYS */;
INSERT INTO `danhmuc` (`ma_dm`, `ten_dm`, `id`, `is_active`) VALUES
('DM1', 'sách kinh tế', 1, 1),
('DM2', 'sách văn học', 2, 1),
('DM3', 'sách đời sống xã hội', 3, 1),
('DM4', 'sách thiếu nhi', 4, 1),
('DM5', 'sách giáo khoa - giáo trình', 5, 1),
('DM6', 'sách ngoại ngữ', 6, 1);
UNLOCK TABLES;

--
-- Table structure for table `donvitinh`
--

DROP TABLE IF EXISTS `donvitinh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donvitinh` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_dvt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `donvitinh_pk` (`ma_dvt`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donvitinh`
--

LOCK TABLES `donvitinh` WRITE;
/*!40000 ALTER TABLE `donvitinh` DISABLE KEYS */;
INSERT INTO `donvitinh` VALUES (1,'DVT1','Quyển',1),(2,'DVT2','Cuốn1',1);
/*!40000 ALTER TABLE `donvitinh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gia`
--

DROP TABLE IF EXISTS `gia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_gia` varchar(255) DEFAULT NULL,
  `ten_gia` varchar(255) DEFAULT NULL,
  `tinh_trang` varchar(255) DEFAULT NULL,
  `ma_tuke` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gia_pk` (`ma_gia`),
  KEY `gia___fk` (`ma_tuke`),
  CONSTRAINT `gia___fk` FOREIGN KEY (`ma_tuke`) REFERENCES `tuke` (`ma_tuke`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gia`
--

LOCK TABLES `gia` WRITE;
/*!40000 ALTER TABLE `gia` DISABLE KEYS */;

INSERT INTO `gia` (`id`, `ma_gia`, `ten_gia`, `tinh_trang`, `ma_tuke`, `is_active`) VALUES
(1, 'G1', 'Ngoại thương', 'Đang hoạt động ', 'TK1', 1),
(2, 'G2', 'Marketing - Bán Hàng', 'Đang hoạt động ', 'TK1', 1),
(3, 'G3', 'Nhân Sự & Việc Làm', 'Đang hoạt động ', 'TK1', 1),
(4, 'G4', 'Nhân Vật & Bài Học Kinh Doanh', 'Đang hoạt động ', 'TK1', 1),
(5, 'G5', 'Phân Tích & Môi Trường Kinh Tế', 'Đang hoạt động ', 'TK1', 1),
(6, 'G6', 'Tài Chính & Tiền Tệ', 'Đang hoạt động ', 'TK1', 1),
(7, 'G7', 'Tài Chính – Kế Toán', 'Đang hoạt động ', 'TK1', 1),
(8, 'G8', 'Sách Luật', 'Đang hoạt động ', 'TK1', 1),
(9, 'G9', 'Khởi nghiệp', 'Đang hoạt động ', 'TK1', 1),
(10, 'G2-1', 'Cổ tích thần thoại', 'Đang hoạt động', 'TK2', 1),
(11, 'G2-2', 'Nhân Vật Văn Học/Nhân Vật Lịch Sử', 'Đang hoạt động', 'TK2', 1),
(12, 'G2-3', 'Thơ Ca', 'Đang hoạt động', 'TK2', 1),
(13, 'G2-4', 'Tiểu Thuyết', 'Đang hoạt động', 'TK2', 1),
(14, 'G2-5', 'Truyện & Thơ Ca Dân Gian', 'Đang hoạt động', 'TK2', 1),
(15, 'G2-6', 'Truyện Giả Tưởng – Thần Bí', 'Đang hoạt động', 'TK2', 1),
(16, 'G2-7', 'Truyện Kiếm Hiệp', 'Đang hoạt động', 'TK2', 1),
(17, 'G2-8', 'Trinh Thám- Vụ Án', 'Đang hoạt động', 'TK2', 1),
(18, 'G2-9', 'Tự Truyện - Hồi Ký', 'Đang hoạt động', 'TK2', 1),
(19, 'G3-1', 'Khoa học cơ bản', 'Đang hoạt động', 'TK3', 1),
(20, 'G3-2', 'Khoa học kĩ thuật', 'Đang hoạt động', 'TK3', 1),
(21, 'G3-3', 'Bí Quyết Làm Đẹp', 'Đang hoạt động', 'TK3', 1),
(22, 'G3-4', 'Gia Đình - Nuôi Dạy Con', 'Đang hoạt động', 'TK3', 1),
(23, 'G3-5', 'Nhà Ở - Vật Nuôi', 'Đang hoạt động', 'TK3', 1),
(24, 'G3-6', 'Sách Tâm Lý - Giới Tính', 'Đang hoạt động', 'TK3', 1),
(25, 'G3-7', 'Nữ Công Gia Chánh', 'Đang hoạt động', 'TK3', 1),
(26, 'G3-8', 'Y học', 'Đang hoạt động', 'TK3', 1),
(27, 'G4-1', 'Văn học thiếu nhi', 'Đang hoạt động', 'TK4', 1),
(28, 'G4-2', 'Kiến thức – Kỹ năng cho trẻ', 'Đang hoạt động', 'TK4', 1),
(29, 'G4-3', 'Tranh truyện', 'Đang hoạt động', 'TK4', 1),
(30, 'G5-1', 'Cấp 1', 'Đang hoạt động', 'TK5', 1),
(31, 'G5-2', 'Cấp 2', 'Đang hoạt động', 'TK5', 1),
(32, 'G5-3', 'Cấp 3', 'Đang hoạt động', 'TK5', 1),
(33, 'G5-4', 'Bộ Sách Giáo Khoa', 'Đang hoạt động', 'TK5', 1),
(34, 'G5-5', 'Sách Tham Khảo', 'Đang hoạt động', 'TK5', 1),
(35, 'G6-1', 'Tiếng Anh', 'Đang hoạt động', 'TK6', 1),
(36, 'G6-2', 'Tiếng Nhật', 'Đang hoạt động', 'TK6', 1),
(37, 'G6-3', 'Tiếng Trung', 'Đang hoạt động', 'TK6', 1),
(38, 'G6-4', 'Tiếng Hàn', 'Đang hoạt động', 'TK6', 1);
/*!40000 ALTER TABLE `gia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoa_don`
--

DROP TABLE IF EXISTS `hoa_don`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoa_don` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nguoi_tao` int DEFAULT NULL,
  `nguoi_cap_nhat` int DEFAULT NULL,
  `ma_hoadon` varchar(255) DEFAULT NULL,
  `trang_thai` int DEFAULT '1',
  `ngay_tao` datetime DEFAULT NULL,
  `dia_chi` text,
  `sdt` varchar(20) DEFAULT NULL,
  `ngay_cap_nhat` datetime DEFAULT NULL,
  `ho_ten` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hoadon___fk` (`nguoi_tao`),
  KEY `hoadon___fk_2` (`nguoi_cap_nhat`),
  CONSTRAINT `hoadon___fk` FOREIGN KEY (`nguoi_tao`) REFERENCES `user` (`id`),
  CONSTRAINT `hoadon___fk_2` FOREIGN KEY (`nguoi_cap_nhat`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoa_don`
--

LOCK TABLES `hoa_don` WRITE;
/*!40000 ALTER TABLE `hoa_don` DISABLE KEYS */;
INSERT INTO `hoa_don` VALUES (1,4,5,'HD-675073cfcebb2',2,'2024-12-04 14:53:35','Can Tho, Xã Hòa Bắc, Huyện Hòa Vang, Thành phố Đà Nẵng','0794351152',NULL,'Nguyen Van A'),(2,4,NULL,NULL,1,'2024-12-04 15:26:19','Can Tho, Thị trấn Cờ Đỏ, Huyện Cờ Đỏ, Thành phố Cần Thơ','0794351153',NULL,'Nguyen Van B');
/*!40000 ALTER TABLE `hoa_don` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khuyenmai`
--

DROP TABLE IF EXISTS `khuyenmai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `khuyenmai` (
  `ma_km` varchar(255) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `ten_km` varchar(255) DEFAULT NULL,
  `ngay_bat_dau` date DEFAULT NULL,
  `ngay_ket_thuc` date DEFAULT NULL,
  `phan_tram_giam_gia` decimal(5,2) DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `mo_ta` text,
  `is_active` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `khuyenmai_pk_2` (`ma_km`),
  UNIQUE KEY `khuyenmai_pk` (`ma_km`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khuyenmai`
--

LOCK TABLES `khuyenmai` WRITE;
/*!40000 ALTER TABLE `khuyenmai` DISABLE KEYS */;
INSERT INTO `khuyenmai` VALUES ('KM1',1,'Không khuyến mãi','2024-11-06','2024-11-06',0.00,0,'Mặc định',1),('KM2',2,'black sale1','2024-11-13','2024-11-29',10.00,10,'',1),('KM3',3,'black sale2','2024-11-22','2024-11-30',10.00,10,'black sale2',1),('KM4',4,'black sale3','2024-11-20','2024-11-23',10.00,10,'black sale3',1);
/*!40000 ALTER TABLE `khuyenmai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngan`
--

DROP TABLE IF EXISTS `ngan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ngan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_ngan` varchar(255) DEFAULT NULL,
  `ten_ngan` varchar(255) DEFAULT NULL,
  `tinh_trang` varchar(255) DEFAULT NULL,
  `ma_gia` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ngan_pk` (`ma_ngan`),
  UNIQUE KEY `ngan_pk_2` (`ma_ngan`),
  KEY `ngan___fk` (`ma_gia`),
  CONSTRAINT `ngan___fk` FOREIGN KEY (`ma_gia`) REFERENCES `gia` (`ma_gia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ngan`
--

LOCK TABLES `ngan` WRITE;
/*!40000 ALTER TABLE `ngan` DISABLE KEYS */;

INSERT INTO `ngan` (`id`, `ma_ngan`, `ten_ngan`, `tinh_trang`, `ma_gia`, `is_active`) VALUES
(1, 'N1', 'Ngan 111', 'Đang hoạt động', 'G1', 1),
(2, 'N2', 'Ngan 112', 'Đang hoạt động', 'G1', 1),
(3, 'N3', 'Ngan 121', 'Đang hoạt động', 'G2', 1),
(4, 'N4', 'Ngan 122', 'Đang hoạt động', 'G2', 1),
(5, 'N5', 'Ngan 131', 'Đang hoạt động', 'G3', 1),
(6, 'N6', 'Ngan 132', 'Đang hoạt động', 'G3', 1),
(7, 'N7', 'Ngan 141', 'Đang hoạt động', 'G4', 1),
(8, 'N8', 'Ngan 142', 'Đang hoạt động', 'G4', 1),
(9, 'N9', 'Ngan 151', 'Đang hoạt động', 'G5', 1),
(10, 'N10', 'Ngan 152', 'Đang hoạt động', 'G5', 1),
(11, 'N11', 'Ngan 161', 'Đang hoạt động', 'G6', 1),
(12, 'N12', 'Ngan 162', 'Đang hoạt động', 'G6', 1),
(13, 'N13', 'Ngan 171', 'Đang hoạt động', 'G7', 1),
(14, 'N14', 'Ngan 172', 'Đang hoạt động', 'G7', 1),
(15, 'N15 ', 'Ngan 181', 'Đang hoạt động', 'G8', 1),
(16, 'N16', 'Ngan 182', 'Đang hoạt động', 'G8', 1),
(17, 'N17', 'Ngan 191', 'Đang hoạt động', 'G9', 1),
(18, 'N18 ', 'Ngan 192', 'Đang hoạt động', 'G9', 1),
(19, 'N19 ', 'Ngan 211', 'Đang hoạt động', 'G2-1', 1),
(20, 'N20', 'Ngan 212', 'Đang hoạt động', 'G2-1', 1),
(21, 'N21', 'Ngan 221', 'Đang hoạt động', 'G2-2', 1),
(22, 'N22', 'Ngan 222', 'Đang hoạt động', 'G2-3', 1),
(23, 'N23', 'Ngan 231', 'Đang hoạt động', 'G2-3', 1),
(24, 'N24', 'Ngan 232', 'Đang hoạt động', 'G2-4', 1),
(25, 'N25', 'Ngan 241', 'Đang hoạt động', 'G2-4', 1),
(26, 'N26', 'Ngan 242', 'Đang hoạt động', 'G2-5', 1),
(27, 'N27', 'Ngan 251', 'Đang hoạt động', 'G2-5', 1),
(28, 'N28', 'Ngan 252', 'Đang hoạt động', 'G2-6', 1),
(29, 'N29', 'Ngan 261', 'Đang hoạt động', 'G2-6', 1),
(30, 'N30', 'Ngan 262', 'Đang hoạt động', 'G2-7', 1),
(31, 'N31', 'Ngan271', 'Đang hoạt động', 'G2-7', 1),
(32, 'N32', 'Ngan 272', 'Đang hoạt động', 'G2-7', 1),
(33, 'N33', 'Ngan 281', 'Đang hoạt động', 'G2-8', 1),
(34, 'N34', 'Ngan 282', 'Đang hoạt động', 'G2-8', 1),
(35, 'N35', 'Ngan 291', 'Đang hoạt động', 'G2-9', 1),
(36, 'N36', 'Ngan 292', 'Đang hoạt động', 'G2-9', 1),
(37, 'N39', 'Ngan 311', 'Đang hoạt động', 'G3-1', 1),
(38, 'N40', 'Ngan 312', 'Đang hoạt động', 'G3-1', 1),
(39, 'N41', 'Ngan 321', 'Đang hoạt động', 'G3-2', 1),
(40, 'N42', 'Ngan 322', 'Đang hoạt động', 'G3-2', 1),
(41, 'N43', 'Ngan 331', 'Đang hoạt động', 'G3-3', 1),
(42, 'N44', 'Ngan 332', 'Đang hoạt động', 'G3-3', 1),
(43, 'N45', 'Ngan 341', 'Đang hoạt động', 'G3-4', 1),
(44, 'N46', 'Ngan 342', 'Đang hoạt động', 'G3-4', 1),
(45, 'N47', 'Ngan 351', 'Đang hoạt động', 'G3-5', 1),
(46, 'N48', 'Ngan 352 ', 'Đang hoạt động', 'G3-5', 1),
(47, 'N49', 'Ngan 361', 'Đang hoạt động', 'G3-6', 1),
(48, 'N50', 'Ngan 362', 'Đang hoạt động', 'G3-6', 1),
(49, 'N51', 'Ngan 371', 'Đang hoạt động', 'G2-7', 1),
(50, 'N52', 'Ngan 372', 'Đang hoạt động', 'G2-7', 1),
(51, 'N53', 'Ngan 381', 'Đang hoạt động', 'G3-8', 1),
(52, 'N54', 'Ngan 382', 'Đang hoạt động', 'G3-8', 1),
(53, 'N55 ', 'Ngan 411', 'Đang hoạt động', 'G4-1', 1),
(54, 'N56', 'Ngan 412', 'Đang hoạt động', 'G4-1', 1),
(55, 'N57', 'Ngan 421', 'Đang hoạt động', 'G4-2', 1),
(56, 'N58', 'Ngan 422', 'Đang hoạt động', 'G4-2', 1),
(57, 'N59 ', 'Ngan 431', 'Đang hoạt động', 'G4-3', 1),
(58, 'N60 ', 'Ngan 432', 'Đang hoạt động', 'G4-3', 1),
(59, 'N61', 'Ngan 511', 'Đang hoạt động', 'G5-1', 1),
(60, 'N62', 'Ngan 512', 'Đang hoạt động', 'G5-1', 1),
(61, 'N63', 'Ngan 521', 'Đang hoạt động', 'G5-2', 1),
(62, 'N64', 'Ngan 522', 'Đang hoạt động', 'G5-2', 1),
(63, 'N65', 'Ngan 531', 'Đang hoạt động', 'G5-3', 1),
(64, 'N66 ', 'Ngan 532', 'Đang hoạt động', 'G5-3', 1),
(65, 'N67 ', 'Ngan 541', 'Đang hoạt động', 'G5-4', 1),
(66, 'N68 ', 'Ngan 542', 'Đang hoạt động', 'G5-4', 1),
(67, 'N69 ', 'Ngan 551', 'Đang hoạt động', 'G5-1', 1),
(68, 'N70 ', 'Ngan 552', 'Đang hoạt động', 'G5-5', 1),
(69, 'N71', 'Ngan 611', 'Đang hoạt động', 'G6-1', 1),
(70, 'N72', 'Ngan 612', 'Đang hoạt động', 'G6-1', 1),
(71, 'N73', 'Ngan 621', 'Đang hoạt động', 'G6-2', 1),
(72, 'N74', 'Ngan 622', 'Đang hoạt động', 'G6-2', 1),
(73, 'N75', 'Ngan 631', 'Đang hoạt động', 'G6-3', 1),
(74, 'N76', 'Ngan 632', 'Đang hoạt động', 'G6-3', 1),
(75, 'N77', 'Ngan 641', 'Đang hoạt động', NULL, 1),
(76, 'N78', 'Ngan 642', 'Đang hoạt động', 'G6-4', 1);
/*!40000 ALTER TABLE `ngan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhacungcap`
--

DROP TABLE IF EXISTS `nhacungcap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nhacungcap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_ncc` varchar(255) DEFAULT NULL,
  `sdt` varchar(12) DEFAULT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `ten_ncc` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nhacungcap_pk` (`ma_ncc`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhacungcap`
--

LOCK TABLES `nhacungcap` WRITE;
/*!40000 ALTER TABLE `nhacungcap` DISABLE KEYS */;

INSERT INTO `nhacungcap` (`id`, `ma_ncc`, `sdt`, `dia_chi`, `ten_ncc`, `email`, `is_active`) VALUES
(1, 'ncc1', ' 0916574202', '265/79 Nguyễn Thái Sơn, P. 7, Q. Gò Vấp, TP. Hồ Chí Minh', 'Nhà sách Sgbooknet', 'sgbook.net@gmail.com', 1),
(2, 'NCC2', '0283845270', '14/35, Đào Duy Anh, P.9, Q. Phú Nhuận, TP. Hồ Chí Minh ', ' Công Ty TNHH Văn Hóa Việt Long', 'info@vietlonbook.com', 1),
(3, 'NCC3', '098606663', 'Lô 34E, Khu Đấu Giá 3ha, P. Phúc Diễm, Q. Bắc Từ Liêm, Hà Nội', 'Công Ty Cổ Phần Sách Mcbooks', 'thongtinsach@mcbooks.vn', 1),
(4, 'NCC4', '0246253430', ' 289A Khuất Duy Tiến, P. Trung Hòa, Q. Cầu Giấy, Hà Nội', ' Công Ty Cổ Phần Sách Giáo Dục Tại Thành Phố Hà Nộ', 'hongtran27979@gmail.com', 1),
(5, 'NCC5', '0235121977', 'Tầng 4 Tòa Nhà Diamond Flower Tower 48 Lê Văn Lương, P. Nhân Chính, Q. Thanh Xuân Hà Nội', 'Công Ty Cổ Phần Dịch Vụ Xuất Bản Giáo Dục Hà Nội', 'info@xbgdhn.vn', 1),
(6, 'NCC6', '0283861216', '232 Trần Thủ Độ, P. Phú Thạnh, Q. Tân Phú, TP. Hồ Chí Minh ', 'Quỳnh Phát - Công Ty TNHH Thương Mại Dịch Vụ Quỳnh', 'quynhphatbook@yahoo.com', 1),
(7, 'NCC7', '0283822579', '60-62 Lê Lợi, P. Bến Nghé, Q. 1, TP. Hồ Chí Minh ', 'Công Ty Cổ Phần Phát Hành Sách Tp. HCM', ' fahasa-sg@hcm.vnn.vn', 1),
(8, 'NCC8 ', '0283845270', '14/35, Đào Duy Anh, P.9, Q. Phú Nhuận, TP. Hồ Chí Minh', 'Công Ty TNHH Văn Hóa Việt Long', ' info@vietlonbook.com', 1),
(9, 'NCC9', ' 0258576500', 'Tầng 5, Số 23 Hoàng Văn Thái, P. Khương Mai, Q. Thanh Xuân, Hà Nội', 'CTY Trực Tuyến Atlazbooks', ' info@atlazbooks.com', 1),
(10, 'NCC10', ' 02462559966', 'Tầng 2, Số 46 Tân ấp, P. Phúc Xá, Q. Ba Đình, Hà Nội', 'Công Ty Cổ Phần Truyền Thông Và Xuất Bản Amak', ' info@amak.vn', 1);
UNLOCK TABLES;

--
-- Table structure for table `nhaxuatban`
--

DROP TABLE IF EXISTS `nhaxuatban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nhaxuatban` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_nxb` varchar(255) DEFAULT NULL,
  `sdt` varchar(255) NOT NULL,
  `dia_chi` varchar(255) NOT NULL,
  `ten_nxb` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nhaxuatban_pk` (`ma_nxb`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhaxuatban`
--

LOCK TABLES `nhaxuatban` WRITE;
/*!40000 ALTER TABLE `nhaxuatban` DISABLE KEYS */;
INSERT INTO `nhaxuatban` (`id`, `ma_nxb`, `sdt`, `dia_chi`, `ten_nxb`, `email`, `is_active`) VALUES
(1, 'NXB1', '0984223522', 'Ha Noi', 'NXB Trẻ', 'nxbtre@gmail.com', 1),
(2, 'NXB2', '0923233442', 'Ha Noi', 'Hà Nội', 'sachhanoi@gmail.com', 1),
(3, 'NXB3', '0128362781', 'Ba Đình ,Hà ', 'Lao Động ', 'laodongvn@gmail.com', 1),
(4, 'NXB4', '1900571595', '55 Quang Trung, Hai Bà Trưng, Hà ', 'Kim Đồng', 'info@nxbkimdong.com.vn', 1),
(5, 'NXB5', '0238256804', '62 Nguyễn Thị Minh Khai, Phường Đa Kao, Quận 1, TP HCM', 'Tổng hợp thành phố Hồ Chí Minh', 'nstonghop@gmail.com', 1),
(6, 'NXB6', ' 0243822219', 'Số 65 Nguyễn Du, Hà Nội', 'Hội Nhà văn', 'nxbhoinhavan65@gmail.com', 1),
(7, 'NXB7', '0286290908', 'Số 35 Trần Quốc Toản, Hoàn Kiếm, Hà Nội', 'Tư pháp', 'nxbtp@moj.gov.vn', 1),
(8, 'NXB8', '0243757214', 'Tầng 6, tòa nhà 115 Trần Duy Hưng, Hà Nội', 'Thông tin và Truyền thông', 'nxb.tttt@mic.gov.vn', 1),
(9, 'NXB9', '0243971489', '16 Hàng Chuối, Phạm Đình Hổ, Hai Bà Trưng, Hà Nội', 'đại học quốc gia Hà Nội', 'nxb@vnu.edu.vn', 1),
(10, 'NXB10', '0243822080', ' Số 81 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội', 'Nhà xuất bản Giáo dục Việt Nam', 'gdvn@gmail.com', 1),
(11, 'NXB11', '0982526569', '64 Bà Triệu, Hoàn Kiếm, Hà Nội', 'Nhà xuất bản Thanh niên', 'nxbthanhnien@gmail.com', 1),
(12, 'NXB12', '02439260024', ' Số 65, phố Tràng Thi, Phường Hàng Bông, Quận Hoàn Kiếm, Hà Nội', 'Nhà xuất bản Hồng Đức', 'nhaxuatbanhongduc65@gmail.com', 1),
(32, 'NXB13', '02437547735 ', 'Tầng 6, Toà nhà số 128, đường Xuân Thuỷ, phường Dịch Vọng Hậu, quận Cầu Giấy, Thành phố Hà Nội', 'Nhà xuất bản Đại học sư phạm', 'nxb@hnue.edu.vn', 1),
(33, 'NXB14', ' 0386845697', 'Nhà E – Ngõ 17 – Tạ Quang Bửu – Hai Bà Trưng – Hà Nội', 'Nhà xuất bản Đại học Bách khoa Hà Nội', 'nxbbk@hust.edu.vn', 1),
(40, 'NXB20', ' 0243926002', 'Số 65, phố Tràng Thi, Phường Hàng Bông, Quận Hoàn Kiếm, Hà Nội', 'Nhà xuất bản Hồng Đức', 'nhaxuatbanhongduc65@gmail.com', 1),
(41, 'NXB15', '0243971071', '39 Hàng Chuối, Q. Hai Bà Trưng, Hà Nội', 'Nhà xuất bản Phụ nữ Việt Nam', 'truyenthongvaprnxbpn@gmail.com', 1),
(42, 'NXB16', '0923923612', '26 Lý Thường Kiệt, P. Hàng Bài, Q. Hoàn Kiếm Hà Nội', 'Nhà xuất bản Khoa học xã hội', 'lehuongkhxh@gmail.com', 1),
(43, 'NXB17', '0239454661', 'Tầng 1 – Tòa nhà VUSTA – 53 Nguyễn Du – Quận Hai Bà Trưng – Hà Nội – Việt Nam', 'Nhà xuất bản Tri thức', 'lienhe@nxbtrithuc.com.vn', 1),
(44, 'NXB18', '038253841', '46 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội', 'Nhà xuất bản Thế giới', 'thegioi@hn.vnn.vn', 1),
(45, 'NXB19', '0247161518', '18 Nguyễn Trường Tộ, phường Trúc Bạch, quận Ba Đình, thành phố Hà Nội', 'Nhà xuất bản Văn học', 'info@nxbvanhoc.com.vn', 1);
UNLOCK TABLES;

--
-- Table structure for table `phieunhap`
--

DROP TABLE IF EXISTS `phieunhap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phieunhap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nguoi_tao` int NOT NULL,
  `ma_ncc` varchar(255) DEFAULT NULL,
  `ngay_tao` datetime DEFAULT NULL,
  `ngay_cap_nhat` datetime DEFAULT NULL,
  `nguoi_cap_nhat` int DEFAULT NULL,
  `ma_pn` varchar(255) DEFAULT NULL,
  `trang_thai` int DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phieunhap_pk` (`ma_pn`),
  KEY `phieunhap___fk` (`ma_ncc`),
  KEY `phieunhap___fk_2` (`nguoi_tao`),
  CONSTRAINT `phieunhap___fk` FOREIGN KEY (`ma_ncc`) REFERENCES `nhacungcap` (`ma_ncc`),
  CONSTRAINT `phieunhap___fk_2` FOREIGN KEY (`nguoi_tao`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phieunhap`
--

LOCK TABLES `phieunhap` WRITE;
/*!40000 ALTER TABLE `phieunhap` DISABLE KEYS */;
INSERT INTO `phieunhap` VALUES (1,2,'ncc1','2024-11-20 17:14:09',NULL,2,'PN673e18e1e85fb',3),(2,2,'ncc1','2024-11-21 22:41:19',NULL,2,'PN673fb70f17faa',2);
/*!40000 ALTER TABLE `phieunhap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phieuxuat`
--

DROP TABLE IF EXISTS `phieuxuat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phieuxuat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nguoi_tao` int DEFAULT NULL,
  `nguoi_cap_nhat` int DEFAULT NULL,
  `ma_px` varchar(255) DEFAULT NULL,
  `trang_thai` int DEFAULT '1',
  `ngay_tao` datetime DEFAULT NULL,
  `dia_chi` text,
  `sdt` varchar(20) DEFAULT NULL,
  `ngay_cap_nhat` datetime DEFAULT NULL,
  `ho_ten` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phieuxuat_pk` (`ma_px`),
  KEY `phieuxuat___fk` (`nguoi_tao`),
  KEY `phieuxuat___fk_2` (`nguoi_cap_nhat`),
  CONSTRAINT `phieuxuat___fk` FOREIGN KEY (`nguoi_tao`) REFERENCES `user` (`id`),
  CONSTRAINT `phieuxuat___fk_2` FOREIGN KEY (`nguoi_cap_nhat`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phieuxuat`
--

LOCK TABLES `phieuxuat` WRITE;
/*!40000 ALTER TABLE `phieuxuat` DISABLE KEYS */;
INSERT INTO `phieuxuat` VALUES (1,2,2,'PX673ffdfadcee4',2,'2024-11-22 03:43:54','Can tho','0794351159',NULL,'Nguyen Van A'),(2,2,NULL,'PX_67400aa797a14',1,'2024-11-22 04:37:59','Địa chỉ giao hàng','Số điện thoại',NULL,'Tên người nhận'),(3,2,NULL,'PX_67400b0abb208',1,'2024-11-22 04:39:38','Can tho','0794351154',NULL,'Nguyen Van A'),(4,2,NULL,'PX_67400db637f6d',1,'2024-11-22 04:51:02','Can tho','0794351159',NULL,'Nguyen Van A'),(5,2,NULL,'PX_67400eb0de0d2',1,'2024-11-22 04:55:12','Can tho, Thị trấn Phong Điền, Huyện Phong Điền, Thành phố Cần Thơ','0794351159',NULL,'Nguyen Van a'),(6,2,NULL,'PX_67400f47296cd',1,'2024-11-22 04:57:43','Can tho, Thị trấn Phùng, Huyện Đan Phượng, Thành phố Hà Nội','0794351159',NULL,'Nguyen Van a'),(7,4,4,'PX_6740153179e20',3,'2024-11-22 05:22:57','Can tho, Xã Mỹ Khánh, Huyện Phong Điền, Thành phố Cần Thơ','0794351159',NULL,'Nguyen Van a'),(8,5,NULL,'PX675075388fc55',1,'2024-12-04 15:28:56','','',NULL,''),(9,5,NULL,'PX67507554c606a',1,'2024-12-04 15:29:24','','',NULL,'');
/*!40000 ALTER TABLE `phieuxuat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'admin'),(2,'Chủ cửa hàng'),(3,'Nhân viên bán hàng'),(4,'Nhân viên kho'),(5,'Kế toán'),(6,'Khách hàng');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sach`
--

DROP TABLE IF EXISTS `sach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sach` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_sach` varchar(255) DEFAULT NULL,
  `ma_tg` varchar(255) DEFAULT NULL,
  `so_luong` int DEFAULT '0',
  `ma_tl` varchar(255) DEFAULT NULL,
  `ma_nxb` varchar(255) DEFAULT NULL,
  `ma_ngan` varchar(255) DEFAULT NULL,
  `ma_km` varchar(255) DEFAULT NULL,
  `ma_dvt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gia` float NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `ten_sach` varchar(255) NOT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sach_pk` (`ma_sach`),
  UNIQUE KEY `sach_pk_2` (`ma_sach`),
  KEY `sach_khuyenmai_ma_km_fk` (`ma_km`),
  KEY `sach_ngan_ma_ngan_fk` (`ma_ngan`),
  KEY `ma_nxb` (`ma_nxb`),
  KEY `ma_tg` (`ma_tg`),
  KEY `ma_tl` (`ma_tl`),
  KEY `ma_dvt` (`ma_dvt`),
  CONSTRAINT `sach_ibfk_1` FOREIGN KEY (`ma_nxb`) REFERENCES `nhaxuatban` (`ma_nxb`),
  CONSTRAINT `sach_ibfk_2` FOREIGN KEY (`ma_tg`) REFERENCES `tacgia` (`ma_tg`),
  CONSTRAINT `sach_ibfk_3` FOREIGN KEY (`ma_tl`) REFERENCES `theloai` (`ma_tl`),
  CONSTRAINT `sach_ibfk_4` FOREIGN KEY (`ma_dvt`) REFERENCES `donvitinh` (`ma_dvt`),
  CONSTRAINT `sach_khuyenmai_ma_km_fk` FOREIGN KEY (`ma_km`) REFERENCES `khuyenmai` (`ma_km`),
  CONSTRAINT `sach_ngan_ma_ngan_fk` FOREIGN KEY (`ma_ngan`) REFERENCES `ngan` (`ma_ngan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sach`
--

LOCK TABLES `sach` WRITE;
/*!40000 ALTER TABLE `sach` DISABLE KEYS */;

INSERT INTO `sach` (`id`, `ma_sach`, `ma_tg`, `so_luong`, `ma_tl`, `ma_nxb`, `ma_ngan`, `ma_km`, `ma_dvt`, `gia`, `is_active`, `ten_sach`, `hinh_anh`) VALUES
(1, 'BOOK1', 'TG13', 10, 'TL4', 'NXB1', 'N7', 'KM1', 'DVT1', 100000, 1, 'Kỹ Năng Quản Lý Tài Chính Cá Nhân Cho Gen Z', '../../images/4.webp'),
(2, 'BOOK2', 'TG227', 11, 'TL18', 'NXB1', 'N41', 'KM1', 'DVT1', 200000, 1, 'Tri Thức Về Vạn Vật - Một Thế Giới Trực Quan Chưa Từng Thấy (Tái Bản 2023)', '../../images/Screenshot 2024-12-02 215342.png'),
(3, 'BOOK3', 'TG233', 19, 'TL7', 'NXB1', 'N18 ', 'KM1', 'DVT1', 187000, 1, 'Khởi Nghiệp Tinh Gọn', '../../images/10.webp'),
(4, 'BOOK4', 'TG225', 9, 'TL1', 'NXB1', 'N4', 'KM1', 'DVT1', 100000, 1, 'Nguyên Lý Kinh Doanh Bền Vững - Quảng Cáo Và Hiệu Ứng Xã Hội', '../../images/Screenshot 2024-12-02 214701.png'),
(5, 'BOOK5', 'TG33', 10, 'TL7', 'NXB16', 'N17', 'KM1', 'DVT1', 110000, 1, 'Không Đến Một', '../../images/11.webp'),
(6, 'BOOK6', 'TG14', 10, 'TL6', 'NXB7', 'N18 ', 'KM1', 'DVT1', 200000, 1, 'Kỹ năng viết cho người hành nghề luật', '../../images/9.jpg'),
(7, 'BOOK7', 'TG16', 10, 'TL2', 'NXB1', 'N3', 'KM1', 'DVT1', 112000, 1, 'Nghiên Cứu Trong Marketing', '../../images/Screenshot 2024-12-02 214158.png'),
(8, 'BOOK8', 'TG33', 10, 'TL1', 'NXB2', 'N27', 'KM1', 'DVT1', 130000, 1, 'Mê Cung Diệu Kì - Vòng Quanh Thế Giới', '../../images/Screenshot 2024-12-02 215210.png'),
(9, 'BOOK9', 'TG226', 10, 'TL1', 'NXB4', 'N28', 'KM1', 'DVT1', 345000, 1, 'Everything Under The Sun - 366 Câu Hỏi Lý Thú Của Trẻ', '../../images/Screenshot 2024-12-02 215342.png'),
(10, 'BOOK10', 'TG227', 10, 'TL1', 'NXB3', 'N13', 'KM1', 'DVT1', 700000, 1, 'Tri Thức Về Vạn Vật - Một Thế Giới Trực Quan Chưa Từng Thấy', '../../images/Screenshot 2024-12-02 215342.png'),
(11, 'BOOK11', 'TG227', 10, 'TL1', 'NXB8', 'N29', 'KM1', 'DVT1', 229000, 1, 'Điều Kỳ Diệu Của Lòng Hiếu Khách', '../../images/0.webp'),
(12, 'BOOK12', 'TG15', 10, 'TL2', 'NXB16', 'N4', 'KM1', 'DVT1', 169000, 1, 'Marketing Cho Bán Lẻ ', '../../images/Screenshot 2024-12-02 215709.png'),
(13, 'BOOK13', 'TG11', 10, 'TL3', 'NXB20', 'N5', 'KM1', 'DVT1', 195000, 1, 'Dặm Đường Tôi Đi', '../../images/Screenshot 2024-12-02 215751.png'),
(14, 'BOOK14', 'TG228', 10, 'TL3', 'NXB11', 'N6', 'KM1', 'DVT1', 118000, 1, 'Quyết Định Triệu Đô', '../../images/Screenshot 2024-12-02 215915.png'),
(15, 'BOOK15', 'TG15', 10, 'TL4', 'NXB16', 'N7', 'KM1', 'DVT1', 80000, 1, 'Bí Mật Khoa Học Làm Giàu', '../../images/1.jpg'),
(16, 'BOOK16', 'TG230', 10, 'TL4', 'NXB16', 'N8', 'KM1', 'DVT1', 300000, 1, 'Ngày Đòi Nợ – Payback Time', '../../images/3.webp'),
(17, 'BOOK17', 'TG12', 10, 'TL4', 'NXB1', 'N8', 'KM1', 'DVT1', 113000, 1, 'Make Money Online', '../../images/5.webp'),
(18, 'BOOK18', 'TG232', 10, 'TL5', 'NXB17', 'N9', 'KM1', 'DVT1', 638000, 1, 'Combo 2 cuốn : Kế toán tài chính', '../../images/7.jpg'),
(19, 'BOOK19', 'TG231', 10, 'TL5', 'NXB8', 'N10', 'KM1', 'DVT1', 190000, 1, 'Để Có Một Tương Lai Tài Chính Tươi Sáng', '../../images/6.webp'),
(20, 'BOOK20', 'TG18', 10, 'TL6', 'NXB7', 'N11', 'KM1', 'DVT1', 109000, 1, 'Luật Đất Đai (2024)', '../../images/8.webp'),
(21, 'BOOK21', 'TG234', 10, 'TL8', 'NXB19', 'N19 ', 'KM1', 'DVT2', 220000, 1, 'Thần Thoại Hy Lạp Trọn Bộ 2 Tập', '../../images/12.webp'),
(22, 'BOOK22', 'TG33', 10, 'TL8', 'NXB19', 'N20', 'KM1', 'DVT1', 115000, 1, 'Truyện Thạch Yêu', '../../images/13.jpg'),
(23, 'BOOK23', 'TG235', 10, 'TL9', 'NXB18', 'N21', 'KM1', 'DVT1', 220000, 1, 'Cùng Cha Tới Auschwits', '../../images/14.png'),
(24, 'BOOK24', 'TG236', 10, 'TL9', 'NXB16', 'N22', 'KM1', 'DVT1', 190000, 1, 'Áo Xưa Dù Nhàu', '../../images/15.webp'),
(25, 'BOOK25', 'TG33', 10, 'TL10', 'NXB16', 'N23', 'KM1', 'DVT1', 1000000, 1, 'Tập Văn Họa Kỷ Niệm Nguyễn Du', '../../images/16.webp'),
(26, 'BOOK26', 'TG238', 10, 'TL10', 'NXB8', 'N24', 'KM1', 'DVT1', 225000, 1, 'Alexander Đại Đế - Huyển Thoại Xứ Macedonia', '../../images/17.webp'),
(27, 'BOOK27', 'TG237', 10, 'TL11', 'NXB6', 'N25', 'KM1', 'DVT1', 100000, 1, 'Thơ Rubaiyat', '../../images/18.webp'),
(28, 'BOOK28', 'TG239', 10, 'TL11', 'NXB19', 'N26', 'KM1', 'DVT1', 388000, 1, '1001 Bài Thơ Tình Nổi Tiếng Thế Giới', '../../images/19.webp'),
(29, 'BOOK29', 'TG21', 10, 'TL12', 'NXB11', 'N27', 'KM1', 'DVT1', 195000, 1, 'Layla - Linh Hồn Bị Đánh Tráo', '../../images/20.webp'),
(30, 'BOOK30', 'TG22', 10, 'TL1', 'NXB16', 'N28', 'KM1', 'DVT1', 120000, 1, 'Những Ta', '../../images/21.jpg'),
(31, 'BOOK31', 'TG22', 10, 'TL12', 'NXB17', 'N28', 'KM1', 'DVT1', 172000, 1, 'Gió Tự Thời Khuất Mặt', '../../images/22.jpg'),
(32, 'BOOK32', 'TG240', 10, 'TL13', 'NXB19', 'N29', 'KM1', 'DVT1', 100000, 1, 'Tiếng Gọi', '../../images/23.webp'),
(33, 'BOOK33', 'TG23', 10, 'TL13', 'NXB11', 'N30', 'KM1', 'DVT1', 110000, 1, 'Ly Ca', '../../images/24.jpg'),
(34, 'BOOK34', 'TG33', 10, 'TL14', 'NXB18', 'N31', 'KM1', 'DVT1', 110000, 1, 'Khi Địa Ngục Trống Rỗng', '../../images/25.jpg'),
(35, 'BOOK35', 'TG241', 10, 'TL14', 'NXB13', 'N32', 'KM1', 'DVT1', 150000, 1, 'Những Đồ Vật Có Linh Hồn', '../../images/26.webp'),
(36, 'BOOK36', 'TG242', 10, 'TL15', 'NXB20', 'N33', 'KM1', 'DVT1', 95000, 1, 'Chuyến Phiêu Lưu Diệu Kỳ Của Edward Tulane', '../../images/27.jpg'),
(37, 'BOOK37', 'TG24', 10, 'TL15', 'NXB5', 'N34', 'KM1', 'DVT1', 360000, 1, 'Truyện Kiếm Hiệp Hiệp Khách Hành', '../../images/28.jpg'),
(38, 'BOOK38', 'TG243', 10, 'TL16', 'NXB6', 'N35', 'KM1', 'DVT1', 119000, 1, 'Mexico Kỳ Án', '../../images/29.jpg'),
(39, 'BOOK39', 'TG19', 10, 'TL16', 'NXB18', 'N36', 'KM1', 'DVT1', 300000, 1, 'Ghi Chép Pháp Y', '../../images/30.webp'),
(40, 'BOOK40', 'TG26', 10, 'TL17', 'NXB16', 'N39', 'KM1', 'DVT1', 69000, 1, 'Steam English Chủ Đề Khoa Học', '../../images/31.jpg'),
(41, 'BOOK41', 'TG33', 10, 'TL17', 'NXB14', 'N40', 'KM1', 'DVT1', 50000, 1, 'Bách Khoa Tri Thức - Khám Phá Khoa Học', '../../images/32.webp'),
(42, 'BOOK42', 'TG244', 10, 'TL18', 'NXB14', 'N41', 'KM1', 'DVT1', 189000, 1, '1000 Bộ Não - Lý Thuyết Mới Về Trí Tuệ Con Người', '../../images/33.webp'),
(43, 'BOOK43', 'TG245', 10, 'TL18', 'NXB13', 'N42', 'KM1', 'DVT1', 65000, 1, 'Bí Ẩn Mãi Mãi Là Bí Ẩn - Siêu Nhiên Kỳ Bí', '../../images/34.webp'),
(44, 'BOOK44', 'TG27', 10, 'TL19', 'NXB13', 'N43', 'KM1', 'DVT1', 220000, 1, 'Trẻ Em Khó Học Thế Nào', '../../images/35.jpg'),
(45, 'BOOK45', 'TG246', 10, 'TL21', 'NXB13', 'N47', 'KM1', 'DVT1', 129000, 1, 'Sức Hút Của Sự Tập Trung - Việc Khó Nhất, Làm Đầu Tiên', '../../images/89.jpg'),
(46, 'BOOK46', 'TG28', 10, 'TL19', 'NXB10', 'N44', 'KM1', 'DVT1', 159000, 1, 'Con Không Phải Là Đứa Trẻ Xấu', '../../images/36.webp'),
(47, 'BOOK47', 'TG30', 10, 'TL20', 'NXB6', 'N45', 'KM1', 'DVT1', 60000, 1, 'Chuyện Con Mèo Dạy Hải Âu Bay', '../../images/37.jpg'),
(48, 'BOOK48', 'TG247', 10, 'TL21', 'NXB13', 'N48', 'KM1', 'DVT1', 149000, 1, 'Thao Túng Cảm Xúc: Áp Đặt Và Định Kiến', '../../images/38.webp'),
(49, 'BOOK49', 'TG30', 10, 'TL20', 'NXB19', 'N46', 'KM1', 'DVT1', 60000, 1, 'Hachiko – Chú Chó Đợi Chờ', '../../images/39.webp'),
(50, 'BOOK50', 'TG248', 10, 'TL22', 'NXB15', 'N49', 'KM1', 'DVT1', 105000, 1, '\'Đẹp Đỉnh Cao Chao Đảo Thế Giới', '../../images/40.webp'),
(51, 'BOOK51', 'TG249', 10, 'TL22', 'NXB15', 'N50', 'KM1', 'DVT1', 180000, 1, 'Skincare Cho Cô Nàng Bận Rộn', '../../images/41.webp'),
(52, 'BOOK52', 'TG250', 10, 'TL23', 'NXB15', 'N51', 'KM1', 'DVT1', 37000, 1, '30 Món Ăn Đặc Sắc Từ Thịt Heo', '../../images/42.jpg');
UNLOCK TABLES;

--
-- Table structure for table `tacgia`
--

DROP TABLE IF EXISTS `tacgia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tacgia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_tg` varchar(255) DEFAULT NULL,
  `ten_tg` varchar(255) DEFAULT NULL,
  `mo_ta` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tacgia_pk` (`ma_tg`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tacgia`
--


LOCK TABLES `tacgia` WRITE;
/*!40000 ALTER TABLE `tacgia` DISABLE KEYS */;
INSERT INTO `tacgia` (`id`, `ma_tg`, `ten_tg`, `mo_ta`, `is_active`) VALUES
(1, 'TG1', 'Rosie Nguyễn', 'Rosie Nguyễn tên thật là Nguyễn Hoàng Nguyên, một tác giả sách, blogger/facebooker về văn hóa du lịch, giảng viên lớp học kĩ năng, và huấn luyện viên yoga. Ngoài việc viết lách và giảng dạy thì là một người tự học, một ta ba lô, một kẻ mộng mơ và đặc biệt chị có một tuổi trẻ đáng để học hỏi trải nghiệm và từng là người dẫn dắt cho nhiều thế hệ trẻ tìm thấy đam mê của mình', 1),
(2, 'TG2', 'Nguyên Phong ', 'John Vũ – Bút danh Nguyên Phong – Một cái tên của nền khoa học nước nhà, một dịch giả nổi tiếng. Những tựa sách của ông để lại rất nhiều ấn tượng trong lòng độc giả. Tác giả Nguyên Phong được xem là một trong những người sáng tạo nhất thế giới. Nhắc đến ông hẳn bạn đọc sẽ chẳng thể nào quên những tác phẩm bất hủ với thời gian', 1),
(3, 'TG3', ' Nguyễn Khoa Điềm', 'Nguyễn Khoa Điềm sinh năm 1943, tại Phong Điền- Thừa Thiên Huế. Ông sinh ra trong một gia đình tri thức Cách mạng. Ông là nhà thơ trưởng thành từ kháng chiến chống Mỹ cứu nước của dân tộc. Thơ của Ngu', 1),
(4, 'TG4', 'Chế Lan Viên', 'Chế Lan Viên (1920-1989), tên khai sinh là Phan Ngọc Hoan, quê ở Quảng Trị. Chế Lan Viên là một trong những người đi đầu trong phong trào thơ mới Việt Nam. Khi tham gia kháng chiến chống Pháp, ông đã ', 1),
(5, 'TG5', ' Kim Lân', 'Kim Lân (1921-2007), tên thật là Nguyễn Văn Tài, quê ở Từ Sơn - Hà Bắc. Ông là một nhà văn chuyên viết về thể loại truyện ngắn nói về cuộc đời và số phận của những người nông dân và vùng nông thôn Việ', 1),
(6, 'TG6', 'Tố Hữu', 'Tố Hữu (1920-2002), tên thật là Nguyễn Kim Thành quê ở Quảng Điền - Thừa Thiên Huế. Ông là nhà thơ tiêu biểu của Cách mạng Việt Nam. Không chỉ là một nhà thơ, Tố Hữu còn là một chiến sĩ Cách mạng lão ', 1),
(7, 'TG7', 'Tô Hoài', 'Tô Hoài (1920-2014), tên khai sinh của ông là Nguyễn Sen, ông được sinh ra tại huyện Thanh Oai, tỉnh Hà Đông. Nhưng lại lớn lên ở quê ngoại là huyện Từ Liêm, tỉnh Hà Đông. Ông là một nhà văn chuyên ng', 1),
(8, 'TG8', 'Andersen', 'Hans Christian Andersen (2 tháng 4 năm 1805 – 4 tháng 8 năm 1875; tiếng Việt thường viết là Han-xơ Crít-xtian An-đéc-xen) là nhà văn người Đan Mạch chuyên viết truyện cổ tích cho thiếu nhi. Trong tiến', 1),
(9, 'TG9', 'William Shakespeare', 'William Shakespeare (tên phiên âm: Uy-li-am Sếch-xpia)không rõ ngày sinh của ông, nhưng theo truyền thống được ghi nhận là vào ngày 23 tháng 4 năm 1564, ngày thánh George; mất ngày 23 tháng 4 năm 1616', 1),
(10, 'TG10', 'Cheri Hyeri', 'Tác giả viết các kiến thức cơ bản cho người mới bắt đầu học tiếng Hàn. ', 1),
(11, 'TG11', 'Võ Quang Huệ', 'Ông Võ Quang Huệ hiện đang là Cố vấn cấp cao Tập đoàn Vingroup, thành viên Hội đồng trường Đại học Việt – Đức và trường Đại học Sư phạm Kỹ thuật Thành phố Hồ Chí Minh.\r\n\r\n- Nguyên Phó Tổng Giám đốc Phụ trách VinFast, Tập đoàn Vingroup.\r\n\r\n- Nguyên Tổng Giám đốc Bosch Việt Nam.\r\n\r\n- Ông là một chuyên gia hàng đầu trong lĩnh vực Kỹ thuật ô-tô với nhiều năm kinh nghiệm làm việc tại BMW, đảm đương qua nhiều vị trí từ nghiên cứu sản xuất đến phụ trách công ty con, nhà máy sản xuất ở từ u sang Á của tập đoàn này.', 1),
(12, 'TG12', 'Lisa Johnson', 'Lisa Johnson là một chuyên gia chiến lược kinh doanh toàn cầu có khả năng tạo ra doanh thu hàng triệu đô la, người đã kiếm 90% thu nhập thông qua các nguồn thu nhập thụ động hoặc bán thụ động. Lisa đã phát triển công việc kinh doanh của mình từ khoản nợ 30 nghìn đô la lên đến doanh thu hàng triệu bảng Anh trong vòng chưa đầy 4 năm. \r\nLisa Johnson cũng là người đặc biệt tin rằng ai cũng có thể thành công, bất kể xuất phát điểm như thế nào. Cô ấy là đại sứ cho tổ chức từ thiện BulliesOut và nổi tiếng với chiến dịch của riêng mình nhằm chống lại nạn bắt nạt trên mạng.\r\n ', 1),
(13, 'TG13', 'Ray & Jessica Higdon', 'Là bộ đôi diễn giả, huấn luyện viên kiêm chuyên gia tiếp thị. Họ từng đứng chung sân khấu với Tony Robbins, Bob Proctor, Les Brown, Robert Kiyosaki và nhiều cái tên khác. Vào năm 2018, công ty của họ đã được công nhận trong danh sách Inc. 5000 với tư cách là một trong những công ty phát triển nhanh nhất Hoa Kỳ.', 1),
(14, 'TG14', 'TS. Trần Thị Quang Hồng', 'Bà tốt nghiệp hệ cử nhân và thạc sĩ của Trường Đại học Luật Hà Nội, lấy bằng Tiến sĩ luật kinh doanh và thương mại ở Trường Đại học Monash, Australia (2012-2016) theo Chương trình học bổng toàn phần của Chính phủ Úc và đã tham gia một số khoá đào tạo ngắn hạn về viết và phân tích trong lĩnh vực luật theo chương trình được Trường Luật Harvard tài trợ. TS. Hồng là người nhận giải thưởng cho bài viết xuất sắc nhất tại Hội nghị thường niên thứ 12 của Viện luật Châu Á (năm 2015) và được VCCI ghi nhận về những đóng góp cho hệ thống pháp luật kinh doanh (2014). Hiện TS. Hồng công tác tại Viện Khoa học pháp lý, Bộ Tư pháp.', 1),
(15, 'TG15', 'Bob Negen, SuSan Negen', 'Bob Negen đã sáng lập ra WhizBang! Training sau khi gặt hái được nhiều thành công trong việc điều hành chuỗi các cửa hàng kinh doanh diều hơn hai thập kỷ. Sáu năm cuối cùng của mình, ông đã dành thời gian dạy các giám đốc, các ông chủ tư nhân những kỹ năng thực hành cơ bản để có thể thực hiện tốt việc kinh doanh bán lẻ. Trong tác phẩm của mình, Bob chia sẻ những kinh nghiệm, những bài học đắt giá mà ông học được trong cuộc đời minh như một nhà diễn thuyết, một tác giả và một nhà tư vấn.', 1),
(16, 'TG16', 'Nina Seppala', 'Nina Seppala, tác giả cuốn sách, là Phó Giám đốc tại Trường Quản lý thuộc Đại học London (UCL), nơi bà giảng dạy về luân lý của trí tuệ nhân tạo và đã xuất bản nhiều nghiên cứu về luân lý kinh doanh​.', 1),
(17, 'TG17', 'Danny Meyer', 'Meyer sinh ra và lớn lên trong một gia đình Do Thái cải cách ở St. Louis, Missouri con trai của Roxanne (nhũ danh Harris) và Morton L. Meyer.Cha ông là chủ tịch của một công ty du lịch, khách sạn và bất động sản ở St. Louis.  Ông nội của ông là doanh nhân và nhà từ thiện Chicago, Irving B. Harris.', 1),
(18, 'TG18', 'Quốc Hội', 'Quốc Hội', 1),
(19, 'TG19', 'Lưu Bát Bách', 'TQ', 1),
(20, 'TG20', 'Edgar parin D\'aulaire, Ingri', 'Ingri d’Aulaire và Edgar Parin d’Aulaire là cặp vợ chồng nhà văn và nhà minh họa sách thiếu nhi. Họ từ châu Âu nhập cư vào Mỹ và cho ra đời những cuốn sách chủ yếu tập trung vào chủ đề lịch sử. Vợ chồng d’Aulaire nằm trong thế hệ những nghệ sĩ nhập cư đã tạo nên Thời kỳ Hoàng kim của sách tranh ở nước Mỹ thế kỷ 20. Những cuốn sách tranh in thạch bản của họ đã trở thành sách gối đầu giường của trẻ em nước Mỹ trong nhiều thế hệ. Ingri và Edgar Parin đã nhận Huy chương Caldecott năm 1940\r\n\r\nNhững sách nổi bật gồm Những vị thần Bắc Âu, Những thần thoại Hy Lạp, Truyện Thạch yêu, v.v...', 1),
(21, 'TG21', 'Colleen Hoover', 'Colleen Hoover là tác giả của nhiều cuốn tiểu thuyết bán chạy nhất trên New York Times, bao gồm tiểu thuyết viễn tưởng dành cho phụ nữ bán chạy nhất It Ends with Us và tác phẩm tâm lý bán chạy nhất Verity (Bí mật bị chôn vùi). Cô đã giành được Giải thưởng Goodreads Choice cho tác phẩm lãng mạn hay nhất ba năm liên tiếp ― cho Confess (2015), It Ends with Us (2016) và Without Merit (2017). Confess đã được chuyển thể thành loạt phim trực tuyến dài bảy tập. Vào năm 2015, Hoover và gia đình cô thành lập Bookworm Box, một hiệu sách và dịch vụ đăng ký hằng tháng cung cấp các tiểu thuyết có chữ ký do các tác giả tặng. Tất cả lợi nhuận sẽ được chuyển đến các tổ chức từ thiện khác nhau mỗi tháng để giúp đỡ những người gặp khó khăn. Hoover sống ở Texas cùng chồng và ba cậu con trai của họ.', 1),
(22, 'TG22', 'Lê Minh Hà', 'Nhà văn Lê Minh Hà sinh năm 1962 tại Hà Nội. Chị tốt nghiệp Khoa Ngữ văn Ðại học Sư phạm năm 1983. Chị từng giảng dạy tại trường PTTH Hà Nội - Amsterdam, hiện làm việc và sinh sống tại CHLB Ðức. Lê Minh Hà bắt đầu viết văn từ khi chị còn ở trong nước và viết bền bỉ, liên tục trong suốt nhiều năm qua. Cuốn sách đầu tiên của chị được xuất bản năm 1998 tại Mỹ - tập truyện ngắn Trăng goá. Cho tới nay, Lê Minh Hà đã in 18 cuốn sách, bao gồm truyện ngắn, tản văn, tiểu thuyết.', 1),
(23, 'TG23', 'Đỗ Doãn Phương', 'Đỗ Doãn Phương\r\n- Sinh năm 1977, tại Đường Lâm, Sơn Tây, Hà Nội.\r\n- Đã xuất bản:\r\n+ Thơ: Ánh chớp (2006), Những ngọn triều nhục cảm (2009), Hoan ca (2011), Tuyệt ca (2013).\r\n+ Truyện ngắn: Một bông hồng và triệu bông hồng (2008), Tình cơm bụi (2011).\r\nHiện là Phó tổng biên tập báo Thể thao & Văn hóa', 1),
(24, 'TG24', 'Kim Dung', 'tên khai sinh là Tra Lương Dung, là một trong những nhà văn có tầm ảnh hưởng nhất đến văn học Trung Quốc hiện đại. Ông còn là người đồng sáng lập của nhật báo Hồng Kông Minh Báo, ra đời năm 1959 và là tổng biên tập đầu tiên của tờ báo này.', 1),
(25, 'TG25', 'Katie Daynes, Stefano Tognetti', '- Thực vật, Động vật\r\n- Môi trường sống và con người\r\n- Vật chất, Ánh sáng, Âm thanh\r\n- Các lực tác dụng\r\n- Điện và cách giữ an toàn khi sử dụng điện\r\n- Thời tiết và sự thay đổi của bốn mùa\r\n- Ngày và đêm, năm và tháng', 1),
(26, 'TG26', 'Sage Franch', 'Sage Franch, Sage Franch', 1),
(27, 'TG27', 'John Holt', 'Sinh (1923 - 1985) là một tác giả và nhà giáo dục nổi tiếng người Hoa Kỳ. Ông ủng hộ giáo dục tại gia và là nhà tiên phong trong lý thuyết về quyền trẻ em. Trong một bài phỏng vấn với Marlene Bumgarner, ông cho rằng: “về cơ bản, con người là một động vật học tập: chúng ta thích học hỏi, chúng ta cần học hỏi, chúng ta giỏi trong việc đó: chúng ta không cần phải được chỉ cách học như thế nào hoặc ai đó khiến ta phải học. Những gì giết chết các quá trình học tập này là những người can thiệp vào nó hoặc cố gắng điều chỉnh hoặc kiểm soát nó.\"\r\n\r\nJohn Holt chủ trương để học sinh tự quyết nhiều, giáo viên linh hoạt hơn để giúp mọi em học sinh đều học được tốt. Sau nhiều năm cố tạo ra sự thay đổi qua việc viết sách và làm việc trong hệ thống trường học, Holt nhận thấy rằng, trường học sẽ không thay đổi trừ phi xã hội thay đổi trước, do đó ông bắt đầu trợ giúp những phụ huynh và giáo viên nào muốn giúp con trẻ được học theo cách của chúng trong các tình huống thực tế.', 1),
(28, 'TG28', 'Melinda Wenner Moyer', 'là biên tập viên từng đoạt giải thưởng tại Tạp chí Scientific American, là cộng tác viên hằng tuần cho tờ New York Times và là giảng viên của Học viện Báo chí Arthur L. Carter, trường Đại học New York. Cô giành được Giải thưởng Bricker của năm 2019 cho bài viết Khoa học về Y học, tác phẩm đã được giới thiệu trong tuyển tập Bài luận về Khoa học và Tự nhiên hay nhất của Mỹ, năm 2020. Cô sống ở Thung lũng Hudson, New York cùng chồng và hai con. Con không phải là đứa trẻ xấu là cuốn sách đầu tay của cô.', 1),
(29, 'TG29', 'Luis Sepúlveda Calfucura', 'là một nhà văn và phóng viên Chile. Ông là một chiến sĩ cộng sản, chống lại chế độ Augusto Pinochet, đã bị chế độ độc tài quân sự cầm tù và tra tấn trong thập niên 1970[1]. Sepúlveda là tác giả những tập thơ và truyện ngắn. Ngoài tiếng Tây Ban Nha là tiếng mẹ đẻ, ông còn nói được tiếng Anh, Pháp và Ý. Vào cuối thập niên 1980, Sepúlveda chinh phục giới văn học với tiểu thuyết đầu tiên Lão già mê đọc truyện tình[2].', 1),
(30, 'TG30', 'Luis Prats', 'Luis Prats (Lluís Prats) sinh năm 1966 ở&nbsp;Terrassa, Tây Ban Nha. Ông từng&nbsp;nghiên cứu Lịch sử Nghệ thuật và Khảo cổ học tại vài trường Đại học ở Tây Ban Nha. Ông cũng từng là một giáo viên tiểu học và trung học, là một biên tập viên nghệ thuật và là một nhà sản xuất phim ở Los Angeles (California).', 1),
(31, 'TG31', 'Nguyễn Anh Tuấn', 'là một đầu bếp giàu kinh nghiệm và nhà sáng tạo nội dung trên đa nền tảng mạng xã hội, nổi bật với phong cách ẩm thực đầy sáng tạo và chỉn chu. Anh không ngừng khám phá những phương thức mới để thổi hồn vào các món ăn quen thuộc, mang đến trải nghiệm vị giác vừa gần gũi vừa độc đáo. Với triết lý luôn đặt văn hóa và bản sắc Việt Nam vào cốt lõi để sáng tạo, Nguyễn Anh Tuấn chia sẻ: “Tôi là một đầu bếp luôn muốn lan tỏa giá trị văn hóa và bản sắc của ẩm thực Việt bằng những món ăn đậm nét truyền thống nhưng mang phong cách hiện đại.”', 1),
(32, 'TG32', 'Dân gian', 'Những tác phẩm được tạo ra và phát triển bởi đa tầng lớp xã hội, được lưu truyền và duy trì qua nhiều thế hệ.', 1),
(33, 'TG33', 'Nhóm tác giả ', 'Nhiều tác giả cùng sáng tác và xuất bản sách\r\n', 1),
(34, 'TG34', 'Trần Thanh Hương, Hoàng Thị Hồng Nhung', 'Trần Thanh Hương\r\n\r\n▪ Thạc sĩ Ngôn ngữ Anh, Trường Đại học Ngoại ngữ, Đại học Quốc gia Hà Nội\r\n\r\n▪ 2013 – nay: Giáo viên tiếng Anh, Trường THPT Chuyên ngoại ngữ, Trường Đại học Ngoại ngữ, ĐHQG Hà Nội\r\n\r\n▪ 2017 - 2019: thành viên đoàn đánh giá bộ SGK 10 năm Đề án Ngoại ngữ Quốc gia\r\n\r\n▪ Các sách đã xuất bản: Hướng dẫn ôn thi tốt nghiệp THPT môn Tiếng Anh (NXB ĐHQGHN 2024); Trọng tâm kiến thức & Câu hỏi ôn luyện môn Tiếng Anh (NXB ĐHQGHN 2024); Let’s Write 2 - Viết đoạn nâng cao (Gamma 2022); Let’s Write 1 - Viết đoạn không khó (Gamma 2020), Bồi dưỡng học sinh giỏi THCS và Ôn thi vào lớp 10 THPT Chuyên môn Tiếng Anh (NXB Dân Trí 2021); 35 đề ôn luyện thi vào lớp 6 CLC môn tiếng Anh (NXB ĐHQGHN 2020). \r\n\r\nHoàng Thị Hồng Nhung\r\n\r\n▪ Thạc sĩ ngành Truyền thông, Trường Đại học London Metropolitan, Vương quốc Anh\r\n\r\n▪ 2012 - nay: Giáo viên luyện thi IELTS\r\n\r\n▪ 2022 - 2023: Cố vấn Học tập hệ Cambridge trường THPT Vinschool - The Harmony\r\n\r\n▪ 2016 - 2020: Đồng Sáng lập và Quản lý Học thuật Trung tâm Anh ngữ IMEC\r\n\r\n▪ 2012 - 2014: Giáo viên tiếng Anh các trường phổ thông công lập và quốc tế ở Tp Hồ Chí Minh (Trường Quốc tế Việt Úc) và Hà Nội (Trường THPT Thăng Long)', 1),
(35, 'TG35', 'Nguyễn Nhật Ánh', 'Nguyễn Nhật Ánh (sinh ngày 7 tháng 5 năm 1955) là một nhà văn người Việt. Ông được biết đến qua nhiều tác phẩm văn học về chủ đề tuổi mới lớn, các tác phẩm của ông cực kì được độc giả ưa chuộng và nhi', 1),
(36, 'TG36', 'Dale Breckenridge Carnegie', 'Dale Breckenridge Carnegie (1888 – 1955) là một nhà văn và nhà thuyết trình Mỹ và là người phát triển các lớp tự giáo dục, nghệ thuật bán hàng, huấn luyện đoàn thể, nói trước công chúng và các kỹ năng', 1),
(224, 'TG224', 'Bonita M. Kolb', '', 1),
(225, 'TG225', 'Sarah Turnbull', '', 1),
(226, 'TG226', 'Molly Oldfield', '', 1),
(227, 'TG227', 'DK', '', 1),
(228, 'TG228', 'Robert Rolih', '', 1),
(229, 'TG229', 'Bob Proctor - Sandy Gallagher', '', 1),
(230, 'TG230', 'Phil Town', '', 1),
(231, 'TG231', 'Robert T. Kiyosaki', '', 1),
(232, 'TG232', 'Trần Xuân Nam', '', 1),
(233, 'TG233', 'John Mullins', '', 1),
(234, 'TG234', 'Huỳnh Phan Thanh Uyên', '', 1),
(235, 'TG235', 'Jeremy Dronfield', '', 1),
(236, 'TG236', 'Đỗ Hồng Ngọc', '', 1),
(237, 'TG237', 'Omar Khayyam', '', 1),
(238, 'TG238', 'Philip Freeman', '', 1),
(239, 'TG239', 'Nguyễn Viết Thắng', '', 1),
(240, 'TG240', 'Lê Thái Hằng', '', 1),
(241, 'TG241', 'Tống Ngọc', '', 1),
(242, 'TG242', 'Kate Dicamillo', '', 1),
(243, 'TG243', 'Rafael Bernal', '', 1),
(244, 'TG244', 'Jeff Hawkins', '', 1),
(245, 'TG245', 'Tony Hưng', '', 1),
(246, 'TG246', 'Scott Allan ', '', 1),
(247, 'TG247', 'Châu Mộ Tư ', '', 1),
(248, 'TG248', 'Becca Anderson ', '', 1),
(249, 'TG249', 'Bing Han ', '', 1),
(250, 'TG250', 'Nguyễn Doãn Cẩm Vân', '', 1),
(251, 'TG251', 'Eliza Savage', '', 1),
(252, 'TG252', 'Bùi Mạnh Chiến', '', 1),
(253, 'TG253', 'Phan Minh Đạo', '', 1),
(254, 'TG254', 'Bảo Linh', '', 1),
(255, 'TG255', 'Stefania Leonardi Hartley', '', 1),
(256, 'TG256', 'Phan Huy Khải', '', 1),
(257, 'TG257', 'Trương Hải Hà', '', 1),
(258, 'TG258', 'Kyoko Tsuchiya', '', 1),
(259, 'TG259', 'Thu Trang', '', 1),
(260, 'TG260', 'The Changmi', '', 1);
UNLOCK TABLES;

--
-- Table structure for table `theloai`
--

DROP TABLE IF EXISTS `theloai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theloai` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_tl` varchar(255) DEFAULT NULL,
  `ten_tl` varchar(255) DEFAULT NULL,
  `ma_dm` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `theloai_pk_2` (`ma_tl`),
  UNIQUE KEY `theloai_pk` (`ma_tl`),
  KEY `theloai_danhmuc_ma_dm_fk` (`ma_dm`),
  CONSTRAINT `theloai_danhmuc_ma_dm_fk` FOREIGN KEY (`ma_dm`) REFERENCES `danhmuc` (`ma_dm`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theloai`
--

LOCK TABLES `theloai` WRITE;
/*!40000 ALTER TABLE `theloai` DISABLE KEYS */;
INSERT INTO `theloai` (`id`, `ma_tl`, `ten_tl`, `ma_dm`, `is_active`) VALUES
(1, 'TL1', 'Ngoại Thương', 'DM1', 1),
(2, 'TL2', 'Marketing - Bán Hàng', 'DM1', 1),
(3, 'TL3', 'Nhân Vật & Bài Học Kinh Doanh', 'DM1', 1),
(4, 'TL4', 'Tài Chính & Tiền Tệ', 'DM1', 1),
(5, 'TL5', 'Tài Chính – Kế Toán', 'DM1', 1),
(6, 'TL6', 'Sách Luật', 'DM1', 1),
(7, 'TL7', 'Khởi nghiệp', 'DM1', 1),
(8, 'TL8', 'Cổ tích thần thoại', 'DM2', 1),
(9, 'TL9', 'Tự Truyện - Hồi Ký', 'DM2', 1),
(10, 'TL10', 'Nhân Vật Văn Học/Nhân Vật Lịch Sử', 'DM2', 1),
(11, 'TL11', 'Thơ Ca', 'DM2', 1),
(12, 'TL12', 'Tiểu Thuyết', 'DM2', 1),
(13, 'TL13', 'Truyện Giả Tưởng – Thần Bí', 'DM2', 1),
(14, 'TL14', 'Truyện & Thơ Ca Dân Gian', 'DM2', 1),
(15, 'TL15', 'Truyện Kiếm Hiệp', 'DM2', 1),
(16, 'TL16', 'Truyện Trinh Thám - Vụ Án', 'DM2', 1),
(17, 'TL17', 'Khoa học cơ bản', 'DM3', 1),
(18, 'TL18', 'Khoa học kĩ thuật', 'DM3', 1),
(19, 'TL19', 'Gia Đình - Nuôi Dạy Con', 'DM3', 1),
(20, 'TL20', 'Nhà Ở - Vật Nuôi', 'DM3', 1),
(21, 'TL21', 'Sách Tâm Lý - Giới Tính', 'DM3', 1),
(22, 'TL22', 'Bí Quyết Làm Đẹp', 'DM3', 1),
(23, 'TL23', 'Nữ Công Gia Chánh', 'DM3', 1),
(24, 'TL24', 'Y học', 'DM3', 1),
(25, 'TL25', 'Văn học thiếu nhi', 'DM4', 1),
(26, 'TL26', 'Kiến thức – Kỹ năng cho trẻ', 'DM4', 1),
(27, 'TL27', 'Truyện Tranh', 'DM4', 1),
(28, 'TL28', 'Cấp 1', 'DM5', 1),
(29, 'TL29', 'Cấp 2', 'DM5', 1),
(30, 'TL30', 'Cấp 3', 'DM5', 1),
(31, 'TL31', 'Sách Giáo Khoa', 'DM5', 1),
(32, 'TL32', 'Sách Tham Khảo', 'DM5', 1),
(33, 'TL33', 'Tiếng Anh', 'DM6', 1),
(34, 'TL34', 'Tiếng Nhật', 'DM6', 1),
(35, 'TL35', 'Tiếng Trung', 'DM6', 1),
(36, 'TL36', 'Tiếng Hàn', 'DM6', 1),
(37, 'TL37', 'Khởi Ngiệp', 'DM3', 1);
/*!40000 ALTER TABLE `theloai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tuke`
--

DROP TABLE IF EXISTS `tuke`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tuke` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_tuke` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ten_tuke` varchar(255) DEFAULT NULL,
  `trang_thai` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tu_ke_pk` (`ma_tuke`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tuke`
--

LOCK TABLES `tuke` WRITE;
/*!40000 ALTER TABLE `tuke` DISABLE KEYS */;
INSERT INTO `tuke` (`id`, `ma_tuke`, `is_active`, `ten_tuke`, `trang_thai`) VALUES
(1, 'TK1', 1, 'Kinh tế', 'Đang hoạt động'),
(2, 'TK2', 1, 'Văn học', 'Đang hoạt động'),
(3, 'TK3', 1, 'Khoa học - Đời sống xã hội', 'Đang hoạt động'),
(4, 'TK4', 0, 'Thiếu nhi', 'Đang hoạt động '),
(5, 'TK5', 0, 'Giáo khoa - Giáo trình', 'Đang hoạt động'),
(6, 'TK6', 0, 'Ngoại ngữ', 'Đang hoạt động');
/*!40000 ALTER TABLE `tuke` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `matkhau` varchar(255) DEFAULT NULL,
  `role_id` int DEFAULT '6',
  `username` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'nvnhan.dev@gmail.com','43ef63b23b5ddbd8dc0b2805da15aca0',4,'nvnhan',1),(3,'nvnhan1@gmail.con','43ef63b23b5ddbd8dc0b2805da15aca0',1,'nvnhan1',1),(4,'nhan2@gmail.com','43ef63b23b5ddbd8dc0b2805da15aca0',6,'nvnhan2',1),(5,'admin1234@gmail.com','c93ccd78b2076528346216b3b2f701e6',1,'admin1234',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-04 16:08:24
