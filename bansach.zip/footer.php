<!-- Custom scripts -->
<?php
if (isset($_SESSION['message'])) {
    showAlert();
}
?>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        const alertElement = document.querySelector('.custom-alert-message');
        if (alertElement) {
            setTimeout(function() {
                alertElement.remove();
            }, 3000); // 3000ms tương đương với 3 giây
        }
    });
</script>
<!-- jQuery -->

<!-- Select2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<!-- MDBootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.10.2/mdb.min.js"></script>
</body>
</html>
<?php
    setSession("message", null);
?>