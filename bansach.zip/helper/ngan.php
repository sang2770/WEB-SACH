<?php
function get_ngan($search, $limit, $ofset) {
    global $conn;
    $query = "SELECT * FROM ngan";
    if (!empty($search)) {
        $query .= " WHERE ma_ngan LIKE '%$search%' 
                        or ten_ngan LIKE '%$search%'";
    }
    $query .= " ORDER BY id DESC LIMIT $ofset, $limit";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $ngans = array();
    while ($row = $results->fetch_assoc()) {
        $ngans[] = $row;
    }
    return $ngans;
}


function get_total_ngan($search = "")
{
    global $conn;
    $query = "SELECT COUNT(*) AS total FROM ngan";
    if (!empty($search)) {
        $query .= " WHERE ma_ngan LIKE '%$search%' 
                        or ten_ngan LIKE '%$search%'";
    }
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $results =  $stmt->get_result();
    $row = $results->fetch_assoc();
    return $row['total'];

}


function set_status_ngan($id, $status = 1)
{
    global $conn;
    $query = "UPDATE ngan SET is_active = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('ii', $status, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}


function get_ngan_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM ngan WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->fetch_object();
}


function get_ngan_by_name($name)
{
    global $conn;
    $query = "SELECT * FROM ngan WHERE ten_ngan = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $results = $stmt->get_result();
    return $results->num_rows > 0;
}


/**
 * Create a new ngan entry in the database.
 *
 * @param string $ten_ngan
 * @param string $tinh_trang
 * @param string $ma_gia
 * @return bool|int
 */
function create_ngan($ten_ngan, $tinh_trang, $ma_gia)
{
    global $conn;
    $query = "INSERT INTO ngan (ten_ngan, tinh_trang, ma_gia) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('sss', $ten_ngan, $tinh_trang, $ma_gia);
    $stmt->execute();
    $id = $conn->insert_id;
    $stmt->prepare("UPDATE ngan SET ma_ngan = 'N$id' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->insert_id;
}


/**
 * Update an existing ngan entry in the database by id.
 *
 * @param int $id
 * @param string $ten_ngan
 * @param string $tinh_trang
 * @param string $ma_gia
 * @return bool
 */
function update_ngan($id, $ten_ngan, $tinh_trang, $ma_gia)
{
    global $conn;
    $query = "UPDATE ngan SET ten_ngan = ?, tinh_trang = ?, ma_gia = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        trigger_error($conn->error, E_USER_ERROR);
        return false;
    }
    $stmt->bind_param('sssi', $ten_ngan, $tinh_trang, $ma_gia, $id);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}
?>