<?php
session_start();
require_once 'helper/common.php';
require_once 'helper/user.php';
global $conn;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;  // Giả sử user_id đã được lưu trong session
    $ma_sach = $_POST['ma_sach'];
    $gia = $_POST['gia'];
    $so_luong = 1;  // Bạn có thể thay đổi số lượng tùy thuộc vào yêu cầu của bạn

    if ($user_id) {
        // Kiểm tra xem sách đã có trong giỏ hàng của người dùng hay chưa
        $check_sql = "SELECT * FROM cart WHERE user_id = ? AND ma_sach = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("is", $user_id, $ma_sach);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Nếu sách đã có trong giỏ hàng, cập nhật số lượng
            $update_sql = "UPDATE cart SET so_luong = so_luong + 1 WHERE user_id = ? AND ma_sach = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("is", $user_id, $ma_sach);
            $update_stmt->execute();
        } else {
            // Nếu sách chưa có trong giỏ hàng, thêm vào giỏ hàng
            $insert_sql = "INSERT INTO cart (ma_sach, so_luong, gia, user_id) VALUES (?, ?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sidi", $ma_sach, $so_luong, $gia, $user_id);
            $insert_stmt->execute();
        }

        // Truy vấn để lấy tổng số lượng sản phẩm trong giỏ hàng của người dùng
        $cart_count_sql = "SELECT SUM(so_luong) AS total_items FROM cart WHERE user_id = ?";
        $stmt = $conn->prepare($cart_count_sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $total_items = $row['total_items'];

        $stmt->close();
        $conn->close();

        echo json_encode(['status' => 'success', 'total_items' => $total_items]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>