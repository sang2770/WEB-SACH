<?php
session_start();
require_once "../../helper/common.php";
require_once "../../helper/user.php";
require_once "../../helper/role.php";
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'tab-table';
?>

<?php require_once "../header.php"?>
    <div class="container mt-3">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-table" ? "active" : "" ?>" id="tl-tab" data-mdb-toggle="tab" href="#tl" role="tab" aria-controls="tl" aria-selected="true">Đơn vị tính</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?= $tab == "tab-form" ? "active" : "" ?>" id="tl-tab-form" data-mdb-toggle="tab" href="#tl-form" role="tab" aria-controls="tl-form" aria-selected="false">Thêm đơn vị tính</a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade <?= $tab == "tab-table" ? "active show" : "" ?>" id="tl" role="tabpanel" aria-labelledby="tl-tab">
                <?php require_once "table.php" ?>
            </div>
            <div class="tab-pane fade <?= $tab == "tab-form" ? "active show" : "" ?>" id="tl-form" role="tabpanel" aria-labelledby="tl-tab-form">
                <?php require_once "form.php" ?>
            </div>
        </div>
    </div>
<?php require_once "../../footer.php" ?>