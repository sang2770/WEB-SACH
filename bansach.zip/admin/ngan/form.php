<?php
$mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
    $id = $_GET['id'];
    $ngan = get_ngan_by_id($id);
    $mode = "update";
}

// Lấy danh sách tủ kệ từ cơ sở dữ liệu
$gia_list = get_gia_list();
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Giá -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenGia" name="ten_ngan" value="<?= isset($ngan->ten_ngan) ? htmlspecialchars($ngan->ten_ngan) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenGia">Tên Ngăn</label>
                </div>

                <!-- Tình Trạng -->
                <div class="form-outline mb-4">
                    <input type="text" id="tinhTrang" name="tinh_trang" value="<?= isset($ngan->tinh_trang) ? htmlspecialchars($ngan->tinh_trang) : null ?>" class="form-control" required />
                    <label class="form-label" for="tinhTrang">Tình Trạng</label>
                </div>

                <!-- Mã Tủ Kệ -->
                <div class="mb-4">
                    <?= genderSelect("ma_gia", "ma_gia", "Giá", $gia_list, $ngan->ma_gia ?? null)?>
                </div>

                <input type="hidden" name="id" value="<?= isset($ngan->id) ? htmlspecialchars($ngan->id) : null ?>"/>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Ngăn" : "Lưu Ngăn" ?></button>
            </form>
        </div>
    </div>
</div>