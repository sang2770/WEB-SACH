<?php
global $LIMIT;
require_once "../../helper/phieuxuat.php";
$limit = $LIMIT;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;
$search = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

$phieunhap_lst = get_phieuxuat($search, $limit, $offset);
$totalRecords = get_total_phieuxuat($search);
$totalPages = ceil($totalRecords / $limit);
?>
    <div class="card mt-1">
        <div class="card-body" style="height: 620px">
            <form action="index.php" method="get">
                <div class="form-group">
                    <input hidden name="page" value="<?php echo $page; ?>" />
                    <input type="text" placeholder="Tìm kiếm..." name="search" value="<?php echo $search; ?>" id="search" class="form-control" />
                    <button type="submit" class="btn btn-info mt-1">Tìm</button>
                    <a href="xuat_excel.php"><button type="button" class="btn btn-success mt-1">Xuất excel</button></a>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table align-middle">
                <thead>
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Mã Phiếu Xuất</th>
                    <th scope="col">Ngày Tạo</th>
                    <th scope="col">Người Tạo</th>
                    <th scope="col">Họ tên</th>
                    <th scope="col">Địa chỉ</th>
                    <th scope="col">Số điện thoại</th>
                    <th scope="col">Chi Tiết Sách</th>
                    <th scope="col">Hành Động</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                foreach ($phieunhap_lst as $pn) {
                    echo '<tr>';
                    echo '<td>' . $i . '</td>';
                    echo '<td>' . $pn['ma_px'] . '</td>';
                    echo '<td>' . $pn['ngay_tao'] . '</td>';
                    echo '<td>' . $pn['username'] . '</td>';
                    echo '<td>' . $pn['ho_ten'] . '</td>';
                    echo '<td>' . $pn['dia_chi'] . '</td>';
                    echo '<td>' . $pn['sdt'] . '</td>';
                    echo '<td>';
                    $sach_lst = get_sach_by_phieuxuat($pn['ma_px']); // Hàm để lấy danh sách sách theo mã phiếu nhập
                    if (!empty($sach_lst)) {
                        echo '<table class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr><th>Mã Sách</th><th>Tên sách</th><th>Số Lượng</th><th>Vốn</th><th>Giá bán</th></tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        foreach ($sach_lst as $sach) {
                            echo '<tr>';
                            echo '<td>' . $sach['ma_sach'] . '</td>';
                            echo '<td>' . $sach['ten_sach'] . '</td>';
                            echo '<td>' . $sach['so_luong'] . ' (' .$sach['ten_dvt']. ')' . '</td>';
                            echo '<td>' . $sach['von'] . '</td>';
                            echo '<td>' . $sach['gia_ban'] . '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody>';
                        echo '</table>';
                    } else {
                        echo 'Không có sách nào trong phiếu nhập này.';
                    }
                    echo '</td>';
                    echo '<td>';
                    if ($pn['trang_thai'] == 1) {
                        echo '<a href="create.php?ma_px=' . $pn['ma_px'] . '&status=confirm"><button class="btn btn-info btn-sm mt-1">Xác nhận</button></a>';
                        echo '<a href="create.php?ma_px=' . $pn['ma_px'] . '&status=cancel"><button class="btn btn-danger btn-sm mx-1">Huỷ</button></a>';
                    } elseif ($pn['trang_thai'] == 2) {
                        echo '<span class="text-success"> Đã xác nhận </span><br>';
                        echo '<a href="xuat_excel.php?id='.$pn['ma_px'].'"><button type="button" class="btn btn-success mt-1">Xuất excel</button></a>';
                    } elseif ($pn['trang_thai'] == 3) {
                        echo '<span class="text-danger"> Đã huỷ </span>';
                    }
                    echo '</td>';
                    echo '</tr>';
                    $i++;
                }
                ?>
                </tbody>
            </table>
            </div>
        </div>
        <div class="card-footer">
            <div class="pagination mx-auto">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
