<?php
session_start();
global $conn;

require_once "../../helper/common.php";
require_once "../../helper/donhang.php";
require_once "../../helper/hoadon.php";
require_once '../../helper/config.php';



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $id_dh = $_POST['id_dh'];

    $conn->begin_transaction();
    try {
        // Cập nhật trạng thái đơn hàng thành 'Hủy'
        setStatus_donhang($id_dh, 'Hủy');

        $conn->commit();
        setMessage("success", "Hủy đơn hàng thành công");
        // Chuyển hướng người dùng về trang danh sách đơn hàng sau khi hủy thành công
        header('Location: index.php');
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        setMessage("error", "Hủy đơn hàng thất bại: " . $e->getMessage());
    }

    $conn->close();
} else {
    header('Location: index.php');
}
?>
