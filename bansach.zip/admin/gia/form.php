<?php
$mode = "insert";
if(isset($_GET['id']) && $_GET['id']){
    $id = $_GET['id'];
    $gia = get_gia_by_id($id);
    $mode = "update";
}

// Lấy danh sách tủ kệ từ cơ sở dữ liệu
$tuke_list = get_tuke_list();
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php">
                <!-- Tên Giá -->
                <div class="form-outline mb-4">
                    <input type="text" id="tenGia" name="ten_gia" value="<?= isset($gia->ten_gia) ? htmlspecialchars($gia->ten_gia) : null ?>" class="form-control" required />
                    <label class="form-label" for="tenGia">Tên Giá</label>
                </div>

                <!-- Tình Trạng -->
                <div class="form-outline mb-4">
                    <input type="text" id="tinhTrang" name="tinh_trang" value="<?= isset($gia->tinh_trang) ? htmlspecialchars($gia->tinh_trang) : null ?>" class="form-control" required />
                    <label class="form-label" for="tinhTrang">Tình Trạng</label>
                </div>

                <!-- Mã Tủ Kệ -->
                <div class="mb-4">
                    <?= genderSelect("ma_tuke", "ma_tuke", "Tủ kệ", $tuke_list, $gia->ma_tuke ?? null)?>
                </div>

                <input type="hidden" name="id" value="<?= isset($gia->id) ? htmlspecialchars($gia->id) : null ?>"/>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <!-- Nút Gửi -->
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Giá" : "Lưu Giá" ?></button>
            </form>
        </div>
    </div>
</div>