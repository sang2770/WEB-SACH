<?php
$mode = "insert";
if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $sach = get_sach_by_id($id);
    $mode = "update";
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <form method="POST" action="create.php" enctype="multipart/form-data">
                <div class="form-outline mb-4">
                    <input type="text" id="ten_sach" name="ten_sach" value="<?= isset($sach->ten_sach) ? htmlspecialchars($sach->ten_sach) : null ?>" class="form-control" required />
                    <label class="form-label" for="ten_sach">Tên sách</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="number" id="so_luong" name="so_luong" value="<?= isset($sach->so_luong) ? htmlspecialchars($sach->so_luong) : null ?>" class="form-control" required />
                    <label class="form-label" for="so_luong">Số lượng</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="number" id="gia" name="gia" value="<?= isset($sach->gia) ? htmlspecialchars($sach->gia) : null ?>" class="form-control" required />
                    <label class="form-label" for="gia">Giá</label>
                </div>
                <div class=" mb-4">
                    <input type="file" id="hinh_anh" name="hinh_anh" class="form-control" <?= $mode == "insert" ? "required" : null ?>/>
                    <label class="form-label" for="hinh_anh">Hình ảnh</label>
                    <br>
                    <?php if ($mode == "update" && isset($sach->hinh_anh)): ?>
                        <img height="100px" src="<?= str_replace("../..", "", htmlspecialchars($sach->hinh_anh)) ?>" alt="Hình ảnh của sách" />
                    <?php endif; ?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_tg", "ma_tg", "Tác giả", get_select_list("ma_tg", "ten_tg", "tacgia"), $sach->ma_tg ?? null)?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_tl", "ma_tl", "Thể loại", get_select_list("ma_tl", "ten_tl", "theloai"), $sach->ma_tl ?? null)?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_nxb", "ma_nxb", "Nhà xuất bản", get_select_list("ma_nxb", "ten_nxb", "nhaxuatban"), $sach->ma_nxb ?? null)?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_ngan", "ma_ngan", "Ngăn", get_select_list("ma_ngan", "ten_ngan", "ngan"), $sach->ma_ngan ?? null)?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_dvt", "ma_dvt", "Đơn vị tính", get_select_list("ma_dvt", "ten_dvt", "donvitinh"), $sach->ma_dvt ?? null)?>
                </div>
                <div class="mb-4">
                    <?= genderSelect("ma_km", "ma_km", "Khuyến mãi", get_select_list("ma_km", "ten_km", "khuyenmai"), $sach->ma_km ?? null)?>
                </div>
                <?php if ($mode == "update"): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($sach->id) ?>"/>
                <?php endif; ?>
                <input type="hidden" name="mode" value="<?= $mode ?>" />
                <button type="submit" class="btn btn-primary btn-block mb-4"><?= $mode == "insert" ? "Thêm Sách" : "Lưu sách" ?></button>
            </form>
        </div>
    </div>
</div>