<?php
// if (isset($_SESSION['role_id']) && $_SESSION['role_id'] == 6) {
//     echo '<script>window.location.href = "/index.php";</script>';
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Material Design for Bootstrap</title>
    <!-- MDB icon -->
    <link rel="icon" href="../img/mdb-favicon.ico" type="image/x-icon" />
    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.10.2/mdb.min.css">
    <!-- Select2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
        .custom-alert-message {
            position: fixed; /* Định vị cố định */
            top: 58px;       /* Khoảng cách từ phía trên */
            right: 20px;     /* Khoảng cách từ bên phải */
            z-index: 1050;   /* Đảm bảo cảnh báo nằm trên các phần tử khác */
            width: auto;     /* Tự điều chỉnh theo độ dài nội dung */
            max-width: 400px; /* Giới hạn độ rộng tối đa */
        }
        .table-responsive {
            display: block;
            width: 100%;          /* Đảm bảo chiều rộng đầy đủ */
            overflow: auto;     /* Cuộn theo chiều ngang */
            -webkit-overflow-scrolling: touch;  /* Hỗ trợ cuộn mềm trên các thiết bị di động */
            white-space: nowrap;  /* Đảm bảo các cột không bị thay đổi dòng */
            height: 90%;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-body-tertiary">
    <!-- Container wrapper -->
    <div class="container-fluid">
        <!-- Toggle button -->
        <button
            data-mdb-collapse-init
            class="navbar-toggler"
            type="button"
            data-mdb-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <i class="fas fa-bars"></i>
        </button>

        <!-- Collapsible wrapper -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Navbar brand -->
            <a class="navbar-brand mt-2 mt-lg-0" href="#">
                <i class="fas fa-address-book"></i>
                BookStore
            </a>
            <!-- Left links -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/admin/index.php">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <?php
                    $role_id = getSession('role_id');
                        if ($role_id == 1) {
                            echo '                    <a class="nav-link" href="/admin/users.php">Người dùng</a>';
                        }
                    ?>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="dropdownBook" href="#" role="button" data-mdb-toggle="dropdown" aria-expanded="false">Quản lý sách</a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownBook">
                        <li><a class="dropdown-item" href="/admin/sach/index.php">Sách</a></li>
                        <li><a class="dropdown-item" href="/admin/nhaxuatban/index.php">Nhà xuất bản</a></li>
                        <li><a class="dropdown-item" href="/admin/nhacungcap/index.php">Nhà cung cấp</a></li>
                        <li><a class="dropdown-item" href="/admin/tacgia/index.php">Tác giả</a></li>
                        <li><a class="dropdown-item" href="/admin/danhmuc/index.php">Danh mục</a></li>
                        <li><a class="dropdown-item" href="/admin/theloai/index.php">Thể loại</a></li>
                        <li><a class="dropdown-item" href="/admin/donvitinh/index.php">Đơn vị tính</a></li>
                        <li><a class="dropdown-item" href="/admin/khuyenmai/index.php">Khuyến mãi</a></li>
                        <li><a class="dropdown-item" href="/admin/tuke/index.php">Tủ kệ</a></li>
                        <li><a class="dropdown-item" href="/admin/gia/index.php">Giá</a></li>
                        <li><a class="dropdown-item" href="/admin/ngan/index.php">Ngăn</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/admin/phieunhap/index.php">Phiếu nhập</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/admin/phieuxuat/index.php">Phiếu xuất</a>
                </li>
                <?php
                $allow = [1,2,3];
                $role_id = getCurrentRole(getSession('user_id'));
                ?>
                <?php if(in_array($role_id, $allow)): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/admin/hoadon/index.php">Hoá đơn</a>
                </li>
                <?php endif ?>
                
                <?php
                $allow = [1,2];
                $role_id = getCurrentRole(getSession('user_id'));
                ?>
                <?php if(in_array($role_id, $allow)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/thongke/index.php">Thống kê</a>
                    </li>
                <?php endif ?>

                <?php
                $allow = [1,2,3];
                $role_id = getCurrentRole(getSession('user_id'));
                ?>
                <?php if(in_array($role_id, $allow)): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/admin/donhang/index.php">Đơn hàng</a>
                </li>
                <?php endif ?>
            </ul>
            <!-- Left links -->
        </div>
        <!-- Collapsible wrapper -->

        <!-- Right elements -->
        <div class="d-flex align-items-center">
            <!-- Icon -->

            <!-- Avatar -->
            <?php
            if (isLogined()) {
                echo '
                <div class="dropdown">
                <a
        class="dropdown-toggle d-flex align-items-center hidden-arrow"
        href="#"
        id="navbarDropdownMenuAvatar"
        role="button"
        data-mdb-toggle="dropdown"
        aria-expanded="false"
    >
        <img
            src="/images/avt.png"
            class="rounded-circle"
            height="25"
            alt="Black and White Portrait of a Man"
            loading="lazy"
        />
    </a>
    <ul
        class="dropdown-menu dropdown-menu-end"
        aria-labelledby="navbarDropdownMenuAvatar"
    >
        <li>
            <a class="dropdown-item" href="/logout.php">Logout</a>
        </li>
    </ul>
            </div>';
                echo '<p class="text-reset m-2">' . getSession("username") . '</p>';
            }
            else {
                echo '<a href="login.php"><button type="button" class="btn btn-primary" data-mdb-ripple-init>Đăng nhập</button></a>';
            }

            ?>
        </div>
        <!-- Right elements -->
    </div>
    <!-- Container wrapper -->
</nav>
<!-- Navbar -->
</nav>