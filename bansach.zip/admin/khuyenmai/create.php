<?php
session_start();
require_once '../../helper/config.php';
require_once '../../helper/common.php';
require_once '../../helper/khuyenmai.php';

if (isset($_POST['mode']) && $_POST['mode'] == "insert") {
    $ten_km = $_POST['ten_km'];
    $ngay_bat_dau = $_POST['ngay_bat_dau'];
    $ngay_ket_thuc = $_POST['ngay_ket_thuc'];
    $phan_tram_giam_gia = $_POST['phan_tram_giam_gia'];
    $so_luong = $_POST['so_luong'];
    $mo_ta = $_POST['mo_ta'];
    if(get_khuyenmai_by_name($ten_km)) {
        setMessage("danger", "Khuyến mãi đã tồn tại");
        redirectTo("index.php?tab=tab-form");
    }
    $dt_a = new DateTime($ngay_bat_dau);
    $dt_b = new DateTime($ngay_ket_thuc);
    if ($dt_a > $dt_b) {
        setMessage("danger", "Ngày bắt đầu phải nhỏ hơn ngày kết thúc!");
        redirectTo("index.php?tab=tab-form");
    }

    create_khuyenmai($ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta);
    setMessage("info", "Thêm khuyến mãi thành công");
    redirectTo("index.php");
}

if (isset($_POST['mode']) && $_POST['mode'] == "update") {
    $id = $_POST['id'];
    $ten_km = $_POST['ten_km'];
    $ngay_bat_dau = $_POST['ngay_bat_dau'];
    $ngay_ket_thuc = $_POST['ngay_ket_thuc'];
    $phan_tram_giam_gia = $_POST['phan_tram_giam_gia'];
    $so_luong = $_POST['so_luong'];
    $mo_ta = $_POST['mo_ta'];

    $dt_a = new DateTime($ngay_bat_dau);
    $dt_b = new DateTime($ngay_ket_thuc);

    if ($dt_a > $dt_b) {
        setMessage("danger", "Ngày bắt đầu phải nhỏ hơn ngày kết thúc!");
        redirectTo("index.php?tab=tab-form&id=$id");
    }
    update_khuyenmai($id, $ten_km, $ngay_bat_dau, $ngay_ket_thuc, $phan_tram_giam_gia, $so_luong, $mo_ta);
    setMessage("info", "Cập nhật khuyến mãi thành công!");
    redirectTo("index.php");
}
?>