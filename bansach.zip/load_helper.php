<?php

$helperFiles = glob(__DIR__ . '/helper/*.php');

foreach ($helperFiles as $file) {
    include $file;
}
